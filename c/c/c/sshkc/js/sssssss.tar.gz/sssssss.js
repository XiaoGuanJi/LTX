// 猜数字游戏 (JavaScript 版本)
// 从Bash脚本转换而来
// 注意：这是一个浏览器/Node.js环境的控制台实现

// 游戏配置
const VERSION_NAME = "ULTRA v1.20260213";
const DATA_ROOT = "/storage/emulated/0/c/sshkc"; // 模拟路径
let GAME_COUNT = 0;
let SECRET_NUMBER = 0;
let ATTEMPTS = 0;
let SCORE = 0;
let START_TIME = 0;
let RANGE = 100;
let MAX_ATTEMPTS = 10;
let INITIAL_SCORE = 100;
let PENALTY = 5;
let MODE = "normal";
let TIME_LIMIT = 30;

// 文件系统模拟（浏览器中用localStorage，Node.js中用fs）
let storage = null;
try {
  if (typeof localStorage !== 'undefined') {
    storage = localStorage;
  } else if (typeof require !== 'undefined') {
    const fs = require('fs');
    storage = {
      getItem: (key) => {
        try { return fs.readFileSync(`${DATA_ROOT}/${key}`, 'utf8'); } 
        catch { return null; }
      },
      setItem: (key, value) => {
        try { fs.writeFileSync(`${DATA_ROOT}/${key}`, value); } 
        catch { console.log(`无法写入文件: ${key}`); }
      }
    };
  }
} catch (e) {
  storage = { getItem: () => null, setItem: () => {} };
  console.log("使用内存存储（无持久化）");
}

// 初始化
function initGame(difficulty) {
  console.log(`初始化游戏，难度: ${difficulty}`);
  
  switch(difficulty) {
    case "easy": initNormal(100, 10, 100, 5); break;
    case "normal": initNormal(100, 8, 100, 5); break;
    case "hard": initNormal(1000, 15, 150, 5); break;
    case "hell": initNormal(10000, 20, 200, 3); break;
    case "chaos": initChaos(); break;
    case "timeattack": initTimeAttack(); break;
    case "ninja": initNinja(); break;
    case "zombie": initZombie(); break;
    case "troll": initTroll(); break;
    default: initNormal(100, 10, 100, 5);
  }
  
  SECRET_NUMBER = Math.floor(Math.random() * RANGE) + 1;
  ATTEMPTS = 0;
  SCORE = INITIAL_SCORE;
  START_TIME = Date.now();
}

function initNormal(range, maxAttempts, initialScore, penalty) {
  RANGE = range;
  MAX_ATTEMPTS = maxAttempts;
  INITIAL_SCORE = initialScore;
  PENALTY = penalty;
  MODE = "normal";
}

function initChaos() {
  RANGE = Math.floor(Math.random() * 9900) + 100;
  MAX_ATTEMPTS = Math.floor(Math.random() * 15) + 5;
  INITIAL_SCORE = Math.floor(Math.random() * 150) + 50;
  PENALTY = Math.floor(Math.random() * 7) + 3;
  MODE = "chaos";
}

function initTimeAttack() {
  RANGE = 100;
  MAX_ATTEMPTS = 999;
  INITIAL_SCORE = 100;
  PENALTY = 0;
  TIME_LIMIT = 30;
  MODE = "timeattack";
}

function initNinja() {
  RANGE = 100;
  MAX_ATTEMPTS = 5;
  INITIAL_SCORE = 200;
  PENALTY = 20;
  MODE = "ninja";
}

function initZombie() {
  RANGE = 100;
  MAX_ATTEMPTS = 15;
  INITIAL_SCORE = 50;
  PENALTY = 2;
  MODE = "zombie";
}

function initTroll() {
  RANGE = 10;
  MAX_ATTEMPTS = 7;
  INITIAL_SCORE = 50;
  PENALTY = 0;
  MODE = "troll";
}

// 主游戏循环
async function playGame() {
  await selectDifficulty();
  console.log(`开始新游戏，模式: ${MODE}, 范围: 1-${RANGE}`);
  
  while (ATTEMPTS < MAX_ATTEMPTS) {
    showGameUI();
    const guess = await getUserInput("请输入你的选择: ");
    
    if (await handleSpecialCommands(guess)) continue;
    if (!validateInput(guess)) continue;
    
    ATTEMPTS++;
    SCORE -= PENALTY;
    
    if (checkGuess(guess)) return;
    
    provideFeedback(guess);
    handleSpecialModeEffects();
  }
  
  handleGameOver();
}

async function selectDifficulty() {
  showTitle();
  console.log("请选择游戏模式:");
  console.log("1. 简单模式 (1-100, 10次机会)");
  console.log("2. 普通模式 (1-100, 8次机会)"); 
  console.log("3. 困难模式 (1-1000, 15次机会)");
  console.log("4. 地狱模式 (1-10000, 20次机会)");
  console.log("5. 🌀 混沌模式 (完全随机规则)");
  console.log("6. ⏱️ 限时模式 (30秒内完成)");
  console.log("7. 🥷 忍者模式 (5次机会，高惩罚)");
  console.log("8. 🧟 僵尸模式 (分数低但机会多)");
  console.log("9. 🤪 摆烂模式 (1-10, 7次机会)");
  console.log();
  
  const choice = await getUserInput("请选择 [1-9]: ");
  const difficultyMap = {
    "1": "easy", "2": "normal", "3": "hard", 
    "4": "hell", "5": "chaos", "6": "timeattack",
    "7": "ninja", "8": "zombie", "9": "troll"
  };
  
  initGame(difficultyMap[choice] || "easy");
}

function showGameUI() {
  showTitle();
  if (MODE === "timeattack") showTimeRemaining();
  if (MODE === "troll") showTrollUI(); else showNormalUI();
  showModeHints();
}

function showTimeRemaining() {
  const elapsed = Math.floor((Date.now() - START_TIME) / 1000);
  const remaining = TIME_LIMIT - elapsed;
  if (remaining > 0) console.log(`⏱️ 剩余时间: ${remaining} 秒`);
}

function showTrollUI() {
  console.log(`🤪 摆烂模式：猜一个1-10的数字 (还剩 ${MAX_ATTEMPTS - ATTEMPTS} 次机会)`);
  console.log("（这都能输建议卸载游戏）");
}

function showNormalUI() {
  console.log(`猜一个数字 (范围: 1-${RANGE}, 还剩 ${MAX_ATTEMPTS - ATTEMPTS} 次机会)`);
}

function showModeHints() {
  console.log(`当前得分: ${SCORE}`);
  if (PENALTY > 0) console.log(`提示: 每次猜错扣${PENALTY}分`);
  
  switch(MODE) {
    case "chaos": console.log("🌀 混沌模式: 数字可能是负数！"); break;
    case "ninja": console.log("🥷 忍者模式: 高难度挑战！"); break;
    case "zombie": console.log("🧟 僵尸模式: 缓慢但持久！"); break;
  }
  
  console.log("输入 'q' 放弃, 'h' 获取提示(扣10分), 's' 使用特殊技能");
  console.log();
}

async function handleSpecialCommands(guess) {
  if (guess === 'q' || guess === 'quit') {
    showTitle();
    console.log("⚠️ 你选择了放弃游戏！");
    console.log(`正确答案是: ${SECRET_NUMBER}`);
    if (MODE === "troll") {
      console.log("最终得分: -100 (连摆烂模式都放弃？)");
    } else {
      console.log("最终得分: 0 (放弃游戏不计分)");
    }
    console.log();
    await getUserInput("按回车键返回主菜单...");
    return true;
  }
  
  if (guess === 'h' || guess === 'hint') {
    if (SCORE > 10) {
      SCORE -= 10;
      ATTEMPTS++;
      const difference = SECRET_NUMBER - (Math.floor(Math.random() * RANGE) + 1);
      if (difference < 0) {
        console.log(`💡 提示: 数字比 ${SECRET_NUMBER + Math.floor(Math.random() * 100)} 小`);
      } else {
        console.log(`💡 提示: 数字比 ${SECRET_NUMBER - Math.floor(Math.random() * 100)} 大`);
      }
      if (Math.random() < 0.1 && MODE === "chaos") {
        console.log("💥 但是这个提示可能是假的！混沌模式生效！");
      }
      await sleep(2000);
      return true;
    } else {
      console.log("分数不足，无法获取提示！");
      await sleep(1000);
      return true;
    }
  }
  
  if (guess === 's' || guess === 'skill') {
    if (SCORE > 20) {
      SCORE -= 20;
      ATTEMPTS++;
      const skill = Math.floor(Math.random() * 5);
      switch(skill) {
        case 0:
          RANGE = Math.floor(RANGE / 2);
          console.log(`🌟 技能生效！数字范围缩小到1-${RANGE}`);
          break;
        case 1:
          MAX_ATTEMPTS += 3;
          console.log(`🌟 技能生效！获得额外3次机会！`);
          break;
        case 2:
          SCORE += 50;
          console.log(`🌟 技能生效！分数增加50！`);
          break;
        case 3:
          PENALTY = PENALTY > 2 ? PENALTY - 2 : 1;
          console.log(`🌟 技能生效！惩罚减少2分！`);
          break;
        case 4:
          console.log(`🌟 技能生效！直接告诉你数字的奇偶性！`);
          console.log(SECRET_NUMBER % 2 === 0 ? "💡 这是个偶数！" : "💡 这是个奇数！");
          break;
      }
      await sleep(2000);
      return true;
    } else {
      console.log("分数不足，无法使用技能！");
      await sleep(1000);
      return true;
    }
  }
  
  return false;
}

function validateInput(guess) {
  const num = parseInt(guess);
  if (isNaN(num) || num < 1 - RANGE/10 || num > RANGE + RANGE/10) {
    console.log();
    console.log("眼睛不要就捐给有需要的人吧");
    console.log(`请输入1-${RANGE}之间的数字啊！`);
    return false;
  }
  return true;
}

function checkGuess(guess) {
  if (parseInt(guess) === SECRET_NUMBER) {
    showTitle();
    switch(MODE) {
      case "chaos": console.log("🌀🌀🌀 不可思议！你在混沌中找到了答案！"); break;
      case "timeattack": console.log("⏱️⚡ 闪电般的速度！你在时间内完成了挑战！"); break;
      case "ninja": console.log("🥷✨ 忍者般的精准！一击必中！"); break;
      case "zombie": console.log("🧟‍♂️🎉 缓慢但稳定！你最终找到了答案！"); break;
      case "troll": 
        console.log("哇，你可真的是太牛逼了，'宇宙无敌'难度被你通过了");
        console.log(`用了 ${ATTEMPTS} 次尝试猜中了 ${SECRET_NUMBER}`);
        console.log("建议你赶紧截图发朋友圈炫耀！");
        break;
      default: console.log(`🎉 恭喜！你猜对了！数字是 ${SECRET_NUMBER}`);
    }
    
    console.log(`用了 ${ATTEMPTS} 次尝试`);
    
    let finalScore = SCORE;
    if (MODE === "timeattack") {
      const elapsed = Math.floor((Date.now() - START_TIME) / 1000);
      const timeBonus = Math.max(0, TIME_LIMIT - elapsed) * 2;
      finalScore += timeBonus;
      console.log(`时间奖励: +${timeBonus} 分`);
    }
    
    console.log(`最终得分: ${finalScore}`);
    
    if (ATTEMPTS === 1) {
      console.log("评价: 神迹！你一定是开了天眼！");
    } else if (ATTEMPTS <= 3) {
      console.log("评价: 天才！简直不可思议！");
    } else if (ATTEMPTS <= MAX_ATTEMPTS/2) {
      console.log("评价: 优秀！你的直觉很准！");
    } else {
      console.log("评价: 不错！坚持就是胜利！");
    }
    
    if (Math.random() < 0.1) {
      console.log();
      console.log("💫 隐藏结局触发！");
      console.log("这个数字其实还有另一个含义...");
      console.log(`它是宇宙的终极答案的${SECRET_NUMBER % 42}部分！`);
    }
    
    console.log();
    return true;
  }
  return false;
}

function provideFeedback(guess) {
  const num = parseInt(guess);
  if (num < SECRET_NUMBER) {
    const difference = SECRET_NUMBER - num;
    if (difference > RANGE/10) {
      console.log("太小了！差得很远呢！");
    } else if (difference > RANGE/20) {
      console.log("太小了！但已经接近了！");
    } else {
      console.log("非常接近了！只是小了一点点！");
    }
    
    if (Math.random() < 0.05 && MODE === "chaos") {
      console.log("💥 混沌波动！提示反转！其实应该是太大了！");
    }
  } else {
    const difference = num - SECRET_NUMBER;
    if (difference > RANGE/10) {
      console.log("太大了！差得很远呢！");
    } else if (difference > RANGE/20) {
      console.log("太大了！但已经接近了！");
    } else {
      console.log("非常接近了！只是大了一点点！");
    }
    
    if (Math.random() < 0.05 && MODE === "chaos") {
      console.log("💥 混沌波动！提示反转！其实应该是太小了！");
    }
  }
}

function handleSpecialModeEffects() {
  switch(MODE) {
    case "chaos":
      if (Math.random() < 0.1) {
        const oldNumber = SECRET_NUMBER;
        SECRET_NUMBER = Math.floor(Math.random() * RANGE) + 1;
        console.log(`🌀 混沌波动！数字已经改变了！(从 ${oldNumber} 变为 ???)`);
      }
      break;
    case "ninja":
      if (Math.random() < 0.2) {
        MAX_ATTEMPTS--;
        console.log(`🥷 忍者偷袭！剩余机会减少到 ${MAX_ATTEMPTS} 次！`);
      }
      break;
    case "zombie":
      if (Math.random() < 0.1) {
        MAX_ATTEMPTS++;
        console.log(`🧟 僵尸再生！剩余机会增加到 ${MAX_ATTEMPTS} 次！`);
      }
      break;
  }
  
  if (RANGE > 1000 && ATTEMPTS % 3 === 0) {
    let lower = SECRET_NUMBER - Math.floor(RANGE/10);
    let upper = SECRET_NUMBER + Math.floor(RANGE/10);
    lower = lower < 1 ? 1 : lower;
    upper = upper > RANGE ? RANGE : upper;
    console.log(`💡 提示：数字在 ${lower} 到 ${upper} 之间`);
  }
}

function handleGameOver() {
  showTitle();
  switch(MODE) {
    case "chaos": console.log("🌀 混沌吞噬了一切！你失败了！"); break;
    case "timeattack": console.log("⏱️ 时间流逝，机会消失..."); break;
    case "ninja": console.log("🥷 忍者消失在黑暗中..."); break;
    case "zombie": console.log("🧟 僵尸终于倒下了..."); break;
    case "troll":
      console.log("你有实力吗？");
      console.log(`就猜1-10的数字，${MAX_ATTEMPTS} 次机会你都能输？`);
      console.log(`正确答案是: ${SECRET_NUMBER}`);
      console.log();
      console.log("建议：");
      console.log("1. 换个游戏玩");
      console.log("2. 找个班上");
      console.log("3. 反思人生");
      break;
    default: console.log("💀 很遗憾，你没有猜中。");
  }
  
  if (MODE !== "troll") console.log(`正确答案是: ${SECRET_NUMBER}`);
  console.log(`最终得分: ${SCORE}`);
  
  if (MODE !== "troll") {
    console.log();
    console.log("经验总结:");
    if (SCORE > INITIAL_SCORE/2) {
      console.log("表现不错！下次可以尝试更精确的策略。");
    } else {
      console.log("建议使用二分法搜索，能大大提高效率！");
    }
  }
  
  if (Math.random() < 0.1) {
    console.log();
    console.log(`💬 神秘声音: '数字 ${SECRET_NUMBER + 1} 才是真正的答案...'`);
  }
  
  console.log();
}

// 辅助函数
function showTitle() {
  console.clear();
  console.log("========================================");
  console.log(`      猜数字游戏 ${VERSION_NAME}`);
  console.log("========================================");
  console.log();
}

async function getUserInput(prompt) {
  // 浏览器环境
  if (typeof window !== 'undefined') {
    return prompt(prompt);
  }
  // Node.js环境
  else if (typeof process !== 'undefined') {
    const readline = require('readline');
    const rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout
    });
    return new Promise(resolve => {
      rl.question(prompt, answer => {
        rl.close();
        resolve(answer);
      });
    });
  }
  return "";
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// 主入口
async function main() {
  console.log(`猜数字游戏 ${VERSION_NAME} - JavaScript 版本`);
  console.log("========================================");
  console.log();
  
  while (true) {
    console.log("主菜单");
    console.log("1. 开始游戏（选择模式）");
    console.log("2. 关于游戏");
    console.log("0. 退出游戏");
    console.log();
    
    const choice = await getUserInput("请选择 [0-2]: ");
    
    switch(choice) {
      case "1":
        await playGame();
        break;
      case "2":
        showTitle();
        console.log("猜数字游戏 (JavaScript 版本)");
        console.log("从Bash脚本转换而来");
        console.log("原脚本功能完整转换，包括：");
        console.log("• 9种游戏模式");
        console.log("• 混沌随机系统");
        console.log("• 时间限制模式");
        console.log("• 特殊技能系统");
        console.log("• 嘲讽提示和彩蛋");
        console.log();
        await getUserInput("按回车键返回主菜单...");
        break;
      case "0":
        console.log("感谢游玩猜数字游戏！");
        return;
      default:
        console.log("无效选择，请输入0-2之间的数字");
        await sleep(1000);
    }
  }
}

// 启动游戏
if (typeof window !== 'undefined') {
  window.onload = main;
} else {
  main().catch(console.error);
}
