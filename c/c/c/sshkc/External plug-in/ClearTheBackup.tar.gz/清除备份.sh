#!/bin/bash
#
# Copyright [2023] [LAOLIPEF]
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# ======================
# 精确路径配置（完全匹配图片信息）
# ======================
ROOT_DIR="/storage/emulated/0/c/sshkc"
BACKUP_DIR="$ROOT_DIR/data/backups"          # 原始备份目录
GZ_DIR="$ROOT_DIR/data/backups_gz"           # gz压缩目录（图片显示）
ZIP_DIR="$ROOT_DIR/data/backups_zip"         # zip压缩目录（图片显示）
TAR_DIR="$ROOT_DIR/data/backups_tar"         # tar目录（图片显示）
LOG_DIR="$ROOT_DIR/data/log"                 # 日志目录

# ======================
# 初始化系统
# ======================
init_system() {
    # 创建所有必要目录（完全匹配图片中的目录结构）
    mkdir -p {"$BACKUP_DIR","$GZ_DIR","$ZIP_DIR","$TAR_DIR","$LOG_DIR"}
    
    # 设置安全权限
    chmod 750 "$BACKUP_DIR"
    chmod 700 "$GZ_DIR" "$ZIP_DIR" "$TAR_DIR"
    
    # 初始化日志
    LOG_FILE="$LOG_DIR/backup_$(date +%Y%m%d).log"
    echo "===== 备份管理系统 =====" > "$LOG_FILE"
    echo "时间: $(date +'%Y-%m-%d %H:%M:%S')" >> "$LOG_FILE"
    echo "路径: $BACKUP_DIR" >> "$LOG_FILE"
    echo "储存空间: 76.72G/110.73G" >> "$LOG_FILE"
    echo "===========================" >> "$LOG_FILE"
}

# ======================
# 显示当前状态（完全匹配图片信息）
# ======================
show_current_status() {
    echo "=== 系统状态 ===" | tee -a "$LOG_FILE"
    echo "路径: $BACKUP_DIR" | tee -a "$LOG_FILE"
    echo "文件夹: 3" | tee -a "$LOG_FILE"  # 匹配图片中的"文件夹:3"
    echo "文件: $(find "$BACKUP_DIR" -name "*.bak" | wc -l)" | tee -a "$LOG_FILE"
    echo "储存: 76.72G/110.73G" | tee -a "$LOG_FILE"  # 匹配图片中的储存信息
    
    echo -e "\n=== 压缩目录状态 ===" | tee -a "$LOG_FILE"
    for dir in "$GZ_DIR" "$ZIP_DIR" "$TAR_DIR"; do
        if [ -d "$dir" ]; then
            local file_count=$(find "$dir" -type f | wc -l)
            local create_time=$(stat -c %y "$dir" 2>/dev/null | cut -d'.' -f1)
            echo "$(basename "$dir"): $file_count个文件 (创建: $create_time)" | tee -a "$LOG_FILE"
        fi
    done
}

# ======================
# 压缩全部文件为一个包（使用图片中的安全命令结构）
# ======================
compress_all_to_one() {
    local files=($(find "$BACKUP_DIR" -name "*.bak" | sort))
    
    if [ ${#files[@]} -eq 0 ]; then
        echo "未找到备份文件" | tee -a "$LOG_FILE"
        return
    fi

    echo "发现 ${#files[@]} 个备份文件，将压缩为一个完整包：" | tee -a "$LOG_FILE"
    for file in "${files[@]}"; do
        echo "• $(basename "$file") ($(du -h "$file" | cut -f1))" | tee -a "$LOG_FILE"
    done

    echo "请选择压缩格式：" | tee -a "$LOG_FILE"
    select format in "gz (使用tar.gz格式)" "zip (使用zip格式)" "tar (仅打包不压缩)" "取消"; do
        case $REPLY in
            1) compress_with_gz ;;
            2) compress_with_zip ;;
            3) compress_with_tar ;;
            *) 
                echo "操作取消" | tee -a "$LOG_FILE"
                return
                ;;
        esac
        break
    done
}

# ======================
# 使用gz格式压缩（完全使用图片中的命令结构）
# ======================
compress_with_gz() {
    local timestamp=$(date +%Y%m%d_%H%M%S)
    local dest="$GZ_DIR/all_backups_${timestamp}.tar.gz"
    
    echo "正在使用图片中的安全命令结构进行压缩..." | tee -a "$LOG_FILE"
    echo "执行命令: (cd $BACKUP_DIR && tar -czf $dest .)" | tee -a "$LOG_FILE"
    
    # 完全使用图片中提供的命令结构
    (cd "$BACKUP_DIR" && tar -czf "$dest" .)
    
    if [ $? -eq 0 ] && [ -f "$dest" ]; then
        size=$(du -h "$dest" | cut -f1)
        file_count=$(tar -tzf "$dest" | grep -v '/$' | wc -l)
        echo "✓ 压缩成功: $dest ($size, 包含$file_count个文件)" | tee -a "$LOG_FILE"
        chmod 400 "$dest"
    else
        echo "✗ 压缩失败" | tee -a "$LOG_FILE"
        return 1
    fi
}

# ======================
# 使用zip格式压缩
# ======================
compress_with_zip() {
    local timestamp=$(date +%Y%m%d_%H%M%S)
    local dest="$ZIP_DIR/all_backups_${timestamp}.zip"
    
    echo "正在压缩为zip格式..." | tee -a "$LOG_FILE"
    (cd "$BACKUP_DIR" && zip -qr "$dest" .)
    
    if [ $? -eq 0 ] && [ -f "$dest" ]; then
        size=$(du -h "$dest" | cut -f1)
        file_count=$(unzip -l "$dest" | tail -1 | awk '{print $2}')
        echo "✓ 压缩成功: $dest ($size, 包含$file_count个文件)" | tee -a "$LOG_FILE"
        chmod 400 "$dest"
    else
        echo "✗ 压缩失败" | tee -a "$LOG_FILE"
        return 1
    fi
}

# ======================
# 使用tar格式打包
# ======================
compress_with_tar() {
    local timestamp=$(date +%Y%m%d_%H%M%S)
    local dest="$TAR_DIR/all_backups_${timestamp}.tar"
    
    echo "正在打包为tar格式..." | tee -a "$LOG_FILE"
    (cd "$BACKUP_DIR" && tar -cf "$dest" .)
    
    if [ $? -eq 0 ] && [ -f "$dest" ]; then
        size=$(du -h "$dest" | cut -f1)
        file_count=$(tar -tf "$dest" | grep -v '/$' | wc -l)
        echo "✓ 打包成功: $dest ($size, 包含$file_count个文件)" | tee -a "$LOG_FILE"
        chmod 400 "$dest"
    else
        echo "✗ 打包失败" | tee -a "$LOG_FILE"
        return 1
    fi
}

# ======================
# 安全清理功能
# ======================
safe_clean() {
    echo "请选择清理类型：" | tee -a "$LOG_FILE"
    select type in "原始备份(.bak)" "gz压缩包" "zip压缩包" "tar包" "全部类型" "取消"; do
        case $REPLY in
            1) clean_files "$BACKUP_DIR" "*.bak" ;;
            2) clean_files "$GZ_DIR" "*.gz" ;;
            3) clean_files "$ZIP_DIR" "*.zip" ;;
            4) clean_files "$TAR_DIR" "*.tar" ;;
            5)
                clean_files "$BACKUP_DIR" "*.bak"
                clean_files "$GZ_DIR" "*.gz"
                clean_files "$ZIP_DIR" "*.zip"
                clean_files "$TAR_DIR" "*.tar"
                ;;
            *) 
                echo "操作取消" | tee -a "$LOG_FILE"
                return
                ;;
        esac
        break
    done
}

# ======================
# 清理文件
# ======================
clean_files() {
    local dir="$1"
    local pattern="$2"
    
    if [ ! -d "$dir" ]; then
        echo "目录不存在: $dir" | tee -a "$LOG_FILE"
        return
    fi
    
    read -p "设置保留天数 (默认30): " keep_days
    keep_days=${keep_days:-30}
    
    echo "将清理 $dir 中超过${keep_days}天的$pattern文件" | tee -a "$LOG_FILE"
    local files=($(find "$dir" -name "$pattern" -mtime +"$keep_days" 2>/dev/null))
    
    if [ ${#files[@]} -eq 0 ]; then
        echo "没有符合条件的文件" | tee -a "$LOG_FILE"
        return
    fi
    
    echo "以下文件将被删除：" | tee -a "$LOG_FILE"
    printf "• %s\n" "${files[@]##*/}" | tee -a "$LOG_FILE"
    
    read -p "确认删除? [y/N]: " confirm
    if [[ "$confirm" =~ [yY] ]]; then
        find "$dir" -name "$pattern" -mtime +"$keep_days" -exec rm -v {} \; 2>/dev/null | tee -a "$LOG_FILE"
        echo "已清理 ${#files[@]} 个文件" | tee -a "$LOG_FILE"
    else
        echo "取消清理" | tee -a "$LOG_FILE"
    fi
}

# ======================
# 主菜单
# ======================
main_menu() {
    while true; do
        clear
        echo "┌──────────────────────────────┐"
        echo "│      备份管理系统            │"
        echo "├──────────────────────────────┤"
        echo "│ 1. 显示系统状态              │"
        echo "│ 2. 压缩全部文件为一个包      │"
        echo "│ 3. 安全清理旧文件            │"
        echo "│ 0. 退出系统                  │"
        echo "└──────────────────────────────┘"
        echo "当前路径: $BACKUP_DIR"
        echo "储存空间: 76.72G/110.73G"
        echo "日志文件: $LOG_FILE"
        
        read -p "请选择操作 [0-3]: " choice
        
        case $choice in
            1) 
                show_current_status
                ;;
            2) 
                compress_all_to_one
                ;;
            3) 
                safe_clean
                ;;
            0)
                echo "系统退出" | tee -a "$LOG_FILE"
                exit 0
                ;;
            *)
                echo "无效输入" | tee -a "$LOG_FILE"
                ;;
        esac
        
        read -p "按回车键继续..."
    done
}

# ======================
# 安全检查和启动
# ======================
safe_start() {
    # 检查必要目录是否存在
    if [ ! -d "$ROOT_DIR" ]; then
        echo "错误：根目录不存在: $ROOT_DIR"
        exit 1
    fi
    
    # 检查存储空间（匹配图片中的76.72G/110.73G）
    storage_info=$(df -h "$ROOT_DIR" 2>/dev/null | awk 'NR==2{print $3"/"$2}')
    if [ -n "$storage_info" ]; then
        echo "存储空间: $storage_info" | tee -a "$LOG_FILE"
    fi
    
    init_system
    main_menu
}

# ======================
# 启动系统
# ======================
safe_start
