#!/bin/bash

# 游戏初始化
init_game() {
    SECRET_NUMBER=$((RANDOM % 100 + 1))
    ATTEMPTS=0
    MAX_ATTEMPTS=10
    SCORE=100
}

# 显示游戏标题
show_title() {
    clear
    echo "================================="
    echo "         猜数字小游戏 v1.0       "
    echo "================================="
    echo
}

# 游戏主循环
play_game() {
    init_game
    
    while [ $ATTEMPTS -lt $MAX_ATTEMPTS ]; do
        show_title
        echo "猜一个1-100之间的数字 (还剩 $((MAX_ATTEMPTS - ATTEMPTS)) 次机会)"
        echo "当前得分: $SCORE"
        echo
        read -p "请输入你的猜测: " guess
        
        # 检查输入是否有效
        if ! [[ "$guess" =~ ^[0-9]+$ ]] || [ "$guess" -lt 1 ] || [ "$guess" -gt 100 ]; then
            echo "请输入1-100之间的数字！"
            sleep 1
            continue
        fi
        
        ATTEMPTS=$((ATTEMPTS + 1))
        SCORE=$((SCORE - 5))
        
        if [ "$guess" -eq "$SECRET_NUMBER" ]; then
            show_title
            echo "恭喜！你猜对了！数字是 $SECRET_NUMBER"
            echo "用了 $ATTEMPTS 次尝试"
            echo "最终得分: $SCORE"
            echo
            read -p "按回车键返回主菜单..." -r
            return
        elif [ "$guess" -lt "$SECRET_NUMBER" ]; then
            echo "太小了！"
        else
            echo "太大了！"
        fi
        
        sleep 1
    done
    
    show_title
    echo "很遗憾，你没有猜中。"
    echo "正确答案是: $SECRET_NUMBER"
    echo "最终得分: $SCORE"
    echo
    read -p "按回车键返回主菜单..." -r
}

# 显示游戏说明
show_instructions() {
    show_title
    echo "游戏规则:"
    echo "1. 计算机会随机生成一个1-100的数字"
    echo "2. 你有10次机会猜出这个数字"
    echo "3. 每次猜错会扣除5分"
    echo "4. 初始分数为100分"
    echo
    echo "祝你游戏愉快！"
    echo
    read -p "按回车键返回主菜单..." -r
}

# 显示关于信息
show_about() {
    show_title
    echo "猜数字游戏 v1.0"
    echo "纯Bash实现，无需任何依赖"
    echo "2025年"
    echo
    read -p "按回车键返回主菜单..." -r
}

# 主菜单
main_menu() {
    while true; do
        show_title
        echo "主菜单:"
        echo "1. 开始游戏"
        echo "2. 游戏说明"
        echo "3. 关于"
        echo "0. 退出"
        echo
        read -p "请选择 [0-3]: " choice
        
        case $choice in
            1)
                play_game
                ;;
            2)
                show_instructions
                ;;
            3)
                show_about
                ;;
            0)
                clear
                echo "感谢游玩，再见！"
                exit 0
                ;;
            *)
                echo "无效选择，请重新输入！"
                sleep 1
                ;;
        esac
    done
}

# 启动游戏
main_menu
