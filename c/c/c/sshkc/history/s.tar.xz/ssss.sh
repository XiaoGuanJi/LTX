#!/bin/bash

# ======================
# 版本控制系统
# ======================
SCRIPT_NAME=$(basename "$0")
VERSION=$(($(echo "$SCRIPT_NAME" | tr -dc 'sS' | wc -c)))
VERSION_NAME="ULTRA v${VERSION}.$(date +%Y%m%d)"

# ======================
# 目录结构配置
# ======================
SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)
LOG_DIR="$SCRIPT_DIR/data/log"
mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/game_$(date +%Y%m%d).log"

# ======================
# 全局变量
# ======================
GAME_COUNT=0
SECRET_NUMBER=0
ATTEMPTS=0
SCORE=0
START_TIME=0
RANGE=100
MAX_ATTEMPTS=10
INITIAL_SCORE=100
PENALTY=5
MODE="normal"
TIME_LIMIT=30

# ======================
# 初始化函数
# ======================
init_log() {
    mkdir -p "$LOG_DIR"
    echo "======================================" >> "$LOG_FILE"
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] 猜数字游戏 $VERSION_NAME 启动" >> "$LOG_FILE"
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] 日志目录: $LOG_DIR" >> "$LOG_FILE"
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] 设备信息: $(uname -a)" >> "$LOG_FILE"
    echo "======================================" >> "$LOG_FILE"
}

log() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] $1" >> "$LOG_FILE"
}

init_game() {
    local difficulty=$1
    log "初始化游戏，难度: $difficulty"
    
    case $difficulty in
        "easy") init_normal 100 10 100 5 ;;
        "normal") init_normal 100 8 100 5 ;;
        "hard") init_normal 1000 15 150 5 ;;
        "hell") init_normal 10000 20 200 3 ;;
        "chaos") init_chaos ;;
        "timeattack") init_timeattack ;;
        "ninja") init_ninja ;;
        "zombie") init_zombie ;;
        "troll") init_troll ;;
        *) init_normal 100 10 100 5 ;;
    esac
    
    SECRET_NUMBER=$((RANDOM % RANGE + 1))
    ATTEMPTS=0
    SCORE=$INITIAL_SCORE
    START_TIME=$(date +%s)
}

# ======================
# 游戏模式初始化
# ======================
init_normal() {
    RANGE=$1; MAX_ATTEMPTS=$2
    INITIAL_SCORE=$3; PENALTY=$4
    MODE="normal"
}

init_chaos() {
    RANGE=$((RANDOM % 9900 + 100))
    MAX_ATTEMPTS=$((RANDOM % 15 + 5))
    INITIAL_SCORE=$((RANDOM % 150 + 50))
    PENALTY=$((RANDOM % 7 + 3))
    MODE="chaos"
}

init_timeattack() {
    RANGE=100; MAX_ATTEMPTS=999
    INITIAL_SCORE=100; PENALTY=0
    TIME_LIMIT=30; MODE="timeattack"
}

init_ninja() {
    RANGE=100; MAX_ATTEMPTS=5
    INITIAL_SCORE=200; PENALTY=20
    MODE="ninja"
}

init_zombie() {
    RANGE=100; MAX_ATTEMPTS=15
    INITIAL_SCORE=50; PENALTY=2
    MODE="zombie"
}

init_troll() {
    RANGE=10; MAX_ATTEMPTS=7
    INITIAL_SCORE=50; PENALTY=0
    MODE="troll"
}

# ======================
# 显示函数
# ======================
show_title() {
    clear
    echo "========================================"
    echo "      猜数字游戏 $VERSION_NAME"
    echo "  不可能模式 · 混沌挑战 · 终极体验"
    echo "========================================"
    echo
}

show_game_ui() {
    show_title
    [ "$MODE" == "timeattack" ] && show_time_remaining
    [ "$MODE" == "troll" ] && show_troll_ui || show_normal_ui
    show_mode_hints
}

show_time_remaining() {
    CURRENT_TIME=$(date +%s)
    ELAPSED=$((CURRENT_TIME - START_TIME))
    REMAINING=$((TIME_LIMIT - ELAPSED))
    [ $REMAINING -le 0 ] && return
    echo "⏱️ 剩余时间: $REMAINING 秒"
}

show_troll_ui() {
    echo "🤪 摆烂模式：猜一个1-10的数字 (还剩 $((MAX_ATTEMPTS - ATTEMPTS)) 次机会)"
    echo "（这都能输建议卸载游戏）"
}

show_normal_ui() {
    echo "猜一个数字 (范围: 1-$RANGE, 还剩 $((MAX_ATTEMPTS - ATTEMPTS)) 次机会)"
}

show_mode_hints() {
    echo "当前得分: $SCORE"
    [ "$PENALTY" -gt 0 ] && echo "提示: 每次猜错扣${PENALTY}分"
    
    case $MODE in
        "chaos") echo "🌀 混沌模式: 数字可能是负数！";;
        "ninja") echo "🥷 忍者模式: 高难度挑战！";;
        "zombie") echo "🧟 僵尸模式: 缓慢但持久！";;
    esac
    
    echo "输入 'q' 放弃, 'h' 获取提示(扣10分), 's' 使用特殊技能"
    echo
}

# ======================
# 游戏核心逻辑
# ======================
play_game() {
    select_difficulty
    log "开始新游戏，模式: $MODE, 范围: 1-$RANGE"
    
    while [ $ATTEMPTS -lt $MAX_ATTEMPTS ]; do
        show_game_ui
        
        read -p "请输入你的选择: " guess
        handle_special_commands && continue
        
        validate_input || continue
        
        ATTEMPTS=$((ATTEMPTS + 1))
        SCORE=$((SCORE - PENALTY))
        
        check_guess && return
        
        provide_feedback
        handle_special_mode_effects
        sleep 1
    done
    
    handle_game_over
}

handle_special_commands() {
    case $guess in
        q|quit)
            show_title
            echo "⚠️ 你选择了放弃游戏！"
            echo "正确答案是: $SECRET_NUMBER"
            if [ "$MODE" == "troll" ]; then
                echo "最终得分: -100 (连摆烂模式都放弃？)"
            else
                echo "最终得分: 0 (放弃游戏不计分)"
            fi
            echo
            read -p "按回车键返回主菜单..." -r
            return 0
            ;;
        h|hint)
            if [ $SCORE -gt 10 ]; then
                SCORE=$((SCORE - 10))
                ATTEMPTS=$((ATTEMPTS + 1))
                difference=$((SECRET_NUMBER - (RANDOM % RANGE + 1)))
                if [ $difference -lt 0 ]; then
                    echo "💡 提示: 数字比 $(($SECRET_NUMBER + (RANDOM % 100))) 小"
                else
                    echo "💡 提示: 数字比 $(($SECRET_NUMBER - (RANDOM % 100))) 大"
                fi
                if [ $((RANDOM % 10)) -eq 0 ]; then
                    echo "💥 但是这个提示可能是假的！混沌模式生效！"
                fi
                sleep 2
                return 0
            else
                echo "分数不足，无法获取提示！"
                sleep 1
                return 0
            fi
            ;;
        s|skill)
            if [ $SCORE -gt 20 ]; then
                SCORE=$((SCORE - 20))
                ATTEMPTS=$((ATTEMPTS + 1))
                special_effects
                case $((RANDOM % 5)) in
                    0) 
                        echo "🌟 技能生效！数字范围缩小到1-$((RANGE/2))"
                        RANGE=$((RANGE/2))
                        ;;
                    1)
                        echo "🌟 技能生效！获得额外3次机会！"
                        MAX_ATTEMPTS=$((MAX_ATTEMPTS + 3))
                        ;;
                    2)
                        echo "🌟 技能生效！分数增加50！"
                        SCORE=$((SCORE + 50))
                        ;;
                    3)
                        echo "🌟 技能生效！惩罚减少2分！"
                        PENALTY=$((PENALTY > 2 ? PENALTY - 2 : 1))
                        ;;
                    4)
                        echo "🌟 技能生效！直接告诉你数字的奇偶性！"
                        if [ $((SECRET_NUMBER % 2)) -eq 0 ]; then
                            echo "💡 这是个偶数！"
                        else
                            echo "💡 这是个奇数！"
                        fi
                        ;;
                esac
                sleep 2
                return 0
            else
                echo "分数不足，无法使用技能！"
                sleep 1
                return 0
            fi
            ;;
    esac
    return 1
}

validate_input() {
    if ! [[ "$guess" =~ ^-?[0-9]+$ ]] || [ "$guess" -lt $((1-RANGE/10)) ] || [ "$guess" -gt $((RANGE+RANGE/10)) ]; then
        echo
        echo "眼睛不要就捐给有需要的人吧"
        echo "请输入1-$RANGE之间的数字啊！"
        sleep 2
        return 1
    fi
    return 0
}

check_guess() {
    if [ "$guess" -eq "$SECRET_NUMBER" ]; then
        show_title
        case $MODE in
            "chaos") echo "🌀🌀🌀 不可思议！你在混沌中找到了答案！";;
            "timeattack") echo "⏱️⚡ 闪电般的速度！你在时间内完成了挑战！";;
            "ninja") echo "🥷✨ 忍者般的精准！一击必中！";;
            "zombie") echo "🧟‍♂️🎉 缓慢但稳定！你最终找到了答案！";;
            "troll") 
                echo "哇，你可真的是太牛逼了，"宇宙无敌"难度被你通过了"
                echo "用了 $ATTEMPTS 次尝试猜中了 $SECRET_NUMBER"
                echo "建议你赶紧截图发朋友圈炫耀！"
                ;;
            *) echo "🎉 恭喜！你猜对了！数字是 $SECRET_NUMBER";;
        esac
        
        echo "用了 $ATTEMPTS 次尝试"
        
        FINAL_SCORE=$SCORE
        if [ "$MODE" == "timeattack" ]; then
            TIME_BONUS=$((REMAINING * 2))
            FINAL_SCORE=$((SCORE + TIME_BONUS))
            echo "时间奖励: +$TIME_BONUS 分"
        fi
        
        echo "最终得分: $FINAL_SCORE"
        
        if [ $ATTEMPTS -eq 1 ]; then
            echo "评价: 神迹！你一定是开了天眼！"
        elif [ $ATTEMPTS -le 3 ]; then
            echo "评价: 天才！简直不可思议！"
        elif [ $ATTEMPTS -le $((MAX_ATTEMPTS/2)) ]; then
            echo "评价: 优秀！你的直觉很准！"
        else
            echo "评价: 不错！坚持就是胜利！"
        fi
        
        if [ $((RANDOM % 10)) -eq 0 ]; then
            echo
            echo "💫 隐藏结局触发！"
            echo "这个数字其实还有另一个含义..."
            echo "它是宇宙的终极答案的$(($SECRET_NUMBER % 42))部分！"
        fi
        
        echo
        read -p "按回车键返回主菜单..." -r
        return 0
    fi
    return 1
}

provide_feedback() {
    if [ "$guess" -lt "$SECRET_NUMBER" ]; then
        difference=$((SECRET_NUMBER - guess))
        if [ $difference -gt $((RANGE/10)) ]; then
            echo "太小了！差得很远呢！"
        elif [ $difference -gt $((RANGE/20)) ]; then
            echo "太小了！但已经接近了！"
        else
            echo "非常接近了！只是小了一点点！"
        fi
        
        if [ $((RANDOM % 20)) -eq 0 ] && [ "$MODE" == "chaos" ]; then
            echo "💥 混沌波动！提示反转！其实应该是太大了！"
        fi
    else
        difference=$((guess - SECRET_NUMBER))
        if [ $difference -gt $((RANGE/10)) ]; then
            echo "太大了！差得很远呢！"
        elif [ $difference -gt $((RANGE/20)) ]; then
            echo "太大了！但已经接近了！"
        else
            echo "非常接近了！只是大了一点点！"
        fi
        
        if [ $((RANDOM % 20)) -eq 0 ] && [ "$MODE" == "chaos" ]; then
            echo "💥 混沌波动！提示反转！其实应该是太小了！"
        fi
    fi
}

handle_special_mode_effects() {
    case $MODE in
        "chaos")
            if [ $((RANDOM % 10)) -eq 0 ]; then
                OLD_NUMBER=$SECRET_NUMBER
                SECRET_NUMBER=$((RANDOM % RANGE + 1))
                echo "🌀 混沌波动！数字已经改变了！(从 $OLD_NUMBER 变为 ???)"
            fi
            ;;
        "ninja")
            if [ $((RANDOM % 5)) -eq 0 ]; then
                MAX_ATTEMPTS=$((MAX_ATTEMPTS - 1))
                echo "🥷 忍者偷袭！剩余机会减少到 $MAX_ATTEMPTS 次！"
            fi
            ;;
        "zombie")
            if [ $((RANDOM % 10)) -eq 0 ]; then
                MAX_ATTEMPTS=$((MAX_ATTEMPTS + 1))
                echo "🧟 僵尸再生！剩余机会增加到 $MAX_ATTEMPTS 次！"
            fi
            ;;
    esac
    
    if [ "$RANGE" -gt 1000 ] && [ $((ATTEMPTS % 3)) -eq 0 ]; then
        lower_bound=$((SECRET_NUMBER - RANGE/10))
        upper_bound=$((SECRET_NUMBER + RANGE/10))
        [ $lower_bound -lt 1 ] && lower_bound=1
        [ $upper_bound -gt $RANGE ] && upper_bound=$RANGE
        echo "💡 提示：数字在 $lower_bound 到 $upper_bound 之间"
    fi
}

handle_game_over() {
    show_title
    case $MODE in
        "chaos") echo "🌀 混沌吞噬了一切！你失败了！";;
        "timeattack") echo "⏱️ 时间流逝，机会消失...";;
        "ninja") echo "🥷 忍者消失在黑暗中...";;
        "zombie") echo "🧟 僵尸终于倒下了...";;
        "troll")
            echo "你有实力吗？"
            echo "就猜1-10的数字，$MAX_ATTEMPTS 次机会你都能输？"
            echo "正确答案是: $SECRET_NUMBER"
            echo
            echo "建议："
            echo "1. 换个游戏玩"
            echo "2. 找个班上"
            echo "3. 反思人生"
            ;;
        *) echo "💀 很遗憾，你没有猜中。";;
    esac
    
    [ "$MODE" != "troll" ] && echo "正确答案是: $SECRET_NUMBER"
    echo "最终得分: $SCORE"
    
    if [ "$MODE" != "troll" ]; then
        echo
        echo "经验总结:"
        if [ $SCORE -gt $((INITIAL_SCORE/2)) ]; then
            echo "表现不错！下次可以尝试更精确的策略。"
        else
            echo "建议使用二分法搜索，能大大提高效率！"
        fi
    fi
    
    if [ $((RANDOM % 10)) -eq 0 ]; then
        echo
        echo "💬 神秘声音: '数字 $(($SECRET_NUMBER + 1)) 才是真正的答案...'"
    fi
    
    echo
    read -p "按回车键返回主菜单..." -r
}

# ======================
# 计算器功能
# ======================
calculator() {
    log "用户进入计算器功能"
    show_title
    echo "🖩 游戏内置计算器 (真爱粉专享)"
    echo "支持运算: + - * / % ^ (指数) √ (平方根)"
    echo "示例: 2+3*4, √25, 3^4"
    echo "输入 'q' 返回主菜单"
    echo
    
    while true; do
        read -p "输入表达式: " expr
        
        if [[ "$expr" == "q" || "$expr" == "quit" ]]; then
            log "用户退出计算器"
            return
        fi
        
        # 1+1彩蛋
        if [[ "$expr" == "1+1" ]]; then
            echo
            echo "我不知道你是真傻还是假傻，我建议你小学一年级回炉重造"
            echo "这么简单的问题也要用计算器？答案是2啊！"
            echo
            log "用户尝试计算1+1，触发彩蛋"
            sleep 2
            continue
        fi
        
        # 除零彩蛋
        if [[ "$expr" == *"/0"* || "$expr" == *"/ 0"* ]]; then
            echo "💥 再乱玩就炸给你看"
            echo "数学老师没教过你不能除以零吗？！"
            log "用户尝试除以零，触发彩蛋"
            sleep 2
            continue
        fi
        
        # 正常计算
        expr=${expr//√/sqrt}
        result=$(echo "scale=4; $expr" | bc -l 2>/dev/null)
        
        if [ -z "$result" ]; then
            echo "无效的数学表达式！"
            echo "眼睛不要就捐给有需要的人吧"
            log "用户输入无效表达式: $expr"
            sleep 1
        else
            result=$(echo "$result" | sed -e 's/\.0*$//' -e 's/\.$//')
            echo "结果: $result"
            log "计算: $expr = $result"
        fi
    done
}

calculator_entrance() {
    show_title
    echo "果然是作者的真爱粉，计算数学都要用到我"
    echo
    echo "如果我没说错的话，你的手机上也有计算器的吧？"
    echo "这里建议你还是用图形化的计算器，防止你老眼昏花没看见"
    echo
    echo "如果真的想用，就得答对我一个问题："
    read -p "计算器的英语怎么说？(输入'不知道'可以退出): " answer
    
    case $answer in
        calculator|Calculator|CALCULATOR)
            echo
            echo "✅ 回答正确！看来你英语不错嘛~"
            log "用户答对计算器验证问题"
            sleep 1
            calculator
            ;;
        不知道)
            echo
            echo "你还是先去学英语吧"
            echo "建议搜索：'计算器 英文'"
            log "用户放弃计算器验证"
            sleep 2
            return
            ;;
        *)
            echo
            echo "眼睛不要就捐给有需要的人吧"
            echo "这么简单都不会？是 'calculator' 啊！"
            log "用户答错计算器验证问题"
            echo
            echo "给你最后一次机会："
            read -p "计算器的英语怎么说？(拼写要完全正确): " answer2
            
            if [[ "$answer2" == "calculator" ]]; then
                echo
                echo "🎉 终于答对了！勉强让你用吧"
                sleep 1
                calculator
            else
                echo
                echo "💔 连这都不会，还是别用计算器了"
                echo "正确答案是：calculator"
                sleep 2
            fi
            ;;
    esac
}

# ======================
# 菜单函数
# ======================
select_difficulty() {
    show_title
    echo "请选择游戏模式:"
    echo "1. 简单模式 (1-100, 10次机会)"
    echo "2. 普通模式 (1-100, 8次机会)" 
    echo "3. 困难模式 (1-1000, 15次机会)"
    echo "4. 地狱模式 (1-10000, 20次机会)"
    echo "5. 🌀 混沌模式 (完全随机规则)"
    echo "6. ⏱️ 限时模式 (30秒内完成)"
    echo "7. 🥷 忍者模式 (5次机会，高惩罚)"
    echo "8. 🧟 僵尸模式 (分数低但机会多)"
    echo "9. 🤪 摆烂模式 (1-10, 7次机会)"
    echo
    read -p "请选择 [1-9]: " difficulty_choice

    case $difficulty_choice in
        1) 
            echo "已选择：简单模式"
            init_game "easy"
            ;;
        2) 
            echo "已选择：普通模式" 
            init_game "normal"
            ;;
        3)
            echo "已选择：困难模式 - 挑战1000以内的数字！"
            init_game "hard"
            ;;
        4)
            echo "已选择：地狱模式 - 挑战10000以内的数字，祝你好运！"
            init_game "hell"
            ;;
        5)
            echo "🌀 已选择：混沌模式 - 规则完全随机！"
            init_game "chaos"
            ;;
        6)
            echo "⏱️ 已选择：限时模式 - 30秒内完成挑战！"
            init_game "timeattack"
            ;;
        7)
            echo "🥷 已选择：忍者模式 - 只有5次机会，但高分奖励！"
            init_game "ninja"
            ;;
        8)
            echo "🧟 已选择：僵尸模式 - 缓慢但持久！"
            init_game "zombie"
            ;;
        9)
            echo "🤪 已选择：摆烂模式 - 这都能输建议卸载游戏！"
            init_game "troll"
            ;;
        *) 
            echo
            echo "眼睛不要就捐给有需要的人吧"
            echo "请看清楚选项是1-9啊！"
            sleep 2
            echo "使用默认简单模式"
            init_game "easy"
            ;;
    esac
    sleep 1
}

show_instructions() {
    show_title
    echo "🎯 游戏规则:"
    echo "1. 根据模式不同，计算机将生成不同范围的数字"
    echo "2. 你有有限次机会或时间猜出这个数字"
    echo "3. 每次猜错会扣除一定分数"
    echo "4. 猜对后根据表现计算最终得分"
    echo "5. 特殊命令:"
    echo "   - q/quit: 放弃游戏"
    echo "   - h/hint: 花费10分获取提示"
    echo "   - s/skill: 花费20分使用特殊技能"
    echo
    echo "🎮 游戏模式:"
    echo "• 简单模式: 经典玩法"
    echo "• 普通模式: 增加挑战"
    echo "• 困难模式: 更大数字范围"
    echo "• 地狱模式: 极限挑战"
    echo "• 🌀 混沌模式: 完全随机规则，数字可能变化"
    echo "• ⏱️ 限时模式: 30秒内完成挑战"
    echo "• 🥷 忍者模式: 机会少但高分奖励"
    echo "• 🧟 僵尸模式: 机会多但分数增长慢"
    echo "• 🤪 摆烂模式: 1-10的数字，7次机会，输了别哭"
    echo
    echo "🛠️ 额外功能:"
    echo "• 🖩 真爱粉专用计算器 (需要答对问题解锁)"
    echo "• 隐藏彩蛋和特殊结局"
    echo
    read -p "按回车键返回主菜单..." -r
}

show_about() {
    show_title
    echo "猜数字游戏 $VERSION_NAME"
    echo "🎯 终极特性:"
    echo "• 9种独特游戏模式"
    echo "• 混沌随机系统"
    echo "• 限时挑战"
    echo "• 特殊技能系统"
    echo "• 🖩 真爱粉计算器"
    echo "• 🤪 摆烂人生模式"
    echo "• 👀 嘲讽提示系统"
    echo "• 💫 隐藏内容和彩蛋"
    echo "• 📝 完整日志系统"
    echo
    echo "纯Bash实现的终极挑战"
    echo "2025年 - 不可能版本"
    echo
    read -p "按回车键返回主菜单..." -r
}

special_effects() {
    case $((RANDOM % 10)) in
        0) echo "✨ 魔法光芒一闪而过...";;
        1) echo "💥 空间似乎扭曲了一下...";;
        2) echo "🌪️ 一阵神秘的风吹过...";;
        3) echo "🔮 水晶球发出微弱的光芒...";;
        4) echo "👻 你感觉有什么在看着你...";;
        5) echo "🤪 系统对你翻了个白眼...";;
        6) echo "🙈 猴子偷走了你的眼镜...";;
        7) echo "🦄 独角兽表示很失望...";;
    esac
}

# ======================
# 主菜单
# ======================
main_menu() {
    while true; do
        show_title
        echo "主菜单:"
        echo "1. 开始游戏（选择模式）"
        echo "2. 游戏说明"  
        echo "3. 关于 $VERSION_NAME"
        echo "4. 🖩 计算器工具 (真爱粉专享)"
        echo "0. 退出游戏"
        echo
        read -p "请选择 [0-4]: " choice
        
        case $choice in
            1)
                play_game
                GAME_COUNT=$((GAME_COUNT + 1))
                ;;
            2)
                show_instructions
                ;;
            3)
                show_about
                ;;
            4)
                calculator_entrance
                ;;
            0)
                clear
                if [ $GAME_COUNT -eq 0 ]; then
                    echo "你不玩进来干啥呀？"
                    sleep 1
                    echo "好吧，那再见咯~"
                else
                    echo "感谢游玩猜数字游戏 $VERSION_NAME！"
                    echo "你本次共玩了 $GAME_COUNT 局游戏"
                    echo "欢迎下次再来挑战！"
                fi
                exit 0
                ;;
            *)
                echo
                echo "眼睛不要就捐给有需要的人吧"
                echo "请看清楚选项是0-4啊！"
                sleep 2
                ;;
        esac
    done
}

# ======================
# 启动游戏
# ======================
init_log
main_menu
