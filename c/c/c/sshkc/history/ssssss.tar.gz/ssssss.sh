#!/bin/bash
#!/bin/bash
#
# Copyright [2023] [LAOLIPEF]
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# ======================
# 版本控制系统
# ======================
SCRIPT_NAME=$(basename "$0")
VERSION=$(($(echo "$SCRIPT_NAME" | tr -dc 'sS' | wc -c)))
VERSION_NAME="ULTRA v${VERSION}.$(date +%Y%m%d)"

# ======================
# 目录结构配置
# ======================
SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)
DATA_ROOT="/storage/emulated/0/c/sshkc"
LOG_DIR="$DATA_ROOT/data/log"
MODS_DIR="$DATA_ROOT/mods"
SYSTEM_DIR="$DATA_ROOT/system"
DATA_DIR="$DATA_ROOT/data"
ETC_DIR="$DATA_ROOT/data/etc"
TIME_DIR="$DATA_ROOT/data/etc/time"
mkdir -p "$LOG_DIR" "$MODS_DIR" "$SYSTEM_DIR" "$DATA_DIR" "$ETC_DIR" "$TIME_DIR"
LOG_FILE="$LOG_DIR/game_$(date +%Y%m%d).log"

# ======================
# Visit.lt 配置路径
# ======================
USER_VISIT="$MODS_DIR/Visit.lt"
SYS_VISIT="$SYSTEM_DIR/Visit.lt"
BACKUP_DIR="$DATA_DIR/backups"
mkdir -p "$BACKUP_DIR"

# ======================
# 全局变量
# ======================
GAME_COUNT=0
SECRET_NUMBER=0
ATTEMPTS=0
SCORE=0
START_TIME=0
RANGE=100
MAX_ATTEMPTS=10
INITIAL_SCORE=100
PENALTY=5
MODE="normal"
TIME_LIMIT=30

# 文件路径
FIRST_RUN_FILE="$TIME_DIR/first_run.date"
NICKNAME_FILE="$ETC_DIR/nickname.txt"
GAME_COUNT_FILE="$TIME_DIR/game_count.txt"
RECENT_PLAYS_FILE="$TIME_DIR/recent_plays.log"
SESSION_LOG_FILE="$TIME_DIR/session.log"
GAME_TIME_FILE="$TIME_DIR/total_time.txt"
LAUNCH_COUNT_FILE="$TIME_DIR/launch_count.txt"
LAST_PLAY_FILE="$TIME_DIR/last_play.date"

# 时间上限常量
MAX_GAME_TIME=$((70 * 365 * 24 * 3600))  # 70年
WARNING_THRESHOLD=$((60 * 365 * 24 * 3600))  # 60年警告

# ======================
# 初始化函数
# ======================
init_log() {
    mkdir -p "$LOG_DIR" "$ETC_DIR" "$TIME_DIR"
    echo "======================================" >> "$LOG_FILE"
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] 猜数字游戏 $VERSION_NAME 启动" >> "$LOG_FILE"
    
    # 初始化所有记录文件
    [ ! -f "$GAME_COUNT_FILE" ] && echo "0" > "$GAME_COUNT_FILE"
    [ ! -f "$GAME_TIME_FILE" ] && echo "0" > "$GAME_TIME_FILE"
    [ ! -f "$LAUNCH_COUNT_FILE" ] && echo "0" > "$LAUNCH_COUNT_FILE"
    [ ! -f "$RECENT_PLAYS_FILE" ] && touch "$RECENT_PLAYS_FILE"
    [ ! -f "$FIRST_RUN_FILE" ] && date +%Y-%m-%d > "$FIRST_RUN_FILE"
    
    # 增加启动次数
    local launch_count=$(( $(cat "$LAUNCH_COUNT_FILE") + 1 ))
    echo "$launch_count" > "$LAUNCH_COUNT_FILE"
    
    # 记录本次启动
    echo "$(date +%Y-%m-%d_%H:%M:%S)" >> "$RECENT_PLAYS_FILE"
    
    # 记录会话开始时间
    SESSION_START_TIME=$(date +%s)
    
    # 更新上次游玩时间
    date +%Y-%m-%d > "$LAST_PLAY_FILE"
    
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] 正在验证系统配置..." >> "$LOG_FILE"
    
    if ! validate_visit_config; then
        echo "[$(date +"%Y-%m-%d %H:%M:%S")] 警告：使用默认配置启动" >> "$LOG_FILE"
    fi
    
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] 设备信息: $(uname -a)" >> "$LOG_FILE"
    echo "======================================" >> "$LOG_FILE"
}

# ======================
# Visit.lt 验证系统
# ======================
validate_visit_config() {
    # 确保系统默认配置存在
    [ ! -f "$SYS_VISIT" ] && generate_default_visit_config
    
    # 检查用户配置
    if [ -f "$USER_VISIT" ]; then
        if validate_config_file "$USER_VISIT"; then
            log "用户Visit.lt配置验证通过"
            return 0
        else
            log "用户配置验证失败，恢复默认"
            backup_invalid_config
            cp "$SYS_VISIT" "$USER_VISIT"
            return 1
        fi
    else
        log "未找到用户配置，创建默认"
        cp "$SYS_VISIT" "$USER_VISIT"
        return 0
    fi
}

validate_config_file() {
    local config_file="$1"
    [ ! -f "$config_file" ] && return 1
    
    # 关键字段检查
    local required_fields=("MOD_LOAD_ORDER" "MOD_EVENTS")
    for field in "${required_fields[@]}"; do
        if ! grep -q "^$field=" "$config_file"; then
            log "缺少必需字段: $field"
            return 2
        fi
    done
    
    # 记录文件大小但不限制
    local file_size=$(stat -c %s "$config_file")
    log "配置文件大小: $file_size 字节 (无限制)"
    
    return 0
}

generate_default_visit_config() {
    cat > "$SYS_VISIT" <<EOF
# ======================
# Visit.lt 默认配置
# ======================
CONFIG_VERSION="3"

# 核心系统
MOD_SYSTEM_ENABLED=true
MOD_DEBUG_MODE=false
MOD_LOG_LEVEL="info"

# 模组管理
MOD_LOAD_ORDER="SystemAchievement,CoreExtensions"
MOD_EVENTS="ON_GAME_START,ON_GAME_END"

# 安全设置
MOD_SIGNATURE_REQUIRED=true
MAX_MOD_THREADS=4

# 文件大小设置 (无限制)
MAX_CONFIG_SIZE="unlimited"
EOF
}

backup_invalid_config() {
    local timestamp=$(date +%Y%m%d_%H%M%S)
    local backup_file="$BACKUP_DIR/Visit_$timestamp.bak"
    mkdir -p "$BACKUP_DIR"
    cp "$USER_VISIT" "$backup_file"
    log "已备份无效配置到: $backup_file"
}

# ======================
# 日志函数
# ======================
log() {
    local message="$1"
    local level="${2:-INFO}"
    local color="\033[0m"
    
    case $level in
        ERROR) color="\033[31m" ;;
        WARN) color="\033[33m" ;;
        DEBUG) color="\033[36m" ;;
    esac
    
    echo -e "${color}[$(date +'%Y-%m-%d %H:%M:%S')] [$level] $message\033[0m" | tee -a "$LOG_FILE"
}

# ======================
# 游戏初始化
# ======================
init_game() {
    local difficulty=$1
    log "初始化游戏，难度: $difficulty"
    
    # 加载Visit.lt配置
    source "$USER_VISIT" 2>/dev/null || {
        log "ERROR" "加载Visit.lt配置失败"
        return 1
    }
    
    case $difficulty in
        "easy") init_normal 100 10 100 5 ;;
        "normal") init_normal 100 8 100 5 ;;
        "hard") init_normal 1000 15 150 5 ;;
        "hell") init_normal 10000 20 200 3 ;;
        "chaos") init_chaos ;;
        "timeattack") init_timeattack ;;
        "ninja") init_ninja ;;
        "zombie") init_zombie ;;
        "troll") init_troll ;;
        *) init_normal 100 10 100 5 ;;
    esac
    
    SECRET_NUMBER=$((RANDOM % RANGE + 1))
    ATTEMPTS=0
    SCORE=$INITIAL_SCORE
    START_TIME=$(date +%s)
}

init_normal() {
    RANGE=$1; MAX_ATTEMPTS=$2
    INITIAL_SCORE=$3; PENALTY=$4
    MODE="normal"
}

init_chaos() {
    RANGE=$((RANDOM % 9900 + 100))
    MAX_ATTEMPTS=$((RANDOM % 15 + 5))
    INITIAL_SCORE=$((RANDOM % 150 + 50))
    PENALTY=$((RANDOM % 7 + 3))
    MODE="chaos"
}

init_timeattack() {
    RANGE=100; MAX_ATTEMPTS=999
    INITIAL_SCORE=100; PENALTY=0
    TIME_LIMIT=30; MODE="timeattack"
}

init_ninja() {
    RANGE=100; MAX_ATTEMPTS=5
    INITIAL_SCORE=200; PENALTY=20
    MODE="ninja"
}

init_zombie() {
    RANGE=100; MAX_ATTEMPTS=15
    INITIAL_SCORE=50; PENALTY=2
    MODE="zombie"
}

init_troll() {
    RANGE=10; MAX_ATTEMPTS=7
    INITIAL_SCORE=50; PENALTY=0
    MODE="troll"
}

# ======================
# 游戏核心逻辑
# ======================
play_game() {
    select_difficulty
    log "开始新游戏，模式: $MODE, 范围: 1-$RANGE"
    
    while [ $ATTEMPTS -lt $MAX_ATTEMPTS ]; do
        show_game_ui
        
        read -p "请输入你的选择: " guess
        handle_special_commands && continue
        
        validate_input || continue
        
        ATTEMPTS=$((ATTEMPTS + 1))
        SCORE=$((SCORE - PENALTY))
        
        check_guess && return
        
        provide_feedback
        handle_special_mode_effects
        sleep 1
    done
    
    handle_game_over
}

select_difficulty() {
    show_title
    echo "请选择游戏模式:"
    echo "1. 简单模式 (1-100, 10次机会)"
    echo "2. 普通模式 (1-100, 8次机会)" 
    echo "3. 困难模式 (1-1000, 15次机会)"
    echo "4. 地狱模式 (1-10000, 20次机会)"
    echo "5. 🌀 混沌模式 (完全随机规则)"
    echo "6. ⏱️ 限时模式 (30秒内完成)"
    echo "7. 🥷 忍者模式 (5次机会，高惩罚)"
    echo "8. 🧟 僵尸模式 (分数低但机会多)"
    echo "9. 🤪 摆烂模式 (1-10, 7次机会)"
    echo
    read -p "请选择 [1-9]: " difficulty_choice

    case $difficulty_choice in
        1) init_game "easy" ;;
        2) init_game "normal" ;;
        3) init_game "hard" ;;
        4) init_game "hell" ;;
        5) init_game "chaos" ;;
        6) init_game "timeattack" ;;
        7) init_game "ninja" ;;
        8) init_game "zombie" ;;
        9) init_game "troll" ;;
        *) 
            echo "使用默认简单模式"
            init_game "easy" 
            ;;
    esac
}

show_game_ui() {
    show_title
    [ "$MODE" == "timeattack" ] && show_time_remaining
    [ "$MODE" == "troll" ] && show_troll_ui || show_normal_ui
    show_mode_hints
}

show_time_remaining() {
    local current_time=$(date +%s)
    local elapsed=$((current_time - START_TIME))
    local remaining=$((TIME_LIMIT - elapsed))
    [ $remaining -le 0 ] && return
    echo "⏱️ 剩余时间: $remaining 秒"
}

show_troll_ui() {
    echo "🤪 摆烂模式：猜一个1-10的数字 (还剩 $((MAX_ATTEMPTS - ATTEMPTS)) 次机会)"
    echo "（这都能输建议卸载游戏）"
}

show_normal_ui() {
    echo "猜一个数字 (范围: 1-$RANGE, 还剩 $((MAX_ATTEMPTS - ATTEMPTS)) 次机会)"
}

show_mode_hints() {
    echo "当前得分: $SCORE"
    [ "$PENALTY" -gt 0 ] && echo "提示: 每次猜错扣${PENALTY}分"
    
    case $MODE in
        "chaos") echo "🌀 混沌模式: 数字可能是负数！";;
        "ninja") echo "🥷 忍者模式: 高难度挑战！";;
        "zombie") echo "🧟 僵尸模式: 缓慢但持久！";;
    esac
    
    echo "输入 'q' 放弃, 'h' 获取提示(扣10分), 's' 使用特殊技能"
    echo
}

handle_special_commands() {
    case $guess in
        q|quit)
            show_title
            echo "⚠️ 你选择了放弃游戏！"
            echo "正确答案是: $SECRET_NUMBER"
            if [ "$MODE" == "troll" ]; then
                echo "最终得分: -100 (连摆烂模式都放弃？)"
            else
                echo "最终得分: 0 (放弃游戏不计分)"
            fi
            echo
            read -p "按回车键返回主菜单..." -r
            return 0
            ;;
        h|hint)
            if [ $SCORE -gt 10 ]; then
                SCORE=$((SCORE - 10))
                ATTEMPTS=$((ATTEMPTS + 1))
                difference=$((SECRET_NUMBER - (RANDOM % RANGE + 1)))
                if [ $difference -lt 0 ]; then
                    echo "💡 提示: 数字比 $(($SECRET_NUMBER + (RANDOM % 100))) 小"
                else
                    echo "💡 提示: 数字比 $(($SECRET_NUMBER - (RANDOM % 100))) 大"
                fi
                if [ $((RANDOM % 10)) -eq 0 ] && [ "$MODE" == "chaos" ]; then
                    echo "💥 但是这个提示可能是假的！混沌模式生效！"
                fi
                sleep 2
                return 0
            else
                echo "分数不足，无法获取提示！"
                sleep 1
                return 0
            fi
            ;;
        s|skill)
            if [ $SCORE -gt 20 ]; then
                SCORE=$((SCORE - 20))
                ATTEMPTS=$((ATTEMPTS + 1))
                special_effects
                case $((RANDOM % 5)) in
                    0) 
                        echo "🌟 技能生效！数字范围缩小到1-$((RANGE/2))"
                        RANGE=$((RANGE/2))
                        ;;
                    1)
                        echo "🌟 技能生效！获得额外3次机会！"
                        MAX_ATTEMPTS=$((MAX_ATTEMPTS + 3))
                        ;;
                    2)
                        echo "🌟 技能生效！分数增加50！"
                        SCORE=$((SCORE + 50))
                        ;;
                    3)
                        echo "🌟 技能生效！惩罚减少2分！"
                        PENALTY=$((PENALTY > 2 ? PENALTY - 2 : 1))
                        ;;
                    4)
                        echo "🌟 技能生效！直接告诉你数字的奇偶性！"
                        if [ $((SECRET_NUMBER % 2)) -eq 0 ]; then
                            echo "💡 这是个偶数！"
                        else
                            echo "💡 这是个奇数！"
                        fi
                        ;;
                esac
                sleep 2
                return 0
            else
                echo "分数不足，无法使用技能！"
                sleep 1
                return 0
            fi
            ;;
    esac
    return 1
}

validate_input() {
    if ! [[ "$guess" =~ ^-?[0-9]+$ ]] || [ "$guess" -lt $((1-RANGE/10)) ] || [ "$guess" -gt $((RANGE+RANGE/10)) ]; then
        echo
        echo "眼睛不要就捐给有需要的人吧"
        echo "请输入1-$RANGE之间的数字啊！"
        sleep 2
        return 1
    fi
    return 0
}

check_guess() {
    if [ "$guess" -eq "$SECRET_NUMBER" ]; then
        show_title
        case $MODE in
            "chaos") echo "🌀🌀🌀 不可思议！你在混沌中找到了答案！";;
            "timeattack") echo "⏱️⚡ 闪电般的速度！你在时间内完成了挑战！";;
            "ninja") echo "🥷✨ 忍者般的精准！一击必中！";;
            "zombie") echo "🧟‍♂️🎉 缓慢但稳定！你最终找到了答案！";;
            "troll") 
                echo "哇，你可真的是太牛逼了，"宇宙无敌"难度被你通过了"
                echo "用了 $ATTEMPTS 次尝试猜中了 $SECRET_NUMBER"
                echo "建议你赶紧截图发朋友圈炫耀！"
                ;;
            *) echo "🎉 恭喜！你猜对了！数字是 $SECRET_NUMBER";;
        esac
        
        echo "用了 $ATTEMPTS 次尝试"
        
        FINAL_SCORE=$SCORE
        if [ "$MODE" == "timeattack" ]; then
            TIME_BONUS=$((REMAINING * 2))
            FINAL_SCORE=$((SCORE + TIME_BONUS))
            echo "时间奖励: +$TIME_BONUS 分"
        fi
        
        echo "最终得分: $FINAL_SCORE"
        
        if [ $ATTEMPTS -eq 1 ]; then
            echo "评价: 神迹！你一定是开了天眼！"
        elif [ $ATTEMPTS -le 3 ]; then
            echo "评价: 天才！简直不可思议！"
        elif [ $ATTEMPTS -le $((MAX_ATTEMPTS/2)) ]; then
            echo "评价: 优秀！你的直觉很准！"
        else
            echo "评价: 不错！坚持就是胜利！"
        fi
        
        if [ $((RANDOM % 10)) -eq 0 ]; then
            echo
            echo "💫 隐藏结局触发！"
            echo "这个数字其实还有另一个含义..."
            echo "它是宇宙的终极答案的$(($SECRET_NUMBER % 42))部分！"
        fi
        
        echo
        read -p "按回车键返回主菜单..." -r
        return 0
    fi
    return 1
}

provide_feedback() {
    if [ "$guess" -lt "$SECRET_NUMBER" ]; then
        difference=$((SECRET_NUMBER - guess))
        if [ $difference -gt $((RANGE/10)) ]; then
            echo "太小了！差得很远呢！"
        elif [ $difference -gt $((RANGE/20)) ]; then
            echo "太小了！但已经接近了！"
        else
            echo "非常接近了！只是小了一点点！"
        fi
        
        if [ $((RANDOM % 20)) -eq 0 ] && [ "$MODE" == "chaos" ]; then
            echo "💥 混沌波动！提示反转！其实应该是太大了！"
        fi
    else
        difference=$((guess - SECRET_NUMBER))
        if [ $difference -gt $((RANGE/10)) ]; then
            echo "太大了！差得很远呢！"
        elif [ $difference -gt $((RANGE/20)) ]; then
            echo "太大了！但已经接近了！"
        else
            echo "非常接近了！只是大了一点点！"
        fi
        
        if [ $((RANDOM % 20)) -eq 0 ] && [ "$MODE" == "chaos" ]; then
            echo "💥 混沌波动！提示反转！其实应该是太小了！"
        fi
    fi
}

handle_special_mode_effects() {
    case $MODE in
        "chaos")
            if [ $((RANDOM % 10)) -eq 0 ]; then
                OLD_NUMBER=$SECRET_NUMBER
                SECRET_NUMBER=$((RANDOM % RANGE + 1))
                echo "🌀 混沌波动！数字已经改变了！(从 $OLD_NUMBER 变为 ???)"
            fi
            ;;
        "ninja")
            if [ $((RANDOM % 5)) -eq 0 ]; then
                MAX_ATTEMPTS=$((MAX_ATTEMPTS - 1))
                echo "🥷 忍者偷袭！剩余机会减少到 $MAX_ATTEMPTS 次！"
            fi
            ;;
        "zombie")
            if [ $((RANDOM % 10)) -eq 0 ]; then
                MAX_ATTEMPTS=$((MAX_ATTEMPTS + 1))
                echo "🧟 僵尸再生！剩余机会增加到 $MAX_ATTEMPTS 次！"
            fi
            ;;
    esac
    
    if [ "$RANGE" -gt 1000 ] && [ $((ATTEMPTS % 3)) -eq 0 ]; then
        lower_bound=$((SECRET_NUMBER - RANGE/10))
        upper_bound=$((SECRET_NUMBER + RANGE/10))
        [ $lower_bound -lt 1 ] && lower_bound=1
        [ $upper_bound -gt $RANGE ] && upper_bound=$RANGE
        echo "💡 提示：数字在 $lower_bound 到 $upper_bound 之间"
    fi
}

handle_game_over() {
    show_title
    case $MODE in
        "chaos") echo "🌀 混沌吞噬了一切！你失败了！";;
        "timeattack") echo "⏱️ 时间流逝，机会消失...";;
        "ninja") echo "🥷 忍者消失在黑暗中...";;
        "zombie") echo "🧟 僵尸终于倒下了...";;
        "troll")
            echo "你有实力吗？"
            echo "就猜1-10的数字，$MAX_ATTEMPTS 次机会你都能输？"
            echo "正确答案是: $SECRET_NUMBER"
            echo
            echo "建议："
            echo "1. 换个游戏玩"
            echo "2. 找个班上"
            echo "3. 反思人生"
            ;;
        *) echo "💀 很遗憾，你没有猜中。";;
    esac
    
    [ "$MODE" != "troll" ] && echo "正确答案是: $SECRET_NUMBER"
    echo "最终得分: $SCORE"
    
    if [ "$MODE" != "troll" ]; then
        echo
        echo "经验总结:"
        if [ $SCORE -gt $((INITIAL_SCORE/2)) ]; then
            echo "表现不错！下次可以尝试更精确的策略。"
        else
            echo "建议使用二分法搜索，能大大提高效率！"
        fi
    fi
    
    if [ $((RANDOM % 10)) -eq 0 ]; then
        echo
        echo "💬 神秘声音: '数字 $(($SECRET_NUMBER + 1)) 才是真正的答案...'"
    fi
    
    echo
    read -p "按回车键返回主菜单..." -r
}

# ======================
# 游戏时间记录
# ======================
record_game_time() {
    local end_time=$(date +%s)
    local duration=$((end_time - START_TIME))
    local total_time=$(( $(cat "$GAME_TIME_FILE") + duration ))
    
    echo "$total_time" > "$GAME_TIME_FILE"
    LAST_GAME_DURATION=$duration
    
    # 记录详细游戏会话
    echo "$(date +%Y-%m-%d_%H:%M:%S),$MODE,$duration,$ATTEMPTS,$SCORE" >> "$SESSION_LOG_FILE"
}

# ======================
# 时间上限检测
# ======================
check_game_time_limit() {
    local total_time=$(cat "$GAME_TIME_FILE")
    
    if [ "$total_time" -ge "$MAX_GAME_TIME" ]; then
        echo "⏳ 时间奇迹：你已经达到了70年游戏时间上限！"
        echo
        echo "这是一个不可思议的里程碑！"
        echo "70年的游戏时间，相当于一个人的整个生命周期！"
        echo
        echo "你已经超越了游戏的界限，"
        echo "成为了数字世界永恒的存在。"
        echo
        echo "作为奖励，你将获得："
        echo "🌟 永恒数字大师称号"
        echo "🔮 无限游戏特权"
        echo "💎 所有数字对你来说都是透明的"
        echo
        echo "感谢你一生的陪伴！"
        sleep 5
        return 1
    elif [ "$total_time" -ge "$WARNING_THRESHOLD" ]; then
        local years_played=$((total_time / (365 * 24 * 3600)))
        local years_left=$((70 - years_played))
        
        echo "⚠️ 时间提醒：你已经玩了$years_played年！"
        echo
        echo "距离70年游戏时间上限还有$years_left年。"
        echo
        echo "你知道吗？70年是大多数人类的平均寿命，"
        echo "而你几乎将一生都献给了这个数字游戏！"
        echo
        echo "这究竟是执着还是热爱？"
        echo "无论如何，你的坚持令人敬佩！"
        sleep 3
    fi
    return 0
}

# ======================
# 永恒模式
# ======================
show_eternal_menu() {
    while true; do
        show_title
        echo "🌟 永恒数字大师菜单 🌟"
        echo "============================"
        echo "你已经超越了时间的界限！"
        echo "累计游戏时间: 70年+"
        echo
        echo "1. 继续数字之旅"
        echo "2. 查看永恒成就"
        echo "3. 数字宇宙探索"
        echo "0. 退出永恒"
        echo
        
        read -p "请选择 [0-3]: " choice
        
        case $choice in
            1)
                play_eternal_game
                ;;
            2)
                show_eternal_achievements
                ;;
            3)
                explore_digital_universe
                ;;
            0)
                echo
                echo "即使你选择离开，你的传奇也将永远留在这里。"
                echo "再见了，永恒的数字大师！"
                sleep 2
                exit 0
                ;;
            *)
                echo
                echo "以你70年的游戏经验，应该知道要选0-3吧？"
                sleep 1
                ;;
        esac
    done
}

play_eternal_game() {
    RANGE=999999999999999999
    SECRET_NUMBER=$((RANDOM % RANGE + 1))
    ATTEMPTS=0
    SCORE=999999999
    
    while true; do
        show_title
        echo "♾️ 永恒模式 - 数字宇宙终极挑战"
        echo "============================"
        echo "目标: 猜出1-${RANGE}之间的数字"
        echo "提示: 这个数字跨越时空维度"
        echo
        
        read -p "输入你的宇宙级猜测 (或q退出): " guess
        
        if [[ "$guess" == "q" ]]; then
            return
        fi
        
        if ! [[ "$guess" =~ ^[0-9]+$ ]]; then
            echo
            echo "以你70年的经验，应该知道要输入数字吧？"
            sleep 1
            continue
        fi
        
        ATTEMPTS=$((ATTEMPTS + 1))
        
        if [ "$guess" -eq "$SECRET_NUMBER" ]; then
            echo
            echo "🌠 宇宙真理揭示！"
            echo "你找到了终极数字: $SECRET_NUMBER"
            echo "用时: $ATTEMPTS 次尝试"
            echo
            echo "这个数字包含了宇宙的所有奥秘..."
            sleep 3
            return
        elif [ "$guess" -lt "$SECRET_NUMBER" ]; then
            echo "太小了！这个数字横跨多个星系！"
        else
            echo "太大了！这个数字超越了时空维度！"
        fi
        
        sleep 1
    done
}

show_eternal_achievements() {
    show_title
    echo "🌟 永恒数字大师成就 🌟"
    echo "============================"
    echo "1. 70年游戏时间 - 生命的全部"
    echo "2. 超越时间限制 - 永恒存在"
    echo "3. 数字宇宙主宰 - 掌控一切"
    echo "4. 无限耐心勋章 - 永不放弃"
    echo "5. 时空旅行者 - 穿梭数字维度"
    echo
    echo "你已经解锁了所有可能的成就！"
    echo
    read -p "按回车键返回..." -r
}

explore_digital_universe() {
    show_title
    echo "🌌 数字宇宙探索"
    echo "============================"
    echo "作为永恒数字大师，你可以："
    echo "1. 观察数字的诞生"
    echo "2. 追踪数字的轨迹"
    echo "3. 预测数字的未来"
    echo "4. 创造新的数字"
    echo
    echo "选择你要进行的探索:"
    
    read -p "请输入选项 [1-4]: " choice
    
    case $choice in
        1)
            echo
            echo "你见证了数字0和1的量子纠缠..."
            echo "它们结合产生了所有其他数字！"
            ;;
        2)
            echo
            echo "你追踪了数字7的轨迹..."
            echo "发现它穿越了12个维度！"
            ;;
        3)
            echo
            echo "你预测了数字42的未来..."
            echo "它将在31415926年后成为宇宙的答案！"
            ;;
        4)
            echo
            echo "你创造了新的数字∞..."
            echo "它立即吞噬了周围的数字空间！"
            ;;
        *)
            echo
            echo "无效的选择，永恒的大师也会犯错呢..."
            ;;
    esac
    
    sleep 2
}

# ======================
# 数字格式化函数
# ======================
format_number() {
    local num=$1
    if [ "$num" -ge 1000000000 ]; then
        printf "%d,%03d,%03d,%03d" $((num/1000000000)) $(( (num/1000000)%1000 )) $(( (num/1000)%1000 )) $((num%1000))
    elif [ "$num" -ge 1000000 ]; then
        printf "%d,%03d,%03d" $((num/1000000)) $(( (num/1000)%1000 )) $((num%1000))
    elif [ "$num" -ge 1000 ]; then
        printf "%d,%03d" $((num/1000)) $((num%1000))
    else
        echo "$num"
    fi
}

format_duration() {
    local seconds=$1
    local days=$((seconds / 86400))
    local hours=$(( (seconds % 86400) / 3600 ))
    local minutes=$(( (seconds % 3600) / 60 ))
    local secs=$((seconds % 60))
    
    if [ "$days" -gt 0 ]; then
        printf "%d天%02d小时%02d分钟%02d秒" "$days" "$hours" "$minutes" "$secs"
    elif [ "$hours" -gt 0 ]; then
        printf "%d小时%02d分钟%02d秒" "$hours" "$minutes" "$secs"
    elif [ "$minutes" -gt 0 ]; then
        printf "%d分钟%02d秒" "$minutes" "$secs"
    else
        printf "%d秒" "$secs"
    fi
}

# ======================
# 欢迎信息函数
# ======================
show_welcome_message() {
    local total_time=$(cat "$GAME_TIME_FILE")
    local launch_count=$(cat "$LAUNCH_COUNT_FILE")
    local total_games=$(cat "$GAME_COUNT_FILE")
    local nickname=$(get_nickname)
    local today=$(date +%m-%d)
    local hour=$(date +%H)
    
    clear
    echo "========================================"
    echo "      猜数字游戏 $VERSION_NAME"
    echo "========================================"
    echo
    
    # 70年特别问候
    if [ "$total_time" -ge "$MAX_GAME_TIME" ]; then
        echo "♾️ 永恒的数字大师，欢迎归来！"
        echo
        echo "时间对你已经失去了意义，"
        echo "你与数字的羁绊超越了时空界限。"
        echo
        echo "今天要探索数字宇宙的哪个角落呢？"
        sleep 3
        return
    fi
    
    # 启动次数里程碑
    if [ "$launch_count" -eq 1 ]; then
        echo "✨ 欢迎初次体验猜数字游戏！"
        echo "希望你喜欢这个数字世界！"
    elif [ "$launch_count" -eq 10 ]; then
        echo "🎯 第10次启动！开始熟悉这个游戏了！"
    elif [ "$launch_count" -eq 100 ]; then
        echo "🏆 第100次启动！你真是忠实玩家！"
    elif [ "$launch_count" -eq 1000 ]; then
        echo "🌟 第1000次启动！这个游戏已经成为你生活的一部分了！"
    elif [ "$launch_count" -eq 10000 ]; then
        echo "🚀 第10000次启动！万次启动成就达成！"
    elif [ "$launch_count" -eq 100000 ]; then
        echo "🌈 第100000次启动！十万次启动里程碑！"
    elif [ "$launch_count" -eq 1000000 ]; then
        echo "👑 第1000000次启动！百万次启动传奇！"
    elif [ "$launch_count" -eq 10000000 ]; then
        echo "🌌 第10000000次启动！千万次启动奇迹！"
    elif [ "$launch_count" -eq 100000000 ]; then
        echo "♾️ 第100000000次启动！亿次启动永恒！"
    else
        echo "📊 游戏统计:"
        echo "启动次数: $(format_number $launch_count)次"
        echo "累计游戏: $(format_number $total_games)局"
        echo "游戏时间: $(format_duration $total_time)"
    fi
    
    # 幽默提示
    if [ "$launch_count" -ge 1000 ]; then
        case $((RANDOM % 5)) in
            0) echo "（你确定不是把启动游戏当成了呼吸吗？）";;
            1) echo "（这个游戏是不是你的桌面背景？）";;
            2) echo "（你的手指还记得其他应用吗？）";;
            3) echo "（要不要考虑给这个游戏写个传记？）";;
            4) echo "（我猜你的手机里只有这个游戏吧？）";;
        esac
    fi
    
    echo
    read -p "按回车键继续..." -r
}

# ======================
# 游戏成就查看功能
# ======================
show_game_achievements() {
    local total_games=$(cat "$GAME_COUNT_FILE")
    local total_time=$(cat "$GAME_TIME_FILE")
    local launch_count=$(cat "$LAUNCH_COUNT_FILE")
    local first_run=$(cat "$FIRST_RUN_FILE")
    
    show_title
    echo "🎖️ 游戏成就系统"
    echo "============================"
    echo "存储路径: $TIME_DIR"
    echo "启动次数: $(format_number $launch_count)次"
    echo "累计游戏: $(format_number $total_games)局"
    echo "游戏时间: $(format_duration $total_time)"
    echo "初次游玩: $first_run"
    echo "最近游玩: $(date +%Y-%m-%d)"
    echo
    
    echo "已达成成就:"
    if [ "$launch_count" -ge 10 ]; then echo "✅ 熟悉的面孔 - 启动10次"; fi
    if [ "$launch_count" -ge 100 ]; then echo "✅ 忠实玩家 - 启动100次"; fi
    if [ "$launch_count" -ge 1000 ]; then echo "✅ 游戏伙伴 - 启动1000次"; fi
    if [ "$launch_count" -ge 10000 ]; then echo "✅ 启动达人 - 启动10000次"; fi
    if [ "$launch_count" -ge 100000 ]; then echo "✅ 启动大师 - 启动100000次"; fi
    if [ "$launch_count" -ge 1000000 ]; then echo "✅ 启动传奇 - 启动1000000次"; fi
    if [ "$launch_count" -ge 10000000 ]; then echo "✅ 启动之神 - 启动10000000次"; fi
    if [ "$launch_count" -ge 100000000 ]; then echo "✅ 启动永恒 - 启动100000000次"; fi
    if [ "$total_games" -ge 10 ]; then echo "✅ 数字探险家 - 完成10局游戏"; fi
    if [ "$total_games" -ge 50 ]; then echo "✅ 数字大师 - 完成50局游戏"; fi
    if [ "$total_games" -ge 100 ]; then echo "✅ 数字传奇 - 完成100局游戏"; fi
    if [ "$total_games" -ge 1000 ]; then echo "✅ 数字狂热者 - 完成1000局游戏"; fi
    if [ "$total_games" -ge 10000 ]; then echo "✅ 数字专家 - 完成10000局游戏"; fi
    if [ "$total_games" -ge 100000 ]; then echo "✅ 数字之王 - 完成100000局游戏"; fi
    if [ "$total_games" -ge 1000000 ]; then echo "✅ 数字主宰 - 完成1000000局游戏"; fi
    if [ "$total_games" -ge 10000000 ]; then echo "✅ 数字之神 - 完成10000000局游戏"; fi
    if [ "$total_games" -ge 100000000 ]; then echo "✅ 数字永恒 - 完成100000000局游戏"; fi
    if [ "$total_time" -ge 3600 ]; then echo "✅ 时间投入者 - 总游戏时间超过1小时"; fi
    if [ "$total_time" -ge 36000 ]; then echo "✅ 时间大师 - 总游戏时间超过10小时"; fi
    if [ "$total_time" -ge 86400 ]; then echo "✅ 时间传奇 - 总游戏时间超过24小时"; fi
    if [ "$total_time" -ge 604800 ]; then echo "✅ 时间领主 - 总游戏时间超过1周"; fi
    
    echo
    echo "即将达成:"
    if [ "$launch_count" -lt 10 ]; then
        echo "🔜 熟悉的面孔 - 还需 $((10 - launch_count)) 次启动"
    elif [ "$launch_count" -lt 100 ]; then
        echo "🔜 忠实玩家 - 还需 $((100 - launch_count)) 次启动"
    elif [ "$launch_count" -lt 1000 ]; then
        echo "🔜 游戏伙伴 - 还需 $((1000 - launch_count)) 次启动"
    elif [ "$launch_count" -lt 10000 ]; then
        echo "🔜 启动达人 - 还需 $((10000 - launch_count)) 次启动"
    elif [ "$launch_count" -lt 100000 ]; then
        echo "🔜 启动大师 - 还需 $((100000 - launch_count)) 次启动"
    elif [ "$launch_count" -lt 1000000 ]; then
        echo "🔜 启动传奇 - 还需 $((1000000 - launch_count)) 次启动"
    elif [ "$launch_count" -lt 10000000 ]; then
        echo "🔜 启动之神 - 还需 $((10000000 - launch_count)) 次启动"
    elif [ "$launch_count" -lt 100000000 ]; then
        echo "🔜 启动永恒 - 还需 $((100000000 - launch_count)) 次启动"
    else
        echo "🌟 你已经达成了所有启动次数成就！"
    fi
    
    echo
    read -p "按回车键返回主菜单..." -r
}

# ======================
# 主菜单
# ======================
main_menu() {
    local total_games=$(cat "$GAME_COUNT_FILE")
    local total_time=$(cat "$GAME_TIME_FILE")
    local launch_count=$(cat "$LAUNCH_COUNT_FILE")
    
    # 检查游戏时间上限
    if ! check_game_time_limit; then
        show_eternal_menu
        return
    fi
    
    # 显示欢迎信息
    show_welcome_message

    while true; do
        show_title
        echo "主菜单 (启动: ${launch_count}次 | 游戏: ${total_games}局 | 时长: $(format_duration $total_time))"
        echo "1. 开始游戏（选择模式）"
        echo "2. 游戏成就"  
        echo "3. 关于 $VERSION_NAME"
        echo "4. 计算器工具"
        echo "5. 检查系统配置"
        echo "0. 退出游戏"
        echo
        
        read -p "请选择 [0-5]: " choice
        
        case $choice in
            1)
                play_game
                total_games=$((total_games + 1))
                echo "$total_games" > "$GAME_COUNT_FILE"
                ;;
            2)
                show_game_achievements
                ;;
            3)
                show_about
                ;;
            4)
                calculator_entrance
                ;;
            5)
                check_system_config
                ;;
            0)
                clear
                if [ $total_games -eq 0 ]; then
                    echo "你不玩进来干啥呀？"
                    sleep 1
                    echo "好吧，那再见咯~"
                else
                    local nickname=$(get_nickname)
                    if [ -n "$nickname" ]; then
                        echo "再见，$nickname！欢迎下次再来玩！"
                    else
                        echo "感谢游玩猜数字游戏 $VERSION_NAME！"
                    fi
                    echo "你本次共玩了 $GAME_COUNT 局游戏"
                fi
                exit 0
                ;;
            *)
                echo
                echo "眼睛不要就捐给有需要的人吧"
                echo "请看清楚选项是0-5啊！"
                sleep 2
                ;;
        esac
    done
}

# ======================
# 关于信息
# ======================
show_about() {
    show_title
    echo "猜数字游戏 $VERSION_NAME"
    echo "🎯 终极特性:"
    echo "• 9种独特游戏模式"
    echo "• 混沌随机系统"
    echo "• 限时挑战"
    echo "• 特殊技能系统"
    echo "• 🖩 真爱粉计算器"
    echo "• 🤪 摆烂人生模式"
    echo "• 👀 嘲讽提示系统"
    echo "• 💫 隐藏内容和彩蛋"
    echo "• 📝 完整日志系统"
    echo
    echo "纯Bash实现的终极挑战"
    echo "2025年 - 不可能版本"
    echo
    read -p "按回车键返回主菜单..." -r
}

# ======================
# 系统配置检查
# ======================
check_system_config() {
    show_title
    echo "🔍 系统配置检查"
    echo "============================"
    echo "配置版本: $(get_config_version "$USER_VISIT")"
    echo "系统版本: $(get_config_version "$SYS_VISIT")"
    echo "存储路径: $TIME_DIR"
    echo
    echo "游戏记录:"
    echo "启动次数: $(format_number $(cat "$LAUNCH_COUNT_FILE"))次"
    echo "游戏次数: $(format_number $(cat "$GAME_COUNT_FILE"))局"
    echo "游戏时间: $(format_duration $(cat "$GAME_TIME_FILE"))"
    echo
    echo "配置文件大小: $(stat -c %s "$USER_VISIT") 字节 (无限制)"
    echo "============================"
    read -p "按回车键返回主菜单..." -r
}

get_config_version() {
    local config_file="$1"
    grep "^CONFIG_VERSION=" "$config_file" | cut -d'=' -f2 | tr -d '"' || echo "未知"
}

# ======================
# 计算器功能
# ======================
calculator_entrance() {
    show_title
    echo "果然是作者的真爱粉，计算数学都要用到我"
    echo
    echo "如果我没说错的话，你的手机上也有计算器的吧？"
    echo "这里建议你还是用图形化的计算器，防止你老眼昏花没看见"
    echo
    echo "如果真的想用，就得答对我一个问题："
    read -p "计算器的英语怎么说？(输入'不知道'可以退出): " answer
    
    case $answer in
        calculator|Calculator|CALCULATOR)
            echo
            echo "✅ 回答正确！看来你英语不错嘛~"
            sleep 1
            calculator
            ;;
        不知道)
            echo
            echo "你还是先去学英语吧"
            echo "建议搜索：'计算器 英文'"
            sleep 2
            return
            ;;
        *)
            echo
            echo "眼睛不要就捐给有需要的人吧"
            echo "这么简单都不会？是 'calculator' 啊！"
            echo
            echo "给你最后一次机会："
            read -p "计算器的英语怎么说？(拼写要完全正确): " answer2
            
            if [[ "$answer2" == "calculator" ]]; then
                echo
                echo "🎉 终于答对了！勉强让你用吧"
                sleep 1
                calculator
            else
                echo
                echo "💔 连这都不会，还是别用计算器了"
                echo "正确答案是：calculator"
                sleep 2
            fi
            ;;
    esac
}

calculator() {
    log "用户进入计算器功能"
    show_title
    echo "🖩 游戏内置计算器 (真爱粉专享)"
    echo "支持运算: + - * / % ^ (指数) √ (平方根)"
    echo "示例: 2+3*4, √25, 3^4"
    echo "输入 'q' 返回主菜单"
    echo
    
    while true; do
        read -p "输入表达式: " expr
        
        if [[ "$expr" == "q" || "$expr" == "quit" ]]; then
            log "用户退出计算器"
            return
        fi
        
        # 1+1彩蛋
        if [[ "$expr" == "1+1" ]]; then
            echo
            echo "我不知道你是真傻还是假傻，我建议你小学一年级回炉重造"
            echo "这么简单的问题也要用计算器？答案是2啊！"
            echo
            log "用户尝试计算1+1，触发彩蛋"
            sleep 2
            continue
        fi
        
        # 除零彩蛋
        if [[ "$expr" == *"/0"* || "$expr" == *"/ 0"* ]]; then
            echo "再乱玩就炸给你看"
            echo "数学老师没教过你不能除以零吗？！"
            log "用户尝试除以零，触发彩蛋"
            sleep 2
            continue
        fi
        
        # 正常计算
        expr=${expr//√/sqrt}
        result=$(echo "scale=4; $expr" | bc -l 2>/dev/null)
        
        if [ -z "$result" ]; then
            echo "无效的数学表达式！"
            echo "眼睛不要就捐给有需要的人吧"
            log "用户输入无效表达式: $expr"
            sleep 1
        else
            result=$(echo "$result" | sed -e 's/\.0*$//' -e 's/\.$//')
            echo "结果: $result"
            log "计算: $expr = $result"
        fi
    done
}

# ======================
# 获取昵称
# ======================
get_nickname() {
    [ -f "$NICKNAME_FILE" ] && cat "$NICKNAME_FILE" || echo ""
}

# ======================
# 设置昵称
# ======================
set_nickname() {
    read -p "请输入你的昵称: " nickname
    if [ -n "$nickname" ]; then
        echo "$nickname" > "$NICKNAME_FILE"
        echo "好的，$nickname，我会记住你的！"
        sleep 1
    fi
}

# ======================
# 计算相识天数
# ======================
calculate_days_together() {
    [ ! -f "$FIRST_RUN_FILE" ] && echo 0 && return
    
    local first_run=$(cat "$FIRST_RUN_FILE")
    local today=$(date +%Y-%m-%d)
    echo $(( ($(date -d "$today" +%s) - $(date -d "$first_run" +%s)) / 86400 ))
}

# ======================
# 启动游戏
# ======================
init_log
main_menu
