// lstdio.h - 轻量级标准输入输出库
#ifndef L_STDIO_H
#define L_STDIO_H

// ============ 系统定义 ============
// 系统调用号（Linux ARM64）
#define L_SYS_WRITE   64
#define L_SYS_READ    63
#define L_SYS_EXIT    93
#define L_SYS_BRK     214
#define L_SYS_OPENAT  56
#define L_SYS_CLOSE   57
#define L_SYS_LSEEK   62
#define L_SYS_GETPID  172
#define L_SYS_TIME    113
#define L_SYS_NANOSLEEP 101

// 文件描述符
#define L_STDIN_FILENO   0
#define L_STDOUT_FILENO  1
#define L_STDERR_FILENO  2

// 文件打开标志
#define L_O_RDONLY    00
#define L_O_WRONLY    01
#define L_O_RDWR      02
#define L_O_CREAT     0100
#define L_O_TRUNC     01000
#define L_O_APPEND    02000

// 错误码
#define L_SUCCESS     0
#define L_EOF        -1
#define L_ERROR      -2
#define L_ENOMEM     -3
#define L_EINVAL     -4
#define L_ENOENT     -5

// 颜色代码
#define L_COLOR_BLACK   0
#define L_COLOR_RED     1
#define L_COLOR_GREEN   2
#define L_COLOR_YELLOW  3
#define L_COLOR_BLUE    4
#define L_COLOR_MAGENTA 5
#define L_COLOR_CYAN    6
#define L_COLOR_WHITE   7
#define L_COLOR_BRIGHT  8

// 布尔类型
#define L_TRUE  1
#define L_FALSE 0
typedef int l_bool;

// ============ 数据结构 ============
// 文件结构
typedef struct {
    int fd;
    int pos;
    int eof;
    int error;
} L_FILE;

// 时间结构
typedef struct {
    long sec;
    long nsec;
} L_TIMESPEC;

// 字符串缓冲区
typedef struct {
    char *data;
    int length;
    int capacity;
} L_STRING;

// ============ 系统调用包装 ============
static inline long l_syscall(long number, long arg1, long arg2, long arg3, 
                            long arg4, long arg5, long arg6) {
    long ret;
    register long x8 __asm__("x8") = number;
    register long x0 __asm__("x0") = arg1;
    register long x1 __asm__("x1") = arg2;
    register long x2 __asm__("x2") = arg3;
    register long x3 __asm__("x3") = arg4;
    register long x4 __asm__("x4") = arg5;
    register long x5 __asm__("x5") = arg6;
    
    __asm__ __volatile__(
        "svc 0"
        : "=r"(x0)
        : "r"(x0), "r"(x1), "r"(x2), "r"(x3), "r"(x4), "r"(x5), "r"(x8)
        : "memory", "cc"
    );
    
    ret = x0;
    return ret;
}

// ============ 基础I/O ============
static int l_write(int fd, const char *buf, int count) {
    return l_syscall(L_SYS_WRITE, fd, (long)buf, count, 0, 0, 0);
}

static int l_read(int fd, char *buf, int count) {
    return l_syscall(L_SYS_READ, fd, (long)buf, count, 0, 0, 0);
}

static void l_putchar(char c) {
    l_write(L_STDOUT_FILENO, &c, 1);
}

static char l_getchar() {
    char c;
    int n = l_read(L_STDIN_FILENO, &c, 1);
    return (n == 1) ? c : L_EOF;
}

static void l_puts(const char *str) {
    int len = 0;
    while (str[len]) len++;
    l_write(L_STDOUT_FILENO, str, len);
    l_putchar('\n');
}

static void l_print(const char *str) {
    int len = 0;
    while (str[len]) len++;
    l_write(L_STDOUT_FILENO, str, len);
}

// ============ 数字格式化 ============
static void l_putint(int num) {
    char buf[32];
    int i = 0, is_negative = 0;
    
    if (num < 0) {
        is_negative = 1;
        num = -num;
    } else if (num == 0) {
        buf[i++] = '0';
    }
    
    while (num > 0) {
        buf[i++] = (num % 10) + '0';
        num /= 10;
    }
    
    if (is_negative) {
        buf[i++] = '-';
    }
    
    // 反转并输出
    for (int j = i - 1; j >= 0; j--) {
        l_putchar(buf[j]);
    }
}

static void l_puthex(unsigned int num) {
    char buf[16];
    const char *hex = "0123456789ABCDEF";
    int i = 0;
    
    if (num == 0) {
        buf[i++] = '0';
    }
    
    while (num > 0) {
        buf[i++] = hex[num & 0xF];
        num >>= 4;
    }
    
    l_print("0x");
    for (int j = i - 1; j >= 0; j--) {
        l_putchar(buf[j]);
    }
}

// ============ 格式化输出 ============
static void l_printf(const char *format, ...) {
    const char *p = format;
    char c;
    
    // 简单实现，支持 %s, %d, %c, %%
    while ((c = *p++)) {
        if (c == '%') {
            c = *p++;
            switch (c) {
                case 's': {
                    // 字符串参数
                    const char *s = *((const char**)(&p + 1));
                    l_print(s);
                    p += sizeof(char*);
                    break;
                }
                case 'd': {
                    // 整数参数
                    int num = *((int*)(&p + 1));
                    l_putint(num);
                    p += sizeof(int);
                    break;
                }
                case 'c': {
                    // 字符参数
                    char ch = *((char*)(&p + 1));
                    l_putchar(ch);
                    p += sizeof(char);
                    break;
                }
                case 'x': {
                    // 十六进制
                    unsigned int num = *((unsigned int*)(&p + 1));
                    l_puthex(num);
                    p += sizeof(unsigned int);
                    break;
                }
                case '%':
                    l_putchar('%');
                    break;
                default:
                    l_putchar('%');
                    l_putchar(c);
                    break;
            }
        } else {
            l_putchar(c);
        }
    }
}

// ============ 字符串处理 ============
static int l_strlen(const char *str) {
    int len = 0;
    while (str[len]) len++;
    return len;
}

static char* l_strcpy(char *dest, const char *src) {
    int i = 0;
    while (src[i]) {
        dest[i] = src[i];
        i++;
    }
    dest[i] = '\0';
    return dest;
}

static char* l_strcat(char *dest, const char *src) {
    int i = l_strlen(dest);
    l_strcpy(dest + i, src);
    return dest;
}

static int l_strcmp(const char *s1, const char *s2) {
    while (*s1 && (*s1 == *s2)) {
        s1++;
        s2++;
    }
    return *(const unsigned char*)s1 - *(const unsigned char*)s2;
}

// ============ 内存操作 ============
static void* l_memset(void *ptr, int value, int size) {
    char *p = (char*)ptr;
    for (int i = 0; i < size; i++) {
        p[i] = (char)value;
    }
    return ptr;
}

static void* l_memcpy(void *dest, const void *src, int size) {
    char *d = (char*)dest;
    const char *s = (const char*)src;
    for (int i = 0; i < size; i++) {
        d[i] = s[i];
    }
    return dest;
}

// ============ 简单内存分配器 ============
#define L_POOL_SIZE (4 * 1024 * 1024)  // 4MB
static char l_mem_pool[L_POOL_SIZE];
static int l_mem_used = 0;

static void* l_malloc(int size) {
    if (size <= 0) return 0;
    
    // 对齐到8字节
    size = (size + 7) & ~7;
    
    if (l_mem_used + size > L_POOL_SIZE) {
        l_puts("Error: Out of memory!");
        return 0;
    }
    
    void *ptr = &l_mem_pool[l_mem_used];
    l_mem_used += size;
    return ptr;
}

static void l_free_all() {
    l_mem_used = 0;
}

static int l_get_mem_used() {
    return l_mem_used;
}

// ============ 控制台功能 ============
static void l_clear() {
    l_print("\033[2J\033[H");
}

static void l_set_color(int fg, int bg) {
    char buf[16];
    int len = 0;
    
    buf[len++] = '\033';
    buf[len++] = '[';
    
    if (fg >= 0 && fg < 16) {
        if (fg >= 8) {
            buf[len++] = '1';
            buf[len++] = ';';
            fg -= 8;
        }
        buf[len++] = '3';
        buf[len++] = '0' + fg;
    }
    
    if (bg >= 0 && bg < 8) {
        if (fg >= 0) buf[len++] = ';';
        buf[len++] = '4';
        buf[len++] = '0' + bg;
    }
    
    buf[len++] = 'm';
    buf[len] = '\0';
    
    l_print(buf);
}

static void l_reset_color() {
    l_print("\033[0m");
}

static void l_cursor_pos(int row, int col) {
    char buf[32];
    int len = 0;
    
    buf[len++] = '\033';
    buf[len++] = '[';
    
    // 行
    int n = row;
    char temp[10];
    int i = 0;
    do {
        temp[i++] = (n % 10) + '0';
        n /= 10;
    } while (n > 0);
    for (int j = i - 1; j >= 0; j--) {
        buf[len++] = temp[j];
    }
    
    buf[len++] = ';';
    
    // 列
    n = col;
    i = 0;
    do {
        temp[i++] = (n % 10) + '0';
        n /= 10;
    } while (n > 0);
    for (int j = i - 1; j >= 0; j--) {
        buf[len++] = temp[j];
    }
    
    buf[len++] = 'H';
    buf[len] = '\0';
    
    l_print(buf);
}

// ============ 文件操作 ============
static L_FILE* l_fopen(const char *path, const char *mode) {
    int flags = 0;
    
    // 解析模式
    if (mode[0] == 'r') {
        flags = L_O_RDONLY;
    } else if (mode[0] == 'w') {
        flags = L_O_WRONLY | L_O_CREAT | L_O_TRUNC;
    } else if (mode[0] == 'a') {
        flags = L_O_WRONLY | L_O_CREAT | L_O_APPEND;
    } else if (mode[0] == 'r' && mode[1] == '+') {
        flags = L_O_RDWR;
    } else if (mode[0] == 'w' && mode[1] == '+') {
        flags = L_O_RDWR | L_O_CREAT | L_O_TRUNC;
    } else {
        return 0;
    }
    
    int fd = l_syscall(L_SYS_OPENAT, -100, (long)path, flags, 0644, 0, 0);
    if (fd < 0) return 0;
    
    L_FILE *file = (L_FILE*)l_malloc(sizeof(L_FILE));
    if (!file) {
        l_syscall(L_SYS_CLOSE, fd, 0, 0, 0, 0, 0);
        return 0;
    }
    
    file->fd = fd;
    file->pos = 0;
    file->eof = 0;
    file->error = 0;
    
    return file;
}

static int l_fclose(L_FILE *stream) {
    if (!stream) return L_EOF;
    
    int result = l_syscall(L_SYS_CLOSE, stream->fd, 0, 0, 0, 0, 0);
    
    // 注意：这里实际上应该释放内存，但我们的简单分配器不支持部分释放
    // 所以只是标记为关闭
    stream->fd = -1;
    
    return result;
}

static int l_fread(void *ptr, int size, int count, L_FILE *stream) {
    if (!stream || stream->fd < 0) return 0;
    
    int total = size * count;
    int n = l_read(stream->fd, (char*)ptr, total);
    
    if (n <= 0) {
        stream->eof = (n == 0);
        stream->error = (n < 0);
        return 0;
    }
    
    stream->pos += n;
    return n / size;
}

static int l_fwrite(const void *ptr, int size, int count, L_FILE *stream) {
    if (!stream || stream->fd < 0) return 0;
    
    int total = size * count;
    int n = l_write(stream->fd, (const char*)ptr, total);
    
    if (n < 0) {
        stream->error = 1;
        return 0;
    }
    
    stream->pos += n;
    return n / size;
}

// ============ 工具函数 ============
static int l_atoi(const char *str) {
    int result = 0;
    int sign = 1;
    
    if (*str == '-') {
        sign = -1;
        str++;
    } else if (*str == '+') {
        str++;
    }
    
    while (*str >= '0' && *str <= '9') {
        result = result * 10 + (*str - '0');
        str++;
    }
    
    return sign * result;
}

static char* l_itoa(int num, char *str, int base) {
    int i = 0, is_negative = 0;
    char temp[32];
    
    if (num == 0) {
        str[i++] = '0';
        str[i] = '\0';
        return str;
    }
    
    if (num < 0 && base == 10) {
        is_negative = 1;
        num = -num;
    }
    
    while (num != 0) {
        int rem = num % base;
        temp[i++] = (rem > 9) ? (rem - 10) + 'a' : rem + '0';
        num = num / base;
    }
    
    if (is_negative) {
        temp[i++] = '-';
    }
    
    temp[i] = '\0';
    
    // 反转字符串
    for (int j = 0; j < i; j++) {
        str[j] = temp[i - j - 1];
    }
    str[i] = '\0';
    
    return str;
}

static int l_abs(int x) {
    return (x < 0) ? -x : x;
}

static int l_max(int a, int b) {
    return (a > b) ? a : b;
}

static int l_min(int a, int b) {
    return (a < b) ? a : b;
}

// ============ 时间函数 ============
static long l_time() {
    return l_syscall(L_SYS_TIME, 0, 0, 0, 0, 0, 0);
}

static int l_sleep(long sec, long nsec) {
    L_TIMESPEC req = {sec, nsec};
    L_TIMESPEC rem = {0, 0};
    
    return l_syscall(L_SYS_NANOSLEEP, (long)&req, (long)&rem, 0, 0, 0, 0);
}

static int l_msleep(int ms) {
    return l_sleep(ms / 1000, (ms % 1000) * 1000000);
}

// ============ 程序控制 ============
static void l_exit(int code) {
    l_syscall(L_SYS_EXIT, code, 0, 0, 0, 0, 0);
}

static int l_getpid() {
    return l_syscall(L_SYS_GETPID, 0, 0, 0, 0, 0, 0);
}

// ============ 数学函数 ============
static int l_pow(int base, int exp) {
    int result = 1;
    for (int i = 0; i < exp; i++) {
        result *= base;
    }
    return result;
}

static int l_sqrt(int x) {
    if (x <= 0) return 0;
    
    int guess = x;
    int prev = 0;
    
    while (guess != prev) {
        prev = guess;
        guess = (guess + x / guess) / 2;
    }
    
    return guess;
}

#endif // L_STDIO_H
