#include "lib.h"
#include "lstdio.h"

int add(int a, int b) { // 具体实现
    return a + b;
}
