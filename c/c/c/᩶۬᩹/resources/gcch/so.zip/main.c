/**
 * Copyright [2023] [LAOLIPEF]
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <stdbool.h>
#include <time.h>
#include <curl/curl.h>
#include <openssl/evp.h>
#include <ncurses.h>
#include <sys/statvfs.h>
#include <sys/stat.h>
#include <dirent.h>
#include <ctype.h>
#include <errno.h>
#include <locale.h>
#include <wchar.h>
#include <math.h>

// 多语言支持
typedef enum {
    LANG_ZH,
    LANG_EN
} Language;

typedef struct {
    Language current_lang;
    
    // 界面文本
    const char *title;
    const char *url_prompt;
    const char *path_prompt;
    const char *browse;
    const char *download;
    const char *pause;
    const char *resume;
    const char *exit;
    
    // 状态消息
    const char *ready;
    const char *downloading;
    const char *success;
    const char *failed;
    
    // 错误消息
    const char *err_no_url;
    const char *err_no_path;
    const char *err_fetch_info;
    const char *err_download;
    const char *err_write_file;
    const char *err_hash_mismatch;
    const char *err_low_space;
} LangStrings;

typedef struct {
    char url[1024];
    char save_path[1024];
    char filename[256];
    long total_size;
    long downloaded;
    long resume_position;
    bool paused;
    bool completed;
    time_t start_time;
    FILE *file;
    CURL *curl_handle;
} DownloadInfo;

// 倒计时结构体
typedef struct {
    long long time_left;
    bool running;
    bool paused;
    time_t start_time;
    time_t pause_time;
    long long total_time;
} CountdownTimer;

// 简单计时器结构体
typedef struct {
    int elapsed_time;
    bool running;
    time_t last_time;
} SimpleTimer;

// 井字棋游戏
char tic_tac_toe_board[3][3] = {{'1', '2', '3'}, {'4', '5', '6'}, {'7', '8', '9'}};
char currentPlayer = 'X';

// 扫雷游戏
#define MINE_WIDTH 10
#define MINE_HEIGHT 10
#define MINE_COUNT 20

char mine_board[MINE_HEIGHT][MINE_WIDTH];
char mine_display[MINE_HEIGHT][MINE_WIDTH];
int mines_remaining = MINE_COUNT;
int cells_revealed = 0;

// 贪吃蛇游戏
#define SNAKE_WIDTH 40
#define SNAKE_HEIGHT 20
#define MAX_SNAKE_LENGTH 100

typedef struct {
    int x;
    int y;
} SnakeSegment;

typedef enum {
    DIR_RIGHT,
    DIR_LEFT,
    DIR_UP,
    DIR_DOWN
} Direction;

typedef struct {
    SnakeSegment body[MAX_SNAKE_LENGTH];
    int length;
    Direction direction;
    int food_x;
    int food_y;
    bool game_over;
} SnakeGame;

// 猜数字游戏
#define NUMBER_GAME_VERSION "ULTRA v2.20250207"
#define NUMBER_DATA_ROOT "/tmp/sshkc"  // 修改为临时目录
#define NUMBER_MAX_PATH_LEN 512
#define NUMBER_MAX_INPUT_LEN 100
#define NUMBER_MAX_ATTEMPTS_DEFAULT 10
#define NUMBER_MAX_GAME_TIME (70LL * 365 * 24 * 3600)  // 70年
#define NUMBER_WARNING_THRESHOLD (60 * 365 * 24 * 3600)  // 60年警告

// 猜数字游戏结构体
typedef struct {
    int range;
    int max_attempts;
    int initial_score;
    int penalty;
    int time_limit;
    char mode[20];
} NumberGameConfig;

typedef struct {
    int game_count;
    int total_time;
    int launch_count;
    int secret_number;
    int attempts;
    int score;
    time_t start_time;
    time_t session_start;
} NumberGameState;

// 猜数字游戏全局变量
char number_log_file[NUMBER_MAX_PATH_LEN];
char number_time_dir[NUMBER_MAX_PATH_LEN];
NumberGameState number_game_state = {0};
NumberGameConfig number_game_config = {100, 10, 100, 5, 30, "normal"};

// 倒计时全局变量
CountdownTimer countdown_timer = {0};

// 简单计时器全局变量
SimpleTimer simple_timer = {0};

// 初始化语言字符串
void init_lang_strings(LangStrings *lang, Language init_lang) {
    lang->current_lang = init_lang;
    
    if (init_lang == LANG_ZH) {
        lang->title = "多功能工具箱 v1.0";
        lang->url_prompt = "请输入下载URL: ";
        lang->path_prompt = "保存路径: ";
        lang->browse = "[浏览]";
        lang->download = "[下载]";
        lang->pause = "[暂停]";
        lang->resume = "[恢复]";
        lang->exit = "[退出]";
        
        lang->ready = "状态: 就绪";
        lang->downloading = "状态: 下载中...";
        lang->success = "下载完成: ";
        lang->failed = "下载失败";
        
        lang->err_no_url = "错误: 请输入下载URL";
        lang->err_no_path = "错误: 请输入保存路径";
        lang->err_fetch_info = "错误: 获取文件信息失败";
        lang->err_download = "错误: 下载失败";
        lang->err_write_file = "错误: 写入文件失败";
        lang->err_hash_mismatch = "警告: 文件哈希校验失败";
        lang->err_low_space = "错误: 磁盘空间不足";
    } else {
        lang->title = "Multi-Tool Box v1.0";
        lang->url_prompt = "Enter download URL: ";
        lang->path_prompt = "Save path: ";
        lang->browse = "[Browse]";
        lang->download = "[Download]";
        lang->pause = "[Pause]";
        lang->resume = "[Resume]";
        lang->exit = "[Exit]";
        
        lang->ready = "Status: Ready";
        lang->downloading = "Status: Downloading...";
        lang->success = "Download completed: ";
        lang->failed = "Download failed";
        
        lang->err_no_url = "Error: Please enter download URL";
        lang->err_no_path = "Error: Please enter save path";
        lang->err_fetch_info = "Error: Failed to fetch file info";
        lang->err_download = "Error: Download failed";
        lang->err_write_file = "Error: Failed to write file";
        lang->err_hash_mismatch = "Warning: File hash mismatch";
        lang->err_low_space = "Error: Not enough disk space";
    }
}

// 切换语言
void toggle_language(LangStrings *lang) {
    lang->current_lang = (lang->current_lang == LANG_ZH) ? LANG_EN : LANG_ZH;
    init_lang_strings(lang, lang->current_lang);
}

// 简单计时器功能函数
void simple_timer_init(SimpleTimer *timer) {
    timer->elapsed_time = 0;
    timer->running = false;
    timer->last_time = time(NULL);
}

void simple_timer_start(SimpleTimer *timer) {
    if (!timer->running) {
        timer->running = true;
        timer->last_time = time(NULL) - timer->elapsed_time;
    }
}

void simple_timer_stop(SimpleTimer *timer) {
    timer->running = false;
}

void simple_timer_reset(SimpleTimer *timer) {
    timer->elapsed_time = 0;
    timer->running = false;
    timer->last_time = time(NULL);
}

void simple_timer_update(SimpleTimer *timer) {
    if (timer->running) {
        timer->elapsed_time = time(NULL) - timer->last_time;
    }
}

char* simple_timer_format_time(int seconds) {
    static char buffer[64];
    int hours = seconds / 3600;
    int minutes = (seconds % 3600) / 60;
    int secs = seconds % 60;
    
    if (hours > 0) {
        snprintf(buffer, sizeof(buffer), "%02d:%02d:%02d", hours, minutes, secs);
    } else {
        snprintf(buffer, sizeof(buffer), "%02d:%02d", minutes, secs);
    }
    
    return buffer;
}

void simple_timer_display(SimpleTimer *timer, int row, int col) {
    char* formatted_time = simple_timer_format_time(timer->elapsed_time);
    char status[32];
    
    if (!timer->running) {
        strcpy(status, "已停止");
    } else {
        strcpy(status, "运行中");
    }
    
    mvprintw(row, col, "简单计时器: %s [%s]", formatted_time, status);
}

void simple_timer_game() {
    bool in_menu = true;
    char input;
    
    // 初始化计时器
    simple_timer_init(&simple_timer);
    
    while (in_menu) {
        clear();
        mvprintw(0, 0, "简单计时器");
        mvprintw(1, 0, "===========");
        
        simple_timer_update(&simple_timer);
        simple_timer_display(&simple_timer, 3, 2);
        
        // 绘制计时器界面
        int hours = simple_timer.elapsed_time / 3600;
        int minutes = (simple_timer.elapsed_time % 3600) / 60;
        int seconds = simple_timer.elapsed_time % 60;
        
        mvprintw(5, 10, "╔════════════════════════╗");
        mvprintw(6, 10, "║    简单计时器          ║");
        mvprintw(7, 10, "╠════════════════════════╣");
        mvprintw(8, 10, "║    %02d:%02d:%02d           ║", hours, minutes, seconds);
        mvprintw(9, 10, "╠════════════════════════╣");
        mvprintw(10, 10, "║  状态: %s          ║", simple_timer.running ? "运行中 " : "已停止 ");
        mvprintw(11, 10, "╠════════════════════════╣");
        mvprintw(12, 10, "║  控制选项:             ║");
        mvprintw(13, 10, "║  s - 开始/停止         ║");
        mvprintw(14, 10, "║  r - 重置              ║");
        mvprintw(15, 10, "║  q - 返回主菜单        ║");
        mvprintw(16, 10, "╚════════════════════════╝");
        
        mvprintw(18, 0, "请选择操作 (s/r/q): ");
        refresh();
        
        timeout(100); // 100ms超时，用于实时更新
        input = getch();
        timeout(-1);  // 恢复阻塞模式
        
        switch (input) {
            case 's':
            case 'S':
                if (simple_timer.running) {
                    simple_timer_stop(&simple_timer);
                    mvprintw(20, 0, "计时器已停止!");
                } else {
                    simple_timer_start(&simple_timer);
                    mvprintw(20, 0, "计时器已开始!");
                }
                refresh();
                napms(500);
                break;
                
            case 'r':
            case 'R':
                simple_timer_reset(&simple_timer);
                mvprintw(20, 0, "计时器已重置!");
                refresh();
                napms(500);
                break;
                
            case 'q':
            case 'Q':
                in_menu = false;
                break;
                
            default:
                break;
        }
        
        // 短暂延迟以避免CPU过度使用
        napms(50);
    }
}

// 倒计时功能函数
void countdown_init(CountdownTimer *timer, long long seconds) {
    timer->time_left = seconds;
    timer->total_time = seconds;
    timer->running = false;
    timer->paused = false;
    timer->start_time = 0;
    timer->pause_time = 0;
}

void countdown_start(CountdownTimer *timer) {
    if (!timer->running) {
        timer->running = true;
        timer->paused = false;
        timer->start_time = time(NULL);
    } else if (timer->paused) {
        // 恢复计时
        long long paused_duration = time(NULL) - timer->pause_time;
        timer->start_time += paused_duration;
        timer->paused = false;
    }
}

void countdown_pause(CountdownTimer *timer) {
    if (timer->running && !timer->paused) {
        timer->paused = true;
        timer->pause_time = time(NULL);
    }
}

void countdown_reset(CountdownTimer *timer) {
    timer->running = false;
    timer->paused = false;
    timer->time_left = timer->total_time;
    timer->start_time = 0;
    timer->pause_time = 0;
}

void countdown_update(CountdownTimer *timer) {
    if (timer->running && !timer->paused) {
        time_t current_time = time(NULL);
        long long elapsed = current_time - timer->start_time;
        timer->time_left = timer->total_time - elapsed;
        
        if (timer->time_left <= 0) {
            timer->time_left = 0;
            timer->running = false;
        }
    }
}

char* countdown_format_time(long long seconds) {
    static char buffer[64];
    long long hours = seconds / 3600;
    long long minutes = (seconds % 3600) / 60;
    long long secs = seconds % 60;
    
    if (hours > 0) {
        snprintf(buffer, sizeof(buffer), "%02lld:%02lld:%02lld", hours, minutes, secs);
    } else {
        snprintf(buffer, sizeof(buffer), "%02lld:%02lld", minutes, secs);
    }
    
    return buffer;
}

void countdown_display(CountdownTimer *timer, int row, int col) {
    char* formatted_time = countdown_format_time(timer->time_left);
    char status[32];
    
    if (!timer->running) {
        strcpy(status, "已停止");
    } else if (timer->paused) {
        strcpy(status, "已暂停");
    } else {
        strcpy(status, "运行中");
    }
    
    mvprintw(row, col, "倒计时: %s [%s]", formatted_time, status);
    
    // 显示进度条
    if (timer->total_time > 0) {
        int bar_width = 30;
        int progress = (int)((double)(timer->total_time - timer->time_left) / timer->total_time * bar_width);
        
        mvprintw(row + 1, col, "[");
        for (int i = 0; i < bar_width; i++) {
            if (i < progress) {
                mvprintw(row + 1, col + 1 + i, "=");
            } else {
                mvprintw(row + 1, col + 1 + i, " ");
            }
        }
        mvprintw(row + 1, col + 1 + bar_width, "]");
        
        // 显示百分比
        int percent = (int)((double)(timer->total_time - timer->time_left) / timer->total_time * 100);
        mvprintw(row + 1, col + bar_width + 5, "%d%%", percent);
    }
}

void countdown_setup_menu() {
    clear();
    mvprintw(0, 0, "倒计时设置");
    mvprintw(1, 0, "================");
    
    mvprintw(3, 0, "当前设置: %lld 秒", countdown_timer.total_time);
    mvprintw(4, 0, "格式: 时:分:秒 或 直接输入秒数");
    mvprintw(5, 0, "示例: 3600 (1小时) 或 01:30:00 (1小时30分)");
    
    mvprintw(7, 0, "请输入新的时间: ");
    refresh();
    
    echo();
    char input[64];
    getnstr(input, sizeof(input) - 1);
    noecho();
    
    long long new_seconds = 0;
    
    // 检查是否是时:分:秒格式
    int hours = 0, minutes = 0, seconds = 0;
    if (sscanf(input, "%d:%d:%d", &hours, &minutes, &seconds) == 3) {
        new_seconds = hours * 3600LL + minutes * 60LL + seconds;
    } else if (sscanf(input, "%d:%d", &minutes, &seconds) == 2) {
        new_seconds = minutes * 60LL + seconds;
    } else {
        // 直接输入秒数
        new_seconds = atoll(input);
    }
    
    if (new_seconds > 0) {
        countdown_init(&countdown_timer, new_seconds);
        mvprintw(9, 0, "时间已设置为: %s", countdown_format_time(new_seconds));
    } else {
        mvprintw(9, 0, "无效的时间格式!");
    }
    
    mvprintw(11, 0, "按任意键继续...");
    refresh();
    getch();
}

void countdown_control_menu() {
    bool in_menu = true;
    
    while (in_menu) {
        clear();
        mvprintw(0, 0, "倒计时控制面板");
        mvprintw(1, 0, "=================");
        
        countdown_display(&countdown_timer, 3, 2);
        
        mvprintw(6, 0, "控制选项:");
        mvprintw(7, 0, "[1] 开始/继续");
        mvprintw(8, 0, "[2] 暂停");
        mvprintw(9, 0, "[3] 重置");
        mvprintw(10, 0, "[4] 重新设置时间");
        mvprintw(11, 0, "[0] 返回主菜单");
        
        mvprintw(13, 0, "请选择操作: ");
        refresh();
        
        int choice = getch();
        
        switch (choice) {
            case '1':
                countdown_start(&countdown_timer);
                mvprintw(15, 0, "倒计时已开始!");
                refresh();
                napms(1000);
                break;
                
            case '2':
                countdown_pause(&countdown_timer);
                mvprintw(15, 0, "倒计时已暂停!");
                refresh();
                napms(1000);
                break;
                
            case '3':
                countdown_reset(&countdown_timer);
                mvprintw(15, 0, "倒计时已重置!");
                refresh();
                napms(1000);
                break;
                
            case '4':
                countdown_setup_menu();
                break;
                
            case '0':
                in_menu = false;
                break;
                
            default:
                mvprintw(15, 0, "无效的选择!");
                refresh();
                napms(1000);
                break;
        }
        
        // 更新倒计时状态
        countdown_update(&countdown_timer);
        
        // 检查是否时间到
        if (countdown_timer.time_left == 0 && countdown_timer.running) {
            clear();
            mvprintw(5, 15, "╔╔══════════════════════════════╗╗");
            mvprintw(6, 15, "║║                              ║║║");
            mvprintw(7, 15, "║║         时间到！            ║║║");
            mvprintw(8, 15, "║║        TIME'S UP!           ║║║");
            mvprintw(9, 15, "║║                              ║║║");
            mvprintw(10, 15, "╚╚══════════════════════════════╝╝");
            
            // 闪烁效果
            for (int i = 0; i < 3; i++) {
                flash();
                napms(500);
            }
            
            mvprintw(12, 0, "按任意键继续...");
            refresh();
            getch();
            
            countdown_timer.running = false;
        }
    }
}

void countdown_game() {
    // 如果还没有设置时间，先进入设置菜单
    if (countdown_timer.total_time == 0) {
        countdown_setup_menu();
    }
    
    countdown_control_menu();
}

// 获取磁盘剩余空间 (bytes)
uint64_t get_free_disk_space(const char *path) {
    struct statvfs stat;
    if (statvfs(path, &stat) == 0) {
        return (uint64_t)stat.f_bsize * stat.f_bavail;
    }
    return 0;
}

// 写文件回调函数
size_t write_callback(void *ptr, size_t size, size_t nmemb, FILE *stream) {
    return fwrite(ptr, size, nmemb, stream);
}

// 进度回调函数
int progress_callback(void *clientp, 
                     curl_off_t dltotal, 
                     curl_off_t dlnow,
                     curl_off_t ultotal, 
                     curl_off_t ulnow) {
    DownloadInfo *info = (DownloadInfo *)clientp;
    
    if (dltotal > 0) {
        double progress = (double)dlnow * 100.0 / dltotal;
        time_t current_time = time(NULL);
        double elapsed = difftime(current_time, info->start_time);
        
        // 计算下载速度
        double speed = (elapsed > 0) ? dlnow / elapsed : 0;
        
        // 计算剩余时间
        double remaining = (speed > 0) ? (dltotal - dlnow) / speed : 0;
        
        // 更新显示
        mvprintw(10, 2, "Progress: %.2f%% Downloaded: %ld/%ld bytes", 
                progress, dlnow, dltotal);
        
        if (speed > 0) {
            mvprintw(11, 2, "Speed: %.2f KB/s ETA: %.0f seconds", 
                    speed / 1024, remaining);
        }
        
        refresh();
    }
    
    return 0;
}

// 使用EVP接口计算MD5哈希
bool verify_file_hash(const char *filename, const char *expected_hash) {
    if (!expected_hash || strlen(expected_hash) != 32) {
        return false;
    }
    
    FILE *file = fopen(filename, "rb");
    if (!file) return false;
    
    EVP_MD_CTX *mdctx;
    const EVP_MD *md;
    unsigned char buffer[8192];
    unsigned char md5_hash[EVP_MAX_MD_SIZE];
    unsigned int md_len;
    
    md = EVP_MD_fetch(NULL, "MD5", NULL);
    if (!md) {
        fclose(file);
        return false;
    }
    
    mdctx = EVP_MD_CTX_new();
    if (!mdctx) {
        EVP_MD_free((EVP_MD*)md);
        fclose(file);
        return false;
    }
    
    if (EVP_DigestInit_ex(mdctx, md, NULL) != 1) {
        EVP_MD_CTX_free(mdctx);
        EVP_MD_free((EVP_MD*)md);
        fclose(file);
        return false;
    }
    
    size_t bytes_read;
    while ((bytes_read = fread(buffer, 1, sizeof(buffer), file)) > 0) {
        if (EVP_DigestUpdate(mdctx, buffer, bytes_read) != 1) {
            EVP_MD_CTX_free(mdctx);
            EVP_MD_free((EVP_MD*)md);
            fclose(file);
            return false;
        }
    }
    
    if (EVP_DigestFinal_ex(mdctx, md5_hash, &md_len) != 1) {
        EVP_MD_CTX_free(mdctx);
        EVP_MD_free((EVP_MD*)md);
        fclose(file);
        return false;
    }
    
    EVP_MD_CTX_free(mdctx);
    EVP_MD_free((EVP_MD*)md);
    fclose(file);
    
    // 转换为十六进制字符串
    char actual_hash[33] = {0};
    for (int i = 0; i < md_len; i++) {
        sprintf(actual_hash + (i * 2), "%02x", md5_hash[i]);
    }
    
    return (strcasecmp(actual_hash, expected_hash) == 0);
}

// 获取远程文件信息
bool get_file_info(DownloadInfo *info) {
    CURL *curl = curl_easy_init();
    if (!curl) return false;
    
    curl_easy_setopt(curl, CURLOPT_URL, info->url);
    curl_easy_setopt(curl, CURLOPT_NOBODY, 1L);
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    
    CURLcode res = curl_easy_perform(curl);
    
    if (res == CURLE_OK) {
        curl_easy_getinfo(curl, CURLINFO_CONTENT_LENGTH_DOWNLOAD_T, 
                         &info->total_size);
        
        // 提取文件名
        char *redirect_url = NULL;
        curl_easy_getinfo(curl, CURLINFO_EFFECTIVE_URL, &redirect_url);
        
        if (redirect_url) {
            char *filename = strrchr(redirect_url, '/');
            if (filename && strlen(filename) > 1) {
                strcpy(info->filename, filename + 1);
            } else {
                sprintf(info->filename, "download_%ld.dat", time(NULL));
            }
        }
    }
    
        curl_easy_cleanup(curl);
    return (res == CURLE_OK && info->total_size > 0);
}

// 主下载函数
bool download_file(DownloadInfo *info, const char *expected_md5) {
    CURL *curl = curl_easy_init();
    if (!curl) return false;
    
    char full_path[1024];
    snprintf(full_path, sizeof(full_path), "%s/%s", 
             info->save_path, info->filename);
    
    // 检查是否已部分下载
    long resume_from = 0;
    info->file = fopen(full_path, "rb+");
    if (info->file) {
        fseek(info->file, 0, SEEK_END);
        resume_from = ftell(info->file);
    } else {
        info->file = fopen(full_path, "wb");
    }
    
    if (!info->file) {
        curl_easy_cleanup(curl);
        return false;
    }
    
    // 设置CURL选项
    curl_easy_setopt(curl, CURLOPT_URL, info->url);
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_callback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, info->file);
    curl_easy_setopt(curl, CURLOPT_NOPROGRESS, 0L);
    curl_easy_setopt(curl, CURLOPT_XFERINFOFUNCTION, progress_callback);
    curl_easy_setopt(curl, CURLOPT_XFERINFODATA, info);
    
    // 设置断点续传
    if (resume_from > 0) {
        char range_header[64];
        snprintf(range_header, sizeof(range_header), "%ld-", resume_from);
        curl_easy_setopt(curl, CURLOPT_RANGE, range_header);
    }
    
    info->start_time = time(NULL);
    CURLcode res = curl_easy_perform(curl);
    
    fclose(info->file);
    info->file = NULL;
    
    bool success = false;
    if (res == CURLE_OK) {
        if (expected_md5 && *expected_md5) {
            success = verify_file_hash(full_path, expected_md5);
            if (!success) {
                remove(full_path);
            }
        } else {
            success = true;
        }
    }
    
    curl_easy_cleanup(curl);
    return success;
}

// 显示UI界面
void show_ui(LangStrings *lang, DownloadInfo *info) {
    clear();
    
    // 显示标题
    mvprintw(0, 0, "%s", lang->title);
    
    // 显示URL输入
    mvprintw(2, 0, "%s", lang->url_prompt);
    if (strlen(info->url) > 0) {
        mvprintw(2, strlen(lang->url_prompt), "%s", info->url);
    }
    
    // 显示路径
    mvprintw(4, 0, "%s", lang->path_prompt);
    if (strlen(info->save_path) > 0) {
        mvprintw(4, strlen(lang->path_prompt), "%s", info->save_path);
    }
    
    // 显示倒计时状态
    countdown_update(&countdown_timer);
    countdown_display(&countdown_timer, 6, 2);
    
    // 显示简单计时器状态
    simple_timer_update(&simple_timer);
    simple_timer_display(&simple_timer, 9, 2);
    
    // 显示按钮
    int x = 2;
    mvprintw(11, x, "[1]%s", lang->browse);
    x += strlen(lang->browse) + 4;
    
    mvprintw(11, x, "[2]%s", lang->download);
    x += strlen(lang->download) + 4;
    
    mvprintw(11, x, "[C]计算器");
    x += 8;
    
    mvprintw(11, x, "[T]井字棋");
    x += 8;
    
    mvprintw(11, x, "[M]扫雷");
    x += 7;
    
    mvprintw(11, x, "[S]贪吃蛇");
    x += 8;
    
    mvprintw(11, x, "[N]猜数字");
    x += 8;
    
    mvprintw(11, x, "[D]倒计时");
    x += 8;
    
    mvprintw(11, x, "[E]简单计时器");  // 新增简单计时器选项
    x += 12;
    
    mvprintw(11, x, "[L]切换语言");
    x += 12;
    
    mvprintw(11, x, "[ESC]%s", lang->exit);
    
    // 显示状态
    mvprintw(13, 0, "%s", lang->ready);
    
    refresh();
}

// 猜数字游戏功能函数
void number_game_create_directories() {
    char path[NUMBER_MAX_PATH_LEN];
    
    sprintf(path, "%s/data/log", NUMBER_DATA_ROOT);
    mkdir(path, 0777);
    
    sprintf(path, "%s/data/etc/time", NUMBER_DATA_ROOT);
    mkdir(path, 0777);
    
    sprintf(path, "%s/data/etc", NUMBER_DATA_ROOT);
    mkdir(path, 0777);
    
    sprintf(number_time_dir, "%s/data/etc/time", NUMBER_DATA_ROOT);
    
    sprintf(number_log_file, "%s/data/log/game_%ld.log", NUMBER_DATA_ROOT, time(NULL)/86400);
}

void number_game_write_log(const char* level, const char* message) {
    FILE* fp = fopen(number_log_file, "a");
    if (!fp) return;
    
    time_t now = time(NULL);
    struct tm* tm_info = localtime(&now);
    
    fprintf(fp, "[%04d-%02d-%02d %02d:%02d:%02d] [%s] %s\n",
            tm_info->tm_year + 1900, tm_info->tm_mon + 1, tm_info->tm_mday,
            tm_info->tm_hour, tm_info->tm_min, tm_info->tm_sec,
            level, message);
    fclose(fp);
    
    // 在ncurses中显示日志
    mvprintw(15, 0, "[%s] %s", level, message);
    refresh();
}

void number_game_clear_screen() {
    clear();
}

void number_game_show_title() {
    clear();
    mvprintw(0, 0, "==================================================");
    mvprintw(1, 0, "      猜数字游戏 %s", NUMBER_GAME_VERSION);
    mvprintw(2, 0, "==================================================");
    refresh();
}

void number_game_save_game_state() {
    char file_path[NUMBER_MAX_PATH_LEN];
    
    sprintf(file_path, "%s/game_count.txt", number_time_dir);
    FILE* fp = fopen(file_path, "w");
    if (fp) {
        fprintf(fp, "%d", number_game_state.game_count);
        fclose(fp);
    }
    
    sprintf(file_path, "%s/total_time.txt", number_time_dir);
    fp = fopen(file_path, "w");
    if (fp) {
        fprintf(fp, "%d", number_game_state.total_time);
        fclose(fp);
    }
    
    sprintf(file_path, "%s/launch_count.txt", number_time_dir);
    fp = fopen(file_path, "w");
    if (fp) {
        fprintf(fp, "%d", number_game_state.launch_count);
        fclose(fp);
    }
    
    sprintf(file_path, "%s/first_run.date", number_time_dir);
    if (access(file_path, F_OK) != 0) {
        fp = fopen(file_path, "w");
        if (fp) {
            time_t now = time(NULL);
            struct tm* tm_info = localtime(&now);
            fprintf(fp, "%04d-%02d-%02d", 
                    tm_info->tm_year + 1900, 
                    tm_info->tm_mon + 1, 
                    tm_info->tm_mday);
            fclose(fp);
        }
    }
}

void number_game_load_game_state() {
    char file_path[NUMBER_MAX_PATH_LEN];
    
    sprintf(file_path, "%s/game_count.txt", number_time_dir);
    FILE* fp = fopen(file_path, "r");
    if (fp) {
        fscanf(fp, "%d", &number_game_state.game_count);
        fclose(fp);
    }
    
    sprintf(file_path, "%s/total_time.txt", number_time_dir);
    fp = fopen(file_path, "r");
    if (fp) {
        fscanf(fp, "%d", &number_game_state.total_time);
        fclose(fp);
    }
    
    sprintf(file_path, "%s/launch_count.txt", number_time_dir);
    fp = fopen(file_path, "r");
    if (fp) {
        fscanf(fp, "%d", &number_game_state.launch_count);
        fclose(fp);
    } else {
        number_game_state.launch_count = 0;
    }
    
    number_game_state.launch_count++;
    number_game_save_game_state();
}

void number_game_init_normal_mode(int range, int max_attempts, int initial_score, int penalty) {
    number_game_config.range = range;
    number_game_config.max_attempts = max_attempts;
    number_game_config.initial_score = initial_score;
    number_game_config.penalty = penalty;
    strcpy(number_game_config.mode, "normal");
}

void number_game_init_chaos_mode() {
    srand(time(NULL));
    number_game_config.range = rand() % 9900 + 100;
    number_game_config.max_attempts = rand() % 15 + 5;
    number_game_config.initial_score = rand() % 150 + 50;
    number_game_config.penalty = rand() % 7 + 3;
    strcpy(number_game_config.mode, "chaos");
}

void number_game_init_timeattack_mode() {
    number_game_config.range = 100;
    number_game_config.max_attempts = 999;
    number_game_config.initial_score = 100;
    number_game_config.penalty = 0;
    number_game_config.time_limit = 30;
    strcpy(number_game_config.mode, "timeattack");
}

void number_game_init_ninja_mode() {
    number_game_config.range = 100;
    number_game_config.max_attempts = 5;
    number_game_config.initial_score = 200;
    number_game_config.penalty = 20;
    strcpy(number_game_config.mode, "ninja");
}

void number_game_init_zombie_mode() {
    number_game_config.range = 100;
    number_game_config.max_attempts = 15;
    number_game_config.initial_score = 50;
    number_game_config.penalty = 2;
    strcpy(number_game_config.mode, "zombie");
}

void number_game_init_troll_mode() {
    number_game_config.range = 10;
    number_game_config.max_attempts = 7;
    number_game_config.initial_score = 50;
    number_game_config.penalty = 0;
    strcpy(number_game_config.mode, "troll");
}

void number_game_init_game(int difficulty) {
    srand(time(NULL));
    
    switch (difficulty) {
        case 1:  // 简单
            number_game_init_normal_mode(100, 10, 100, 5);
            break;
        case 2:  // 普通
            number_game_init_normal_mode(100, 8, 100, 5);
            break;
        case 3:  // 困难
            number_game_init_normal_mode(1000, 15, 150, 5);
            break;
        case 4:  // 地狱
            number_game_init_normal_mode(10000, 20, 200, 3);
            break;
        case 5:  // 混沌
            number_game_init_chaos_mode();
            break;
        case 6:  // 限时
            number_game_init_timeattack_mode();
            break;
        case 7:  // 忍者
            number_game_init_ninja_mode();
            break;
        case 8:  // 僵尸
            number_game_init_zombie_mode();
            break;
        case 9:  // 摆烂
            number_game_init_troll_mode();
            break;
        default: // 默认简单
            number_game_init_normal_mode(100, 10, 100, 5);
            break;
    }
    
    number_game_state.secret_number = rand() % number_game_config.range + 1;
    number_game_state.attempts = 0;
    number_game_state.score = number_game_config.initial_score;
    number_game_state.start_time = time(NULL);
    
    char log_msg[256];
    sprintf(log_msg, "开始新游戏，模式: %s, 范围: 1-%d", 
            number_game_config.mode, number_game_config.range);
    number_game_write_log("INFO", log_msg);
}

int number_game_select_difficulty() {
    number_game_show_title();
    mvprintw(4, 0, "请选择游戏模式:");
    mvprintw(5, 0, "1. 简单模式 (1-100, 10次机会)");
    mvprintw(6, 0, "2. 普通模式 (1-100, 8次机会)");
    mvprintw(7, 0, "3. 困难模式 (1-1000, 15次机会)");
    mvprintw(8, 0, "4. 地狱模式 (1-10000, 20次机会)");
    mvprintw(9, 0, "5. 混沌模式 (完全随机规则)");
    mvprintw(10, 0, "6. 限时模式 (30秒内完成)");
    mvprintw(11, 0, "7. 忍者模式 (5次机会，高惩罚)");
    mvprintw(12, 0, "8. 僵尸模式 (分数低但机会多)");
    mvprintw(13, 0, "9. 摆烂模式 (1-10, 7次机会)");
    
    mvprintw(15, 0, "请选择 [1-9]: ");
    refresh();
    
    echo();
    int choice = getch() - '0';
    noecho();
    
    return choice;
}

int number_game_handle_special_commands(const char* input) {
    if (strcmp(input, "q") == 0 || strcmp(input, "quit") == 0) {
        number_game_show_title();
        mvprintw(4, 0, "你选择了放弃游戏！");
        mvprintw(5, 0, "正确答案是: %d", number_game_state.secret_number);
        
        if (strcmp(number_game_config.mode, "troll") == 0) {
            mvprintw(6, 0, "最终得分: -100 (连摆烂模式都放弃？)");
        } else {
            mvprintw(6, 0, "最终得分: 0 (放弃游戏不计分)");
        }
        
        mvprintw(8, 0, "按任意键返回主菜单...");
        refresh();
        getch();
        return 1;
    }
    
    if (strcmp(input, "h") == 0 || strcmp(input, "hint") == 0) {
        if (number_game_state.score > 10) {
            number_game_state.score -= 10;
            number_game_state.attempts++;
            
            int random_num = rand() % number_game_config.range + 1;
            int difference = number_game_state.secret_number - random_num;
            
            if (difference < 0) {
                mvprintw(15, 0, "提示: 数字比 %d 小", 
                       number_game_state.secret_number + (rand() % 100));
            } else {
                mvprintw(15, 0, "提示: 数字比 %d 大", 
                       number_game_state.secret_number - (rand() % 100));
            }
            
            if ((rand() % 10) == 0 && strcmp(number_game_config.mode, "chaos") == 0) {
                mvprintw(16, 0, "但是这个提示可能是假的！混沌模式生效！");
            }
            
            refresh();
            napms(2000);
            return 1;
        } else {
            mvprintw(15, 0, "分数不足，无法获取提示！");
            refresh();
            napms(1000);
            return 1;
        }
    }
    
    if (strcmp(input, "s") == 0 || strcmp(input, "skill") == 0) {
        if (number_game_state.score > 20) {
            number_game_state.score -= 20;
            number_game_state.attempts++;
            
            int effect = rand() % 5;
            switch (effect) {
                case 0:
                    mvprintw(15, 0, "技能生效！数字范围缩小到1-%d", number_game_config.range/2);
                    number_game_config.range /= 2;
                    break;
                case 1:
                    mvprintw(15, 0, "技能生效！获得额外3次机会！");
                    number_game_config.max_attempts += 3;
                    break;
                case 2:
                    mvprintw(15, 0, "技能生效！分数增加50！");
                    number_game_state.score += 50;
                    break;
                case 3:
                    mvprintw(15, 0, "技能生效！惩罚减少2分！");
                    if (number_game_config.penalty > 2) {
                        number_game_config.penalty -= 2;
                    } else {
                        number_game_config.penalty = 1;
                    }
                    break;
                case 4:
                    mvprintw(15, 0, "技能生效！直接告诉你数字的奇偶性！");
                    if (number_game_state.secret_number % 2 == 0) {
                        mvprintw(16, 0, "这是个偶数！");
                    } else {
                        mvprintw(16, 0, "这是个奇数！");
                    }
                    break;
            }
            
            refresh();
            napms(2000);
            return 1;
        } else {
            mvprintw(15, 0, "分数不足，无法使用技能！");
            refresh();
            napms(1000);
            return 1;
        }
    }
    
    return 0;
}

void number_game_provide_feedback(int guess) {
    int difference = abs(guess - number_game_state.secret_number);
    
    if (guess < number_game_state.secret_number) {
        if (difference > (number_game_config.range / 10)) {
            mvprintw(15, 0, "太小了！差得很远呢！");
        } else if (difference > (number_game_config.range / 20)) {
            mvprintw(15, 0, "太小了！但已经接近了！");
        } else {
            mvprintw(15, 0, "非常接近了！只是小了一点点！");
        }
        
        if ((rand() % 20) == 0 && strcmp(number_game_config.mode, "chaos") == 0) {
            mvprintw(16, 0, "混沌波动！提示反转！其实应该是太大了！");
        }
    } else {
        if (difference > (number_game_config.range / 10)) {
            mvprintw(15, 0, "太大了！差得很远呢！");
        } else if (difference > (number_game_config.range / 20)) {
            mvprintw(15, 0, "太大了！但已经接近了！");
        } else {
            mvprintw(15, 0, "非常接近了！只是大了一点点！");
        }
        
        if ((rand() % 20) == 0 && strcmp(number_game_config.mode, "chaos") == 0) {
            mvprintw(16, 0, "混沌波动！提示反转！其实应该是太小了！");
        }
    }
}

void number_game_handle_special_mode_effects() {
    if (strcmp(number_game_config.mode, "chaos") == 0) {
        if ((rand() % 10) == 0) {
            int old_number = number_game_state.secret_number;
            number_game_state.secret_number = rand() % number_game_config.range + 1;
            mvprintw(16, 0, "混沌波动！数字已经改变了！(从 %d 变为 ????）", old_number);
        }
    } else if (strcmp(number_game_config.mode, "ninja") == 0) {
        if ((rand() % 5) == 0) {
            number_game_config.max_attempts--;
            mvprintw(16, 0, "忍者偷袭！剩余机会减少到 %d 次！", number_game_config.max_attempts);
        }
    } else if (strcmp(number_game_config.mode, "zombie") == 0) {
        if ((rand() % 10) == 0) {
            number_game_config.max_attempts++;
            mvprintw(16, 0, "僵尸再生！剩余机会增加到 %d 次！", number_game_config.max_attempts);
        }
    }
    
    if (number_game_config.range > 1000 && (number_game_state.attempts % 3) == 0) {
        int lower_bound = number_game_state.secret_number - number_game_config.range / 10;
        int upper_bound = number_game_state.secret_number + number_game_config.range / 10;
        if (lower_bound < 1) lower_bound = 1;
        if (upper_bound > number_game_config.range) upper_bound = number_game_config.range;
        mvprintw(16, 0, "提示：数字在 %d 到 %d 之间", lower_bound, upper_bound);
    }
}

void number_game_handle_game_over() {
    number_game_show_title();
    
    if (strcmp(number_game_config.mode, "chaos") == 0) {
        mvprintw(4, 0, "混沌吞噬了一切！你失败了！");
    } else if (strcmp(number_game_config.mode, "timeattack") == 0) {
        mvprintw(4, 0, "时间流逝，机会消失...");
    } else if (strcmp(number_game_config.mode, "ninja") == 0) {
        mvprintw(4, 0, "忍者消失在黑暗中...");
    } else if (strcmp(number_game_config.mode, "zombie") == 0) {
        mvprintw(4, 0, "僵尸终于倒下了...");
    } else if (strcmp(number_game_config.mode, "troll") == 0) {
        mvprintw(4, 0, "你有实力吗？");
        mvprintw(5, 0, "就猜1-10的数字，%d 次机会你都能输？", number_game_config.max_attempts);
        mvprintw(6, 0, "正确答案是: %d", number_game_state.secret_number);
        mvprintw(7, 0, "建议：");
        mvprintw(8, 0, "1. 换个游戏玩");
        mvprintw(9, 0, "2. 找个班上");
        mvprintw(10, 0, "3. 反思人生");
    } else {
        mvprintw(4, 0, "很遗憾，你没有猜中。");
    }
    
    if (strcmp(number_game_config.mode, "troll") != 0) {
        mvprintw(5, 0, "正确答案是: %d", number_game_state.secret_number);
    }
    
    mvprintw(6, 0, "最终得分: %d", number_game_state.score);
    
    if (strcmp(number_game_config.mode, "troll") != 0) {
        mvprintw(8, 0, "经验总结:");
        if (number_game_state.score > (number_game_config.initial_score / 2)) {
            mvprintw(9, 0, "表现不错！下次可以尝试更精确的策略。");
        } else {
            mvprintw(9, 0, "建议使用二分法搜索，能大大提高效率！");
        }
    }
    
    if ((rand() % 10) == 0) {
        mvprintw(11, 0, "神秘声音: '数字 %d 才是真正的答案...'", 
               number_game_state.secret_number + 1);
    }
    
    mvprintw(13, 0, "按任意键返回主菜单...");
    refresh();
    getch();
}

void number_game_play_game() {
    int difficulty = number_game_select_difficulty();
    number_game_init_game(difficulty);
    
    char input[NUMBER_MAX_INPUT_LEN];
    int guess;
    int game_won = 0;
    
    while (number_game_state.attempts < number_game_config.max_attempts) {
        number_game_show_title();
        
        // 显示时间模式倒计时
        if (strcmp(number_game_config.mode, "timeattack") == 0) {
            int current_time = time(NULL);
            int elapsed = current_time - number_game_state.start_time;
            int remaining = number_game_config.time_limit - elapsed;
            if (remaining > 0) {
                mvprintw(3, 0, "剩余时间: %d 秒", remaining);
            } else {
                break;  // 时间到
            }
        }
        
        // 显示游戏界面
        if (strcmp(number_game_config.mode, "troll") == 0) {
            mvprintw(3, 0, "摆烂模式：猜一个1-10的数字 (还剩 %d 次机会)", 
                   number_game_config.max_attempts - number_game_state.attempts);
            mvprintw(4, 0, "（这都能输建议卸载游戏）");
        } else {
            mvprintw(3, 0, "猜一个数字 (范围: 1-%d, 还剩 %d 次机会)", 
                   number_game_config.range, 
                   number_game_config.max_attempts - number_game_state.attempts);
        }
        
        mvprintw(5, 0, "当前得分: %d", number_game_state.score);
        if (number_game_config.penalty > 0) {
            mvprintw(6, 0, "提示: 每次猜错扣%d分", number_game_config.penalty);
        }
        
        if (strcmp(number_game_config.mode, "chaos") == 0) {
            mvprintw(7, 0, "混沌模式: 数字可能是负数！");
        } else if (strcmp(number_game_config.mode, "ninja") == 0) {
            mvprintw(7, 0, "忍者模式: 高难度挑战！");
        } else if (strcmp(number_game_config.mode, "zombie") == 0) {
            mvprintw(7, 0, "僵尸模式: 缓慢但持久！");
        }
        
                mvprintw(9, 0, "输入 'q' 放弃, 'h' 获取提示(扣10分), 's' 使用特殊技能");
        
        mvprintw(11, 0, "请输入你的选择: ");
        refresh();
        
        echo();
        getnstr(input, NUMBER_MAX_INPUT_LEN - 1);
        noecho();
        
        // 处理特殊命令
        if (number_game_handle_special_commands(input)) {
            continue;
        }
        
        // 验证输入
        guess = atoi(input);
        if (guess < (1 - number_game_config.range/10) || guess > (number_game_config.range + number_game_config.range/10)) {
            mvprintw(12, 0, "眼睛不要就捐给有需要的人吧");
            mvprintw(13, 0, "请输入1-%d之间的数字啊！", number_game_config.range);
            refresh();
            napms(2000);
            continue;
        }
        
        // 处理猜测
        number_game_state.attempts++;
        number_game_state.score -= number_game_config.penalty;
        
        if (guess == number_game_state.secret_number) {
            game_won = 1;
            break;
        }
        
        number_game_provide_feedback(guess);
        number_game_handle_special_mode_effects();
        refresh();
        napms(1000);
    }
    
    if (game_won) {
        number_game_show_title();
        
        if (strcmp(number_game_config.mode, "chaos") == 0) {
            mvprintw(3, 0, "不可思议！你在混沌中找到了答案！");
        } else if (strcmp(number_game_config.mode, "timeattack") == 0) {
            mvprintw(3, 0, "闪电般的速度！你在时间内完成了挑战！");
        } else if (strcmp(number_game_config.mode, "ninja") == 0) {
            mvprintw(3, 0, "忍者般的精准！一击必中！");
        } else if (strcmp(number_game_config.mode, "zombie") == 0) {
            mvprintw(3, 0, "缓慢但稳定！你最终找到了答案！");
        } else if (strcmp(number_game_config.mode, "troll") == 0) {
            mvprintw(3, 0, "哇，你可真的是太牛逼了，\"宇宙无敌\"难度被你通过了");
            mvprintw(4, 0, "用了 %d 次尝试猜中了 %d", 
                   number_game_state.attempts, number_game_state.secret_number);
            mvprintw(5, 0, "建议你赶紧截图发朋友圈炫耀！");
        } else {
            mvprintw(3, 0, "恭喜！你猜对了！数字是 %d", number_game_state.secret_number);
        }
        
        mvprintw(6, 0, "用了 %d 次尝试", number_game_state.attempts);
        
        int final_score = number_game_state.score;
        if (strcmp(number_game_config.mode, "timeattack") == 0) {
            int current_time = time(NULL);
            int elapsed = current_time - number_game_state.start_time;
            int remaining = number_game_config.time_limit - elapsed;
            int time_bonus = remaining * 2;
            final_score += time_bonus;
            mvprintw(7, 0, "时间奖励: +%d 分", time_bonus);
        }
        
        mvprintw(8, 0, "最终得分: %d", final_score);
        
        if (number_game_state.attempts == 1) {
            mvprintw(9, 0, "评价: 神迹！你一定是开了天眼！");
        } else if (number_game_state.attempts <= 3) {
            mvprintw(9, 0, "评价: 天才！简直不可思议！");
        } else if (number_game_state.attempts <= (number_game_config.max_attempts/2)) {
            mvprintw(9, 0, "评价: 优秀！你的直觉很准！");
        } else {
            mvprintw(9, 0, "评价: 不错！坚持就是胜利！");
        }
        
        if ((rand() % 10) == 0) {
            mvprintw(11, 0, "隐藏结局触发！");
            mvprintw(12, 0, "这个数字其实还有另一个含义...");
            mvprintw(13, 0, "它是宇宙的终极答案的%d部分！", 
                   number_game_state.secret_number % 42);
        }
        
        mvprintw(15, 0, "按任意键返回主菜单...");
        refresh();
        getch();
    } else {
        number_game_handle_game_over();
    }
    
    // 记录游戏时间
    time_t end_time = time(NULL);
    int duration = (int)(end_time - number_game_state.start_time);
    number_game_state.total_time += duration;
    
    // 记录游戏次数
    number_game_state.game_count++;
    number_game_save_game_state();
}

void number_game_calculator() {
    number_game_write_log("INFO", "用户进入计算器功能");
    number_game_show_title();
    mvprintw(3, 0, "游戏内置计算器 (真爱粉专享)");
    mvprintw(4, 0, "支持运算: + - * / %% ^ (指数) sqrt (平方根)");
    mvprintw(5, 0, "示例: 2+3*4, sqrt(25), 3^4");
    mvprintw(6, 0, "输入 'q' 返回主菜单");
    refresh();
    
    char expr[NUMBER_MAX_INPUT_LEN];
    
    while (1) {
        mvprintw(8, 0, "输入表达式: ");
        echo();
        getnstr(expr, NUMBER_MAX_INPUT_LEN - 1);
        noecho();
        
        if (strcmp(expr, "q") == 0 || strcmp(expr, "quit") == 0) {
            number_game_write_log("INFO", "用户退出计算器");
            return;
        }
        
        // 1+1彩蛋
        if (strcmp(expr, "1+1") == 0) {
            mvprintw(9, 0, "我不知道你是真傻还是假傻，我建议你小学一年级回炉重造");
            mvprintw(10, 0, "这么简单的问题也要用计算器？答案是2啊！");
            number_game_write_log("INFO", "用户尝试计算1+1，触发彩蛋");
            refresh();
            napms(2000);
            continue;
        }
        
        // 除零彩蛋
        if (strstr(expr, "/0") != NULL || strstr(expr, "/ 0") != NULL) {
            mvprintw(9, 0, "再乱玩就炸给你看");
            mvprintw(10, 0, "数学老师没教过你不能除以零吗？！");
            number_game_write_log("INFO", "用户尝试除以零，触发彩蛋");
            refresh();
            napms(2000);
            continue;
        }
        
        // 简单计算（避免依赖bc）
        char *token = strtok(expr, "+-*/^");
        if (token) {
            double num1 = atof(token);
            char *op = expr + strlen(token);
            
            if (*op) {
                char *next = strtok(NULL, "");
                if (next) {
                    double num2 = atof(next);
                    double result = 0;
                    bool valid = true;
                    
                    switch (*op) {
                        case '+':
                            result = num1 + num2;
                            break;
                        case '-':
                            result = num1 - num2;
                            break;
                        case '*':
                            result = num1 * num2;
                            break;
                        case '/':
                            if (num2 != 0) {
                                result = num1 / num2;
                            } else {
                                mvprintw(9, 0, "错误: 除数不能为零！");
                                valid = false;
                            }
                            break;
                        case '^':
                            result = pow(num1, num2);
                            break;
                        default:
                            valid = false;
                            mvprintw(9, 0, "无效的操作符！");
                            break;
                    }
                    
                    if (valid) {
                        mvprintw(9, 0, "结果: %.4f", result);
                    }
                } else {
                    mvprintw(9, 0, "无效的表达式！");
                }
            } else {
                // 检查是否包含sqrt
                if (strncmp(expr, "sqrt(", 5) == 0) {
                    char *num_str = expr + 5;
                    char *end_ptr = strchr(num_str, ')');
                    if (end_ptr) {
                        *end_ptr = '\0';
                        double num = atof(num_str);
                        if (num >= 0) {
                            mvprintw(9, 0, "结果: %.4f", sqrt(num));
                        } else {
                            mvprintw(9, 0, "错误: 不能对负数开平方根！");
                        }
                    } else {
                        mvprintw(9, 0, "无效的sqrt表达式！");
                    }
                } else {
                    mvprintw(9, 0, "无效的表达式！");
                }
            }
        } else {
            mvprintw(9, 0, "无效的数学表达式！");
            mvprintw(10, 0, "眼睛不要就捐给有需要的人吧");
        }
        refresh();
    }
}

void number_game_calculator_entrance() {
    number_game_show_title();
    mvprintw(3, 0, "果然是作者的真爱粉，计算数学都要用到我");
    mvprintw(4, 0, "如果我没说错的话，你的手机上也有计算器的吧？");
    mvprintw(5, 0, "这里建议你还是用图形化的计算器，防止你老眼昏花没看见");
    mvprintw(6, 0, "如果真的想用，就得答对我一个问题：");
    mvprintw(7, 0, "计算器的英语怎么说？(输入'不知道'可以退出): ");
    refresh();
    
    char answer[NUMBER_MAX_INPUT_LEN];
    echo();
    getnstr(answer, NUMBER_MAX_INPUT_LEN - 1);
    noecho();
    
    if (strcmp(answer, "calculator") == 0 || 
        strcmp(answer, "Calculator") == 0 || 
        strcmp(answer, "CALCULATOR") == 0) {
        mvprintw(8, 0, "回答正确！看来你英语不错嘛~");
        refresh();
        napms(1000);
        number_game_calculator();
    } else if (strcmp(answer, "不知道") == 0) {
        mvprintw(8, 0, "你还是先去学英语吧");
        mvprintw(9, 0, "建议搜索：'计算器 英文'");
        refresh();
        napms(2000);
    } else {
        mvprintw(8, 0, "眼睛不要就捐给有需要的人吧");
        mvprintw(9, 0, "这么简单都不会？是 'calculator' 啊！");
        mvprintw(10, 0, "给你最后一次机会：");
        mvprintw(11, 0, "计算器的英语怎么说？(拼写要完全正确): ");
        refresh();
        
        echo();
        getnstr(answer, NUMBER_MAX_INPUT_LEN - 1);
        noecho();
        
        if (strcmp(answer, "calculator") == 0) {
            mvprintw(12, 0, "终于答对了！勉强让你用吧");
            refresh();
            napms(1000);
            number_game_calculator();
        } else {
            mvprintw(12, 0, "连这都不会，还是别用计算器了");
            mvprintw(13, 0, "正确答案是：calculator");
            refresh();
            napms(2000);
        }
    }
}

void number_game_show_game_achievements() {
    number_game_show_title();
    mvprintw(3, 0, "游戏成就系统");
    mvprintw(4, 0, "================================");
    mvprintw(5, 0, "存储路径: %s", number_time_dir);
    mvprintw(6, 0, "启动次数: %d次", number_game_state.launch_count);
    mvprintw(7, 0, "累计游戏: %d局", number_game_state.game_count);
    mvprintw(8, 0, "游戏时间: %d秒", number_game_state.total_time);
    
    char file_path[NUMBER_MAX_PATH_LEN];
    sprintf(file_path, "%s/first_run.date", number_time_dir);
    FILE* fp = fopen(file_path, "r");
    if (fp) {
        char first_run[20];
        fgets(first_run, sizeof(first_run), fp);
        fclose(fp);
        mvprintw(9, 0, "初次游玩: %s", first_run);
    }
    
    time_t now = time(NULL);
    struct tm* tm_info = localtime(&now);
    mvprintw(10, 0, "最近游玩: %04d-%02d-%02d", 
           tm_info->tm_year + 1900, tm_info->tm_mon + 1, tm_info->tm_mday);
    
    mvprintw(12, 0, "已达成成就:");
    int line = 13;
    if (number_game_state.launch_count >= 10) {
        mvprintw(line++, 0, "熟悉的面孔 - 启动10次");
    }
    if (number_game_state.launch_count >= 100) {
        mvprintw(line++, 0, "忠实玩家 - 启动100次");
    }
    if (number_game_state.launch_count >= 1000) {
        mvprintw(line++, 0, "游戏伙伴 - 启动1000次");
    }
    if (number_game_state.game_count >= 10) {
        mvprintw(line++, 0, "数字探险家 - 完成10局游戏");
    }
    if (number_game_state.game_count >= 50) {
        mvprintw(line++, 0, "数字大师 - 完成50局游戏");
    }
    if (number_game_state.game_count >= 100) {
        mvprintw(line++, 0, "数字传奇 - 完成100局游戏");
    }
    if (number_game_state.total_time >= 3600) {
        mvprintw(line++, 0, "时间投入者 - 总游戏时间超过1小时");
    }
    if (number_game_state.total_time >= 36000) {
        mvprintw(line++, 0, "时间大师 - 总游戏时间超过10小时");
    }
    
    mvprintw(line++, 0, "");
    mvprintw(line++, 0, "即将达成:");
    if (number_game_state.launch_count < 10) {
        mvprintw(line++, 0, "熟悉的面孔 - 还需 %d 次启动", 10 - number_game_state.launch_count);
    } else if (number_game_state.launch_count < 100) {
        mvprintw(line++, 0, "忠实玩家 - 还需 %d 次启动", 100 - number_game_state.launch_count);
    } else if (number_game_state.launch_count < 1000) {
        mvprintw(line++, 0, "游戏伙伴 - 还需 %d 次启动", 1000 - number_game_state.launch_count);
    } else {
        mvprintw(line++, 0, "你已经达成了所有启动次数成就！");
    }
    
    mvprintw(line+2, 0, "按任意键返回主菜单...");
    refresh();
    getch();
}

void number_game_main_menu() {
    char input[NUMBER_MAX_INPUT_LEN];
    int choice;
    
    // 检查游戏时间上限
    if ((long long)number_game_state.total_time >= NUMBER_MAX_GAME_TIME) {
        clear();
        mvprintw(3, 0, "时间奇迹：你已经达到了70年游戏时间上限！");
        mvprintw(4, 0, "这是一个不可思议的里程碑！");
        mvprintw(5, 0, "70年的游戏时间，相当于一个人的整个生命周期！");
        mvprintw(7, 0, "你已经超越了游戏的界限，");
        mvprintw(8, 0, "成为了数字世界永恒的存在。");
        mvprintw(10, 0, "作为奖励，你将获得：");
        mvprintw(11, 0, "永恒数字大师称号");
        mvprintw(12, 0, "无限游戏特权");
        mvprintw(13, 0, "所有数字对你来说都是透明的");
        mvprintw(15, 0, "感谢你一生的陪伴！");
        refresh();
        napms(5000);
        return;
    } else if (number_game_state.total_time >= NUMBER_WARNING_THRESHOLD) {
        int years_played = number_game_state.total_time / (365 * 24 * 3600);
        int years_left = 70 - years_played;
        
        clear();
        mvprintw(3, 0, "时间提醒：你已经玩了%d年！", years_played);
        mvprintw(4, 0, "距离70年游戏时间上限还有%d年。", years_left);
        mvprintw(6, 0, "你知道吗？70年是大多数人类的平均寿命，");
        mvprintw(7, 0, "而你几乎将一生都献给了这个数字游戏！");
        mvprintw(9, 0, "这究竟是执着还是热爱？");
        mvprintw(10, 0, "无论如何，你的坚持令人敬佩！");
        refresh();
        napms(3000);
    }
    
    // 显示欢迎信息
    if (number_game_state.launch_count == 1) {
        mvprintw(3, 0, "欢迎初次体验猜数字游戏！");
        mvprintw(4, 0, "希望你喜欢这个数字世界！");
    } else if (number_game_state.launch_count == 10) {
        mvprintw(3, 0, "第10次启动！开始熟悉这个游戏了！");
    } else if (number_game_state.launch_count == 100) {
        mvprintw(3, 0, "第100次启动！你真是忠实玩家！");
    } else {
        mvprintw(3, 0, "游戏统计:");
        mvprintw(4, 0, "启动次数: %d次", number_game_state.launch_count);
        mvprintw(5, 0, "累计游戏: %d局", number_game_state.game_count);
        mvprintw(6, 0, "游戏时间: %d秒", number_game_state.total_time);
    }
    
    if (number_game_state.launch_count >= 1000) {
        switch (rand() % 5) {
            case 0: mvprintw(7, 0, "（你确定不是把启动游戏当成了呼吸吗？）"); break;
            case 1: mvprintw(7, 0, "（这个游戏是不是你的桌面背景？）"); break;
            case 2: mvprintw(7, 0, "（你的手指还记得其他应用吗？）"); break;
            case 3: mvprintw(7, 0, "（要不要考虑给这个游戏写个传记？）"); break;
            case 4: mvprintw(7, 0, "（我猜你的手机里只有这个游戏吧？）"); break;
        }
    }
    
    mvprintw(9, 0, "按任意键继续...");
    refresh();
    getch();
    
    while (1) {
        number_game_show_title();
        mvprintw(3, 0, "主菜单 (启动: %d次 | 游戏: %d局 | 时长: %d秒)", 
               number_game_state.launch_count, number_game_state.game_count, number_game_state.total_time);
        mvprintw(4, 0, "1. 开始游戏（选择模式）");
        mvprintw(5, 0, "2. 游戏成就");
        mvprintw(6, 0, "3. 关于 %s", NUMBER_GAME_VERSION);
        mvprintw(7, 0, "4. 计算器工具");
        mvprintw(8, 0, "5. 检查系统配置");
        mvprintw(9, 0, "0. 退出游戏");
        
        mvprintw(11, 0, "请选择 [0-5]: ");
        refresh();
        
        echo();
        choice = getch() - '0';
        noecho();
        
        switch (choice) {
            case 1:
                number_game_play_game();
                break;
            case 2:
                number_game_show_game_achievements();
                break;
            case 3:
                number_game_show_title();
                mvprintw(3, 0, "猜数字游戏 %s", NUMBER_GAME_VERSION);
                mvprintw(4, 0, "终极特性:");
                mvprintw(5, 0, "• 9种独特游戏模式");
                mvprintw(6, 0, "• 混沌随机系统");
                mvprintw(7, 0, "• 限时挑战");
                mvprintw(8, 0, "• 特殊技能系统");
                mvprintw(9, 0, "• 真爱粉计算器");
                mvprintw(10, 0, "• 摆烂人生模式");
                mvprintw(11, 0, "• 嘲讽提示系统");
                mvprintw(12, 0, "• 隐藏内容和彩蛋");
                mvprintw(13, 0, "• 完整日志系统");
                mvprintw(15, 0, "C语言实现的终极挑战");
                mvprintw(16, 0, "2025年 - 不可能版本");
                
                mvprintw(18, 0, "按任意键返回主菜单...");
                refresh();
                getch();
                break;
            case 4:
                number_game_calculator_entrance();
                break;
            case 5:
                number_game_show_title();
                mvprintw(3, 0, "系统配置检查");
                mvprintw(4, 0, "================================");
                mvprintw(5, 0, "游戏记录:");
                mvprintw(6, 0, "启动次数: %d次", number_game_state.launch_count);
                mvprintw(7, 0, "游戏次数: %d局", number_game_state.game_count);
                mvprintw(8, 0, "游戏时间: %d秒", number_game_state.total_time);
                mvprintw(9, 0, "存储路径: %s", number_time_dir);
                mvprintw(10, 0, "日志文件: %s", number_log_file);
                mvprintw(11, 0, "================================");
                
                mvprintw(13, 0, "按任意键返回主菜单...");
                refresh();
                getch();
                break;
            case 0:
                clear();
                if (number_game_state.game_count == 0) {
                    mvprintw(3, 0, "你不玩进来干啥呀？");
                    mvprintw(4, 0, "好吧，那再见咯~");
                } else {
                    mvprintw(3, 0, "感谢游玩猜数字游戏 %s！", NUMBER_GAME_VERSION);
                }
                mvprintw(5, 0, "你本次共玩了 %d 局游戏", number_game_state.game_count);
                refresh();
                napms(2000);
                exit(0);
            default:
                mvprintw(12, 0, "眼睛不要就捐给有需要的人吧");
                mvprintw(13, 0, "请看清楚选项是0-5啊！");
                refresh();
                napms(2000);
                break;
        }
    }
}

void number_game_start() {
    srand(time(NULL));
    
    // 初始化
    number_game_create_directories();
    number_game_write_log("INFO", "猜数字游戏启动");
    
    number_game_load_game_state();
    
    number_game_write_log("INFO", "系统初始化完成");
    clear();
    mvprintw(3, 0, "猜数字游戏 %s 启动成功！", NUMBER_GAME_VERSION);
    mvprintw(4, 0, "数据存储在: %s", NUMBER_DATA_ROOT);
    refresh();
    napms(1000);
    
    // 进入主菜单
    number_game_main_menu();
}

// 贪吃蛇游戏函数
void snake_init(SnakeGame *game) {
    // 初始化蛇
    game->length = 3;
    for (int i = 0; i < game->length; i++) {
        game->body[i].x = SNAKE_WIDTH / 2 - i;
        game->body[i].y = SNAKE_HEIGHT / 2;
    }
    game->direction = DIR_RIGHT;
    game->game_over = false;
    
    // 生成食物
    srand(time(NULL));
    game->food_x = rand() % SNAKE_WIDTH;
    game->food_y = rand() % SNAKE_HEIGHT;
}

bool snake_check_collision(SnakeGame *game, int x, int y) {
    // 检查是否撞墙
    if (x < 0 || x >= SNAKE_WIDTH || y < 0 || y >= SNAKE_HEIGHT) {
        return true;
    }
    
    // 检查是否撞到自己
    for (int i = 0; i < game->length; i++) {
        if (game->body[i].x == x && game->body[i].y == y) {
            return true;
        }
    }
    
    return false;
}

void snake_move(SnakeGame *game) {
    // 保存蛇头位置
    int new_x = game->body[0].x;
    int new_y = game->body[0].y;
    
    // 计算新蛇头位置
    switch (game->direction) {
        case DIR_RIGHT:
            new_x++;
            break;
        case DIR_LEFT:
            new_x--;
            break;
        case DIR_UP:
            new_y--;
            break;
        case DIR_DOWN:
            new_y++;
            break;
    }
    
    // 检查碰撞
    if (snake_check_collision(game, new_x, new_y)) {
        game->game_over = true;
        return;
    }
    
    // 移动蛇身
    for (int i = game->length - 1; i > 0; i--) {
        game->body[i] = game->body[i - 1];
    }
    
    // 设置新蛇头
    game->body[0].x = new_x;
    game->body[0].y = new_y;
    
    // 检查是否吃到食物
    if (new_x == game->food_x && new_y == game->food_y) {
        // 增加长度
        if (game->length < MAX_SNAKE_LENGTH) {
            game->body[game->length] = game->body[game->length - 1];
            game->length++;
        }
        
        // 生成新食物
                bool valid_food = false;
        while (!valid_food) {
            game->food_x = rand() % SNAKE_WIDTH;
            game->food_y = rand() % SNAKE_HEIGHT;
            
            valid_food = true;
            for (int i = 0; i < game->length; i++) {
                if (game->body[i].x == game->food_x && game->body[i].y == game->food_y) {
                    valid_food = false;
                    break;
                }
            }
        }
    }
}

void snake_draw_board(SnakeGame *game) {
    clear();
    
    // 绘制顶部边界
    mvprintw(0, 0, "贪吃蛇游戏 - 分数: %d", game->length - 3);
    mvprintw(1, 0, "控制: 方向键移动, [Q]退出, [空格]暂停");
    mvprintw(2, 0, "当前分数: %d", game->length - 3);
    
    // 绘制游戏区域
    for (int row = 0; row < SNAKE_HEIGHT; row++) {
        for (int col = 0; col < SNAKE_WIDTH; col++) {
            int display_row = row + 4;
            int display_col = col * 2 + 2;
            
            // 检查是否是蛇身
            bool is_snake = false;
            for (int i = 0; i < game->length; i++) {
                if (game->body[i].x == col && game->body[i].y == row) {
                    is_snake = true;
                    if (i == 0) {
                        // 蛇头
                        attron(COLOR_PAIR(2));
                        mvprintw(display_row, display_col, "▓");
                        attroff(COLOR_PAIR(2));
                    } else {
                        // 蛇身
                        attron(COLOR_PAIR(3));
                        mvprintw(display_row, display_col, "▒");
                        attroff(COLOR_PAIR(3));
                    }
                    break;
                }
            }
            
            // 检查是否是食物
            if (!is_snake && col == game->food_x && row == game->food_y) {
                attron(COLOR_PAIR(4));
                mvprintw(display_row, display_col, "★");
                attroff(COLOR_PAIR(4));
            } else if (!is_snake) {
                // 空白区域
                mvprintw(display_row, display_col, "·");
            }
        }
    }
    
    if (game->game_over) {
        mvprintw(SNAKE_HEIGHT + 5, 2, "游戏结束! 最终分数: %d", game->length - 3);
        mvprintw(SNAKE_HEIGHT + 6, 2, "按任意键返回主菜单...");
    }
    
    refresh();
}

void snake_game() {
    // 初始化颜色
    start_color();
    init_pair(1, COLOR_WHITE, COLOR_BLACK);  // 默认颜色
    init_pair(2, COLOR_GREEN, COLOR_BLACK);  // 蛇头
    init_pair(3, COLOR_YELLOW, COLOR_BLACK); // 蛇身
    init_pair(4, COLOR_RED, COLOR_BLACK);    // 食物
    
    // 初始化游戏
    SnakeGame game;
    snake_init(&game);
    
    // 设置ncurses模式
    timeout(100);  // 100毫秒超时
    noecho();
    curs_set(0);
    
    bool paused = false;
    
    while (!game.game_over) {
        // 处理输入
        int ch = getch();
        switch (ch) {
            case KEY_UP:
                if (game.direction != DIR_DOWN) {
                    game.direction = DIR_UP;
                }
                break;
            case KEY_DOWN:
                if (game.direction != DIR_UP) {
                    game.direction = DIR_DOWN;
                }
                break;
            case KEY_LEFT:
                if (game.direction != DIR_RIGHT) {
                    game.direction = DIR_LEFT;
                }
                break;
            case KEY_RIGHT:
                if (game.direction != DIR_LEFT) {
                    game.direction = DIR_RIGHT;
                }
                break;
            case ' ':
                paused = !paused;
                if (paused) {
                    mvprintw(SNAKE_HEIGHT + 5, 2, "游戏暂停，按空格继续...");
                    refresh();
                    while (getch() != ' ') {
                        // 等待空格键
                    }
                    paused = false;
                }
                break;
            case 'q':
            case 'Q':
                return;
        }
        
        if (!paused) {
            // 移动蛇
            snake_move(&game);
        }
        
        // 绘制游戏
        snake_draw_board(&game);
        
        if (game.game_over) {
            break;
        }
    }
    
    // 等待按键
    timeout(-1);
    getch();
    
    // 恢复ncurses设置
    curs_set(1);
    echo();
    timeout(0);
}

// 扫雷游戏函数
void mine_initialize_board(char board[MINE_HEIGHT][MINE_WIDTH], char fill) {
    for (int i = 0; i < MINE_HEIGHT; i++) {
        for (int j = 0; j < MINE_WIDTH; j++) {
            board[i][j] = fill;
        }
    }
}

void mine_place_mines() {
    srand(time(NULL));
    int mines_placed = 0;
    
    while (mines_placed < MINE_COUNT) {
        int x = rand() % MINE_WIDTH;
        int y = rand() % MINE_HEIGHT;
        if (mine_board[y][x] != '*') {
            mine_board[y][x] = '*';
            mines_placed++;
        }
    }
}

bool mine_is_valid(int x, int y) {
    return (x >= 0 && x < MINE_WIDTH && y >= 0 && y < MINE_HEIGHT);
}

int mine_count_adjacent_mines(int x, int y) {
    int count = 0;
    for (int i = -1; i <= 1; i++) {
        for (int j = -1; j <= 1; j++) {
            int nx = x + j;
            int ny = y + i;
            if (mine_is_valid(nx, ny) && mine_board[ny][nx] == '*') {
                count++;
            }
        }
    }
    return count;
}

void mine_reveal_cells(int x, int y) {
    if (!mine_is_valid(x, y) || mine_display[y][x] != '-') {
        return;
    }
    
    int mine_count = mine_count_adjacent_mines(x, y);
    mine_display[y][x] = mine_count + '0';
    cells_revealed++;
    
    if (mine_count == 0) {
        for (int i = -1; i <= 1; i++) {
            for (int j = -1; j <= 1; j++) {
                if (i == 0 && j == 0) continue;
                mine_reveal_cells(x + j, y + i);
            }
        }
    }
}

void mine_print_board() {
    clear();
    printw("扫雷游戏\n");
    printw("剩余雷数: %d\n\n", mines_remaining);
    
    // 打印列号
    printw("   ");
    for (int j = 0; j < MINE_WIDTH; j++) {
        printw("%2d ", j);
    }
    printw("\n");
    
    for (int i = 0; i < MINE_HEIGHT; i++) {
        printw("%2d ", i); // 打印行号
        for (int j = 0; j < MINE_WIDTH; j++) {
            printw(" %c ", mine_display[i][j]);
        }
        printw("\n");
    }
    printw("\n指令: [坐标] 翻格子, [f+坐标] 标记, [q] 退出\n");
    printw("示例: 5 6 翻格子, f 5 6 标记/取消标记\n");
    refresh();
}

bool mine_check_win() {
    return cells_revealed == (MINE_HEIGHT * MINE_WIDTH - MINE_COUNT);
}

void mine_reveal_all() {
    for (int i = 0; i < MINE_HEIGHT; i++) {
        for (int j = 0; j < MINE_WIDTH; j++) {
            if (mine_board[i][j] == '*') {
                mine_display[i][j] = '*';
            } else {
                int count = mine_count_adjacent_mines(j, i);
                if (mine_display[i][j] == '-') {
                    mine_display[i][j] = count + '0';
                }
            }
        }
    }
}

void minesweeper_game() {
    // 初始化游戏
    mine_initialize_board(mine_board, '-');
    mine_initialize_board(mine_display, '-');
    mine_place_mines();
    mines_remaining = MINE_COUNT;
    cells_revealed = 0;
    
    bool game_running = true;
    
    while (game_running) {
        mine_print_board();
        
        char input[20];
        int x, y;
        char command = 'r'; // 默认是翻格子
        
        echo();
        printw("请输入操作: ");
        getnstr(input, sizeof(input) - 1);
        noecho();
        
        if (strlen(input) == 0) {
            continue;
        }
        
        if (input[0] == 'q' || input[0] == 'Q') {
            break;
        }
        
        int args_read = 0;
        if (input[0] == 'f' || input[0] == 'F') {
            command = 'f';
            args_read = sscanf(input + 1, "%d %d", &x, &y);
        } else {
            command = 'r';
            args_read = sscanf(input, "%d %d", &x, &y);
        }
        
        if (args_read != 2 || !mine_is_valid(x, y)) {
            mvprintw(20, 0, "无效的输入! 请重新输入。");
            refresh();
            getch();
            continue;
        }
        
        if (command == 'f') {
            // 标记/取消标记
            if (mine_display[y][x] == 'F') {
                mine_display[y][x] = '-';
                mines_remaining++;
            } else if (mine_display[y][x] == '-') {
                mine_display[y][x] = 'F';
                mines_remaining--;
            }
        } else {
            // 翻格子
            if (mine_board[y][x] == '*') {
                mine_reveal_all();
                mine_print_board();
                printw("游戏结束! 你踩到地雷了!\n");
                printw("按任意键继续...");
                refresh();
                getch();
                break;
            } else if (mine_display[y][x] == '-') {
                mine_reveal_cells(x, y);
                
                if (mine_check_win()) {
                    mine_reveal_all();
                    mine_print_board();
                    printw("恭喜! 你赢了!\n");
                    printw("按任意键继续...");
                    refresh();
                    getch();
                    break;
                }
            }
        }
    }
}

// 井字棋游戏函数
void tic_tac_toe_draw_board() {
    clear();
    printw("井字棋游戏 - 当前玩家: %c\n\n", currentPlayer);
    
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            printw(" %c ", tic_tac_toe_board[i][j]);
            if (j < 2) printw("|");
        }
        printw("\n");
        if (i < 2) printw("---+---+---\n");
    }
    printw("\n输入1-9选择位置, [r]重新开始, [q]退出\n");
}

bool tic_tac_toe_check_win() {
    // 检查行
    for (int i = 0; i < 3; i++) {
        if (tic_tac_toe_board[i][0] == tic_tac_toe_board[i][1] && 
            tic_tac_toe_board[i][1] == tic_tac_toe_board[i][2]) {
            return true;
        }
    }
    
    // 检查列
    for (int i = 0; i < 3; i++) {
        if (tic_tac_toe_board[0][i] == tic_tac_toe_board[1][i] && 
            tic_tac_toe_board[1][i] == tic_tac_toe_board[2][i]) {
            return true;
        }
    }
    
    // 检查对角线
    if (tic_tac_toe_board[0][0] == tic_tac_toe_board[1][1] && 
        tic_tac_toe_board[1][1] == tic_tac_toe_board[2][2]) {
        return true;
    }
    
    if (tic_tac_toe_board[0][2] == tic_tac_toe_board[1][1] && 
        tic_tac_toe_board[1][1] == tic_tac_toe_board[2][0]) {
        return true;
    }
    
    return false;
}

bool tic_tac_toe_check_draw() {
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            if (tic_tac_toe_board[i][j] != 'X' && tic_tac_toe_board[i][j] != 'O') {
                return false;
            }
        }
    }
    return true;
}

void tic_tac_toe_reset_board() {
    char initial_board[3][3] = {{'1', '2', '3'}, {'4', '5', '6'}, {'7', '8', '9'}};
    memcpy(tic_tac_toe_board, initial_board, sizeof(initial_board));
    currentPlayer = 'X';
}

void tic_tac_toe_game() {
    bool game_running = true;
    
    while (game_running) {
        tic_tac_toe_draw_board();
        
        char input[10];
        echo();
        printw("请输入选择: ");
        getnstr(input, sizeof(input) - 1);
        noecho();
        
        if (input[0] == 'q' || input[0] == 'Q') {
            break;
        }
        
        if (input[0] == 'r' || input[0] == 'R') {
            tic_tac_toe_reset_board();
            continue;
        }
        
        int position = input[0] - '0';
        if (position < 1 || position > 9) {
            mvprintw(10, 0, "无效输入! 请输入1-9之间的数字。");
            refresh();
            getch();
            continue;
        }
        
        int row = (position - 1) / 3;
        int col = (position - 1) % 3;
        
        if (tic_tac_toe_board[row][col] == 'X' || tic_tac_toe_board[row][col] == 'O') {
            mvprintw(10, 0, "该位置已被占用! 请选择其他位置。");
            refresh();
            getch();
            continue;
        }
        
        tic_tac_toe_board[row][col] = currentPlayer;
        
        if (tic_tac_toe_check_win()) {
            tic_tac_toe_draw_board();
            printw("\n玩家 %c 获胜!\n", currentPlayer);
            printw("按任意键继续...");
            refresh();
            getch();
            tic_tac_toe_reset_board();
        } else if (tic_tac_toe_check_draw()) {
            tic_tac_toe_draw_board();
            printw("\n平局!\n");
            printw("按任意键继续...");
            refresh();
            getch();
            tic_tac_toe_reset_board();
        } else {
            currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
        }
    }
}

// 主程序入口
int main() {
    // 初始化ncurses
    initscr();
    cbreak();
    noecho();
    keypad(stdscr, TRUE);
    curs_set(1);
    
    // 初始化curl
    curl_global_init(CURL_GLOBAL_DEFAULT);
    
    // 初始化语言
    LangStrings lang;
    init_lang_strings(&lang, LANG_ZH);
    
    // 初始化下载信息
    DownloadInfo download_info = {0};
    strcpy(download_info.save_path, ".");
    
    // 初始化倒计时
    countdown_init(&countdown_timer, 3600); // 默认1小时
    
    // 初始化简单计时器
    simple_timer_init(&simple_timer);
    
    bool running = true;
    
    while (running) {
        show_ui(&lang, &download_info);
        
        int ch = getch();
        
        switch (ch) {
            case '1': // 浏览路径
                {
                    echo();
                    mvprintw(14, 0, "请输入保存路径: ");
                    getnstr(download_info.save_path, sizeof(download_info.save_path) - 1);
                    noecho();
                }
                break;
                
            case '2': // 开始下载
                {
                    echo();
                    mvprintw(14, 0, "请输入下载URL: ");
                    getnstr(download_info.url, sizeof(download_info.url) - 1);
                    noecho();
                    
                    if (strlen(download_info.url) == 0) {
                        mvprintw(15, 0, "%s", lang.err_no_url);
                        refresh();
                        getch();
                        break;
                    }
                    
                    if (strlen(download_info.save_path) == 0) {
                        mvprintw(15, 0, "%s", lang.err_no_path);
                        refresh();
                        getch();
                        break;
                    }
                    
                    // 检查磁盘空间
                    uint64_t free_space = get_free_disk_space(download_info.save_path);
                    if (free_space < 1024 * 1024) { // 小于1MB
                        mvprintw(15, 0, "%s", lang.err_low_space);
                        refresh();
                        getch();
                        break;
                    }
                    
                    // 获取文件信息
                    if (!get_file_info(&download_info)) {
                        mvprintw(15, 0, "%s", lang.err_fetch_info);
                        refresh();
                        getch();
                        break;
                    }
                    
                    mvprintw(15, 0, "文件大小: %ld bytes, 文件名: %s", 
                            download_info.total_size, download_info.filename);
                    mvprintw(16, 0, "开始下载...");
                    refresh();
                    
                    // 开始下载
                    if (download_file(&download_info, NULL)) {
                        mvprintw(17, 0, "%s%s", lang.success, download_info.filename);
                    } else {
                        mvprintw(17, 0, "%s", lang.failed);
                    }
                    refresh();
                    getch();
                }
                break;
                
            case 'c':
            case 'C': // 计算器
                number_game_calculator_entrance();
                break;
                
            case 't':
            case 'T': // 井字棋
                tic_tac_toe_game();
                break;
                
            case 'm':
            case 'M': // 扫雷
                minesweeper_game();
                break;
                
            case 's':
            case 'S': // 贪吃蛇
                snake_game();
                break;
                
            case 'n':
            case 'N': // 猜数字
                number_game_start();
                break;
                
            case 'd':
            case 'D': // 倒计时
                countdown_game();
                break;
                
            case 'e':
            case 'E': // 简单计时器 (新增)
                simple_timer_game();
                break;
                
            case 'l':
            case 'L': // 切换语言
                toggle_language(&lang);
                break;
                
            case 27: // ESC键
                running = false;
                break;
                
            default:
                break;
        }
        
        // 更新计时器显示
        countdown_update(&countdown_timer);
        simple_timer_update(&simple_timer);
    }
    
    // 清理资源
    endwin();
    curl_global_cleanup();
    
    printf("感谢使用多功能工具箱！\n");
    return 0;
}
