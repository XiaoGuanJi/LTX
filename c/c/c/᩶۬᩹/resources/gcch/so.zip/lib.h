#ifndef LIB_H
#define LIB_H

int add(int a, int b); // 仅声明

#endif
