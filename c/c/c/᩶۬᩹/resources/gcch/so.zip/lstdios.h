/**
 * Copyright [2023] [LAOLIPEF]
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef L_STDIOS_H
#define L_STDIOS_H

// Linux ARM64 系统调用号
#define L_SYS_WRITE   64
#define L_SYS_READ    63
#define L_SYS_EXIT    93
#define L_SYS_BRK     214
#define L_SYS_OPENAT  56
#define L_SYS_CLOSE   57
#define L_SYS_LSEEK   62
#define L_SYS_GETPID  172
#define L_SYS_TIME    113
#define L_SYS_NANOSLEEP 101
#define L_SYS_GETCWD  17
#define L_SYS_CHDIR   49

// 文件描述符
#define L_STDIN_FILENO   0
#define L_STDOUT_FILENO  1
#define L_STDERR_FILENO  2

// 文件打开标志
#define L_O_RDONLY    00
#define L_O_WRONLY    01
#define L_O_RDWR      02
#define L_O_CREAT     0100
#define L_O_TRUNC     01000
#define L_O_APPEND    02000
#define L_O_EXCL      0200

// 错误码 - 基于拼音九键编码
#define L_SUCCESS     0
#define L_EOF        -1
#define L_ERROR      -2

// 系统相关错误
#define L_ENOMEM     -41
#define L_EINVAL     -42
#define L_ENOENT     -45
#define L_EACCES     -46
#define L_EEXIST     -47
#define L_EISDIR     -48
#define L_ENOTDIR    -49

// 文件IO错误
#define L_EFBIG      -52
#define L_ENOSPC     -53
#define L_EIO        -54
#define L_EROFS      -55
#define L_EBADF      -56

// 进程相关错误
#define L_ECHILD     -64
#define L_EDEADLK    -65
#define L_EAGAIN     -66
#define L_ENOMSG     -67
#define L_EINTR      -68

// 网络相关错误
#define L_ENETDOWN   -73
#define L_ENETUNREACH -74
#define L_ECONNREFUSED -75
#define L_ETIMEDOUT  -76
#define L_ECONNRESET -77

// 其他错误
#define L_ENOSYS     -82
#define L_ENOTSUP    -83
#define L_EOVERFLOW  -84
#define L_ERANGE     -85
#define L_EILSEQ     -86

// 颜色定义
#define L_COLOR_BLACK   0
#define L_COLOR_RED     1
#define L_COLOR_GREEN   2
#define L_COLOR_YELLOW  3
#define L_COLOR_BLUE    4
#define L_COLOR_MAGENTA 5
#define L_COLOR_CYAN    6
#define L_COLOR_WHITE   7
#define L_COLOR_BRIGHT  8

// 布尔类型
#define L_TRUE  1
#define L_FALSE 0
typedef int l_bool;

// 文件结构
typedef struct {
    int fd;
    int pos;
    int eof;
    int error;
    int mode;
} L_FILE;

// 时间结构
typedef struct {
    long sec;
    long nsec;
} L_TIMESPEC;

// 目录条目
typedef struct {
    int ino;
    char name[256];
} L_DIRENT;

// 字符串缓冲
typedef struct {
    char *data;
    int length;
    int capacity;
} L_STRING;

// 错误信息结构
typedef struct {
    int code;
    const char *name;
    const char *desc;
} L_ERROR_INFO;

// ============================================
// 函数声明（解决编译错误的关键）
// ============================================

// 基础IO函数声明
static void l_putchar(char c);
static char l_getchar();
static void l_puts(const char *str);
static void l_print(const char *str);
static void l_putint(int num);
static void l_puthex(unsigned int num);
static void l_printf(const char *format, ...);

// 控制台颜色函数声明
static void l_set_color(int fg, int bg);
static void l_reset_color();

// 字符串函数声明
static int l_strlen(const char *str);
static char* l_strcpy(char *dest, const char *src);
static int l_strcmp(const char *s1, const char *s2);
static int l_atoi(const char *str);
static char* l_itoa(int num, char *str, int base);

// 内存函数声明
static void* l_malloc(int size);
static void l_free(void *ptr);
static void l_free_all();
static int l_get_mem_used();

// 工具函数声明
static int l_abs(int x);
static int l_max(int a, int b);
static int l_min(int a, int b);

// ============================================
// 函数实现
// ============================================

// 系统调用封装
static inline long l_syscall(long number, long arg1, long arg2, long arg3, 
                            long arg4, long arg5, long arg6) {
    long ret;
    register long x8 __asm__("x8") = number;
    register long x0 __asm__("x0") = arg1;
    register long x1 __asm__("x1") = arg2;
    register long x2 __asm__("x2") = arg3;
    register long x3 __asm__("x3") = arg4;
    register long x4 __asm__("x4") = arg5;
    register long x5 __asm__("x5") = arg6;
    
    __asm__ __volatile__(
        "svc 0"
        : "=r"(x0)
        : "r"(x0), "r"(x1), "r"(x2), "r"(x3), "r"(x4), "r"(x5), "r"(x8)
        : "memory", "cc"
    );
    
    ret = x0;
    if (ret < 0) {
        return -ret;
    }
    return ret;
}

// IO函数实现
static int l_write(int fd, const char *buf, int count) {
    return l_syscall(L_SYS_WRITE, fd, (long)buf, count, 0, 0, 0);
}

static int l_read(int fd, char *buf, int count) {
    return l_syscall(L_SYS_READ, fd, (long)buf, count, 0, 0, 0);
}

static void l_putchar(char c) {
    l_write(L_STDOUT_FILENO, &c, 1);
}

static char l_getchar() {
    char c;
    int n = l_read(L_STDIN_FILENO, &c, 1);
    return (n == 1) ? c : L_EOF;
}

static void l_puts(const char *str) {
    int len = 0;
    while (str[len]) len++;
    l_write(L_STDOUT_FILENO, str, len);
    l_putchar('\n');
}

static void l_print(const char *str) {
    int len = 0;
    while (str[len]) len++;
    l_write(L_STDOUT_FILENO, str, len);
}

// 数字格式化
static void l_putint(int num) {
    char buf[32];
    int i = 0, is_negative = 0;
    
    if (num < 0) {
        is_negative = 1;
        num = -num;
    } else if (num == 0) {
        buf[i++] = '0';
    }
    
    while (num > 0) {
        buf[i++] = (num % 10) + '0';
        num /= 10;
    }
    
    if (is_negative) {
        buf[i++] = '-';
    }
    
    for (int j = i - 1; j >= 0; j--) {
        l_putchar(buf[j]);
    }
}

static void l_puthex(unsigned int num) {
    char buf[16];
    const char *hex = "0123456789ABCDEF";
    int i = 0;
    
    if (num == 0) {
        buf[i++] = '0';
    }
    
    while (num > 0) {
        buf[i++] = hex[num & 0xF];
        num >>= 4;
    }
    
    l_print("0x");
    for (int j = i - 1; j >= 0; j--) {
        l_putchar(buf[j]);
    }
}

// 格式化输出
static void l_printf(const char *format, ...) {
    const char *p = format;
    char c;
    
    char *args = (char*)&format + sizeof(char*);
    
    while ((c = *p++)) {
        if (c == '%') {
            c = *p++;
            switch (c) {
                case 's': {
                    const char *s = *((const char**)args);
                    args += sizeof(char*);
                    if (s) l_print(s);
                    break;
                }
                case 'd': {
                    int num = *((int*)args);
                    args += sizeof(int);
                    l_putint(num);
                    break;
                }
                case 'c': {
                    char ch = *((char*)args);
                    args += sizeof(char);
                    l_putchar(ch);
                    break;
                }
                case 'x': {
                    unsigned int num = *((unsigned int*)args);
                    args += sizeof(unsigned int);
                    l_puthex(num);
                    break;
                }
                case 'p': {
                    void *ptr = *((void**)args);
                    args += sizeof(void*);
                    l_print("0x");
                    l_puthex((unsigned long)ptr);
                    break;
                }
                case '%':
                    l_putchar('%');
                    break;
                default:
                    l_putchar('%');
                    l_putchar(c);
                    break;
            }
        } else {
            l_putchar(c);
        }
    }
}

// 字符串处理
static int l_strlen(const char *str) {
    int len = 0;
    while (str[len]) len++;
    return len;
}

static char* l_strcpy(char *dest, const char *src) {
    int i = 0;
    while (src[i]) {
        dest[i] = src[i];
        i++;
    }
    dest[i] = '\0';
    return dest;
}

static char* l_strcat(char *dest, const char *src) {
    int i = l_strlen(dest);
    l_strcpy(dest + i, src);
    return dest;
}

static int l_strcmp(const char *s1, const char *s2) {
    while (*s1 && (*s1 == *s2)) {
        s1++;
        s2++;
    }
    return *(const unsigned char*)s1 - *(const unsigned char*)s2;
}

// 内存操作
static void* l_memset(void *ptr, int value, int size) {
    char *p = (char*)ptr;
    for (int i = 0; i < size; i++) {
        p[i] = (char)value;
    }
    return ptr;
}

static void* l_memcpy(void *dest, const void *src, int size) {
    char *d = (char*)dest;
    const char *s = (const char*)src;
    for (int i = 0; i < size; i++) {
        d[i] = s[i];
    }
    return dest;
}

// 内存分配
#define L_POOL_SIZE (4 * 1024 * 1024)
static char l_mem_pool[L_POOL_SIZE];
static int l_mem_used = 0;

typedef struct {
    int size;
    int used;
} L_MEM_BLOCK;

static void* l_malloc(int size) {
    if (size <= 0) return 0;
    
    int total = ((size + sizeof(L_MEM_BLOCK) + 7) & ~7);
    
    if (l_mem_used + total > L_POOL_SIZE) {
        return 0;
    }
    
    L_MEM_BLOCK *block = (L_MEM_BLOCK*)&l_mem_pool[l_mem_used];
    block->size = size;
    block->used = 1;
    
    void *ptr = (void*)(block + 1);
    l_mem_used += total;
    
    return ptr;
}

static void l_free(void *ptr) {
    if (!ptr) return;
    L_MEM_BLOCK *block = (L_MEM_BLOCK*)ptr - 1;
    block->used = 0;
}

static void l_free_all() {
    l_mem_used = 0;
}

static int l_get_mem_used() {
    return l_mem_used;
}

// 控制台颜色
static void l_clear() {
    l_print("\033[2J\033[H");
}

static void l_set_color(int fg, int bg) {
    char buf[16];
    int len = 0;
    
    buf[len++] = '\033';
    buf[len++] = '[';
    
    if (fg >= 0 && fg < 16) {
        if (fg >= 8) {
            buf[len++] = '1';
            buf[len++] = ';';
            fg -= 8;
        }
        buf[len++] = '3';
        buf[len++] = '0' + fg;
    }
    
    if (bg >= 0 && bg < 8) {
        if (fg >= 0) buf[len++] = ';';
        buf[len++] = '4';
        buf[len++] = '0' + bg;
    }
    
    buf[len++] = 'm';
    buf[len] = '\0';
    
    l_print(buf);
}

static void l_reset_color() {
    l_print("\033[0m");
}

static void l_cursor_pos(int row, int col) {
    char buf[32];
    int len = 0;
    
    buf[len++] = '\033';
    buf[len++] = '[';
    
    int n = row;
    char temp[10];
    int i = 0;
    do {
        temp[i++] = (n % 10) + '0';
        n /= 10;
    } while (n > 0);
    for (int j = i - 1; j >= 0; j--) {
        buf[len++] = temp[j];
    }
    
    buf[len++] = ';';
    
    n = col;
    i = 0;
    do {
        temp[i++] = (n % 10) + '0';
        n /= 10;
    } while (n > 0);
    for (int j = i - 1; j >= 0; j--) {
        buf[len++] = temp[j];
    }
    
    buf[len++] = 'H';
    buf[len] = '\0';
    
    l_print(buf);
}

// 工具函数
static int l_atoi(const char *str) {
    int result = 0;
    int sign = 1;
    
    if (*str == '-') {
        sign = -1;
        str++;
    } else if (*str == '+') {
        str++;
    }
    
    while (*str >= '0' && *str <= '9') {
        result = result * 10 + (*str - '0');
        str++;
    }
    
    return sign * result;
}

static char* l_itoa(int num, char *str, int base) {
    int i = 0, is_negative = 0;
    char temp[32];
    
    if (num == 0) {
        str[i++] = '0';
        str[i] = '\0';
        return str;
    }
    
    if (num < 0 && base == 10) {
        is_negative = 1;
        num = -num;
    }
    
    while (num != 0) {
        int rem = num % base;
        temp[i++] = (rem > 9) ? (rem - 10) + 'a' : rem + '0';
        num = num / base;
    }
    
    if (is_negative) {
        temp[i++] = '-';
    }
    
    temp[i] = '\0';
    
    for (int j = 0; j < i; j++) {
        str[j] = temp[i - j - 1];
    }
    str[i] = '\0';
    
    return str;
}

static int l_abs(int x) {
    return (x < 0) ? -x : x;
}

static int l_max(int a, int b) {
    return (a > b) ? a : b;
}

static int l_min(int a, int b) {
    return (a < b) ? a : b;
}

// 字符串缓冲操作
static L_STRING* l_string_new(int capacity) {
    L_STRING *str = (L_STRING*)l_malloc(sizeof(L_STRING));
    if (!str) return 0;
    
    str->data = (char*)l_malloc(capacity);
    if (!str->data) {
        return 0;
    }
    
    str->data[0] = '\0';
    str->length = 0;
    str->capacity = capacity;
    return str;
}

static void l_string_append(L_STRING *str, const char *src) {
    if (!str || !src) return;
    
    int len = l_strlen(src);
    if (str->length + len + 1 > str->capacity) {
        return;
    }
    
    for (int i = 0; i < len; i++) {
        str->data[str->length++] = src[i];
    }
    str->data[str->length] = '\0';
}

static void l_string_append_char(L_STRING *str, char c) {
    if (!str || str->length + 1 >= str->capacity) return;
    
    str->data[str->length++] = c;
    str->data[str->length] = '\0';
}

static void l_string_clear(L_STRING *str) {
    if (!str) return;
    str->data[0] = '\0';
    str->length = 0;
}

// 错误信息表
static const L_ERROR_INFO l_errors[] = {
    {L_SUCCESS,     "SUCCESS",     "操作成功"},
    {L_EOF,         "EOF",         "文件结束"},
    {L_ERROR,       "ERROR",       "一般错误"},
    {L_ENOMEM,      "ENOMEM",      "内存不足"},
    {L_EINVAL,      "EINVAL",      "无效参数"},
    {L_ENOENT,      "ENOENT",      "文件或目录不存在"},
    {L_EACCES,      "EACCES",      "权限不足"},
    {L_EEXIST,      "EEXIST",      "文件已存在"},
    {L_EISDIR,      "EISDIR",      "是目录"},
    {L_ENOTDIR,     "ENOTDIR",     "不是目录"},
    {L_EFBIG,       "EFBIG",       "文件太大"},
    {L_ENOSPC,      "ENOSPC",      "磁盘空间不足"},
    {L_EIO,         "EIO",         "输入输出错误"},
    {L_EROFS,       "EROFS",       "只读文件系统"},
    {L_EBADF,       "EBADF",       "坏的文件描述符"},
    {L_ECHILD,      "ECHILD",      "无子进程"},
    {L_EDEADLK,     "EDEADLK",     "资源死锁"},
    {L_EAGAIN,      "EAGAIN",      "资源暂时不可用，请重试"},
    {L_ENOMSG,      "ENOMSG",      "无消息"},
    {L_EINTR,       "EINTR",       "系统调用被中断"},
    {L_ENETDOWN,    "ENETDOWN",    "网络不可用"},
    {L_ENETUNREACH, "ENETUNREACH", "网络不可达"},
    {L_ECONNREFUSED,"ECONNREFUSED","连接被拒绝"},
    {L_ETIMEDOUT,   "ETIMEDOUT",   "操作超时"},
    {L_ECONNRESET,  "ECONNRESET",  "连接被重置"},
    {L_ENOSYS,      "ENOSYS",      "功能未实现"},
    {L_ENOTSUP,     "ENOTSUP",     "操作不支持"},
    {L_EOVERFLOW,   "EOVERFLOW",   "值溢出"},
    {L_ERANGE,      "ERANGE",      "结果超出范围"},
    {L_EILSEQ,      "EILSEQ",      "非法字节序列"},
    {0, 0, 0}
};

// 拼音九键解码函数
static const char* l_errstr(int errcode) {
    for (int i = 0; l_errors[i].name; i++) {
        if (l_errors[i].code == errcode) {
            return l_errors[i].desc;
        }
    }
    return "未知错误";
}

static const char* l_errname(int errcode) {
    for (int i = 0; l_errors[i].name; i++) {
        if (l_errors[i].code == errcode) {
            return l_errors[i].name;
        }
    }
    return "UNKNOWN";
}

static void l_decode_pinyin(int code, char *buffer) {
    const char *keymap[] = {
        "", "", "abc", "def", "ghi", "jkl", "mno", "pqrs", "tuv", "wxyz"
    };
    
    int num = (code < 0) ? -code : code;
    int first = num / 10;
    int second = num % 10;
    
    if (first >= 0 && first <= 9 && second >= 0 && second <= 9) {
        const char *first_chars = keymap[first];
        const char *second_chars = keymap[second];
        
        buffer[0] = first_chars[0];
        buffer[1] = second_chars[0];
        buffer[2] = '\0';
    } else {
        buffer[0] = '?';
        buffer[1] = '?';
        buffer[2] = '\0';
    }
}

// 打印详细错误信息
static void l_perror(const char *msg, int errcode) {
    char pinyin[3];
    l_decode_pinyin(errcode, pinyin);
    
    l_set_color(L_COLOR_RED, L_COLOR_BLACK);
    if (msg && msg[0]) {
        l_printf("错误: %s (代码:%d, 九键:%s, 类型:%s)\n", 
                 msg, errcode, pinyin, l_errname(errcode));
    } else {
        l_printf("错误代码: %d, 九键:%s, 类型:%s\n", 
                 errcode, pinyin, l_errname(errcode));
    }
    l_printf("描述: %s\n", l_errstr(errcode));
    l_reset_color();
}

// 安全字符串复制
static int l_strncpy(char *dest, const char *src, int n) {
    if (!dest || !src || n <= 0) return L_EINVAL;
    
    int i = 0;
    while (i < n - 1 && src[i]) {
        dest[i] = src[i];
        i++;
    }
    dest[i] = '\0';
    
    return (src[i] == '\0') ? 0 : L_ERANGE;
}

// 字符串大小写转换
static void l_strlower(char *str) {
    if (!str) return;
    
    for (int i = 0; str[i]; i++) {
        if (str[i] >= 'A' && str[i] <= 'Z') {
            str[i] = str[i] - 'A' + 'a';
        }
    }
}

static void l_strupper(char *str) {
    if (!str) return;
    
    for (int i = 0; str[i]; i++) {
        if (str[i] >= 'a' && str[i] <= 'z') {
            str[i] = str[i] - 'a' + 'A';
        }
    }
}

// 文件操作
static L_FILE* l_fopen(const char *path, const char *mode) {
    int flags = 0;
    int mode_bits = 0;
    
    switch (mode[0]) {
        case 'r':
            if (mode[1] == '+') {
                flags = L_O_RDWR;
            } else {
                flags = L_O_RDONLY;
            }
            break;
        case 'w':
            flags = L_O_WRONLY | L_O_CREAT | L_O_TRUNC;
            if (mode[1] == '+') {
                flags = L_O_RDWR | L_O_CREAT | L_O_TRUNC;
            }
            break;
        case 'a':
            flags = L_O_WRONLY | L_O_CREAT | L_O_APPEND;
            if (mode[1] == '+') {
                flags = L_O_RDWR | L_O_CREAT | L_O_APPEND;
            }
            break;
        default:
            return 0;
    }
    
    int fd = l_syscall(L_SYS_OPENAT, -100, (long)path, flags, 0644, 0, 0);
    if (fd < 0) {
        return 0;
    }
    
    L_FILE *file = (L_FILE*)l_malloc(sizeof(L_FILE));
    if (!file) {
        l_syscall(L_SYS_CLOSE, fd, 0, 0, 0, 0, 0);
        return 0;
    }
    
    file->fd = fd;
    file->pos = 0;
    file->eof = 0;
    file->error = 0;
    file->mode = flags;
    
    return file;
}

static int l_fclose(L_FILE *stream) {
    if (!stream) return L_EOF;
    
    int result = l_syscall(L_SYS_CLOSE, stream->fd, 0, 0, 0, 0, 0);
    stream->fd = -1;
    
    return result;
}

static int l_fread(void *ptr, int size, int count, L_FILE *stream) {
    if (!stream || stream->fd < 0) return 0;
    
    int total = size * count;
    int n = l_read(stream->fd, (char*)ptr, total);
    
    if (n <= 0) {
        stream->eof = (n == 0);
        stream->error = (n < 0);
        return 0;
    }
    
    stream->pos += n;
    return n / size;
}

static int l_fwrite(const void *ptr, int size, int count, L_FILE *stream) {
    if (!stream || stream->fd < 0) return 0;
    
    int total = size * count;
    int n = l_write(stream->fd, (const char*)ptr, total);
    
    if (n < 0) {
        stream->error = 1;
        return 0;
    }
    
    stream->pos += n;
    return n / size;
}

// 新增：获取文件大小
static int l_fsize(L_FILE *file) {
    if (!file || file->fd < 0) return L_EBADF;
    
    long current = l_syscall(L_SYS_LSEEK, file->fd, 0, 1, 0, 0, 0);
    if (current < 0) return L_ERROR;
    
    long size = l_syscall(L_SYS_LSEEK, file->fd, 0, 2, 0, 0, 0);
    if (size < 0) return L_ERROR;
    
    l_syscall(L_SYS_LSEEK, file->fd, current, 0, 0, 0, 0);
    
    return (int)size;
}

// 新增：改变当前目录
static int l_chdir(const char *path) {
    int ret = l_syscall(L_SYS_CHDIR, (long)path, 0, 0, 0, 0, 0);
    return (ret < 0) ? -ret : 0;
}

// 新增：获取当前目录
static int l_getcwd(char *buf, int size) {
    if (!buf || size <= 0) return L_EINVAL;
    
    int ret = l_syscall(L_SYS_GETCWD, (long)buf, size, 0, 0, 0, 0);
    if (ret < 0) return -ret;
    
    return 0;
}

// 时间函数
static long l_time() {
    return l_syscall(L_SYS_TIME, 0, 0, 0, 0, 0, 0);
}

static int l_sleep(long sec, long nsec) {
    L_TIMESPEC req = {sec, nsec};
    L_TIMESPEC rem = {0, 0};
    
    return l_syscall(L_SYS_NANOSLEEP, (long)&req, (long)&rem, 0, 0, 0, 0);
}

static int l_msleep(int ms) {
    return l_sleep(ms / 1000, (ms % 1000) * 1000000);
}

// 程序控制
static void l_exit(int code) {
    l_syscall(L_SYS_EXIT, code, 0, 0, 0, 0, 0);
}

static int l_getpid() {
    return l_syscall(L_SYS_GETPID, 0, 0, 0, 0, 0, 0);
}

// 数学函数
static int l_pow(int base, int exp) {
    int result = 1;
    for (int i = 0; i < exp; i++) {
        result *= base;
    }
    return result;
}

static int l_sqrt(int x) {
    if (x <= 0) return 0;
    
    int guess = x;
    int prev = 0;
    
    while (guess != prev) {
        prev = guess;
        guess = (guess + x / guess) / 2;
    }
    
    return guess;
}

// 获取内存信息
static int l_get_mem_info() {
    char buf[32];
    l_print("内存使用: ");
    l_itoa(l_get_mem_used(), buf, 10);
    l_print(buf);
    l_print(" / ");
    l_itoa(L_POOL_SIZE, buf, 10);
    l_print(buf);
    l_puts(" bytes");
    return 0;
}

// 演示错误码
static void l_demo_errors() {
    l_puts("\n=== LAOLIPEF 错误码演示 ===");
    
    int errors[] = {L_ENOMEM, L_EINVAL, L_ENOENT, L_EACCES, L_EIO};
    const char *msgs[] = {
        "分配内存",
        "传递参数",
        "打开文件",
        "访问资源",
        "读写操作"
    };
    
    for (int i = 0; i < 5; i++) {
        l_perror(msgs[i], errors[i]);
    }
}

// 示例：使用错误码的函数
static L_FILE* l_try_open(const char *filename, const char *mode, int *error) {
    L_FILE *file = l_fopen(filename, mode);
    if (!file && error) {
        *error = L_ENOENT;
    }
    return file;
}

#endif // L_STDIOS_H
