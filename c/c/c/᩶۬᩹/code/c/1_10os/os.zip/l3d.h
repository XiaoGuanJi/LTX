/**
 * Copyright [2026] [LAOLIPEF]
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * l3d.h - 自适应3D渲染库
 */

#ifndef L_3D_H
#define L_3D_H

#include "lstdios.h"
#include "lmath.h"
#include "lnull.h"
#include "ltime.h"

/*------------------------------------------------------------------
 * 第一部分：基础类型和常量
 *------------------------------------------------------------------*/

// 渲染模式
#define L3D_MODE_GRAPHICAL 0
#define L3D_MODE_TEXT      1
#define L3D_MODE_AUTO      2

// 数学常量
#define L3D_PI 3.14159265358979323846f

// 顶点结构
typedef struct {
    float x, y, z;
    float u, v;
    float nx, ny, nz;
} L3D_Vertex;

// 三角形结构
typedef struct {
    L3D_Vertex v[3];
    int color;
} L3D_Triangle;

// 矢量结构
typedef struct {
    float x, y, z;
} L3D_Vec3;

// 矩阵结构
typedef struct {
    float m[4][4];
} L3D_Matrix;

// 摄像机结构
typedef struct {
    L3D_Vec3 position;
    L3D_Vec3 target;
    L3D_Vec3 up;
    float fov;
    float aspect;
    float near;
    float far;
} L3D_Camera;

// 渲染上下文
typedef struct {
    int width;
    int height;
    int mode;
    int has_graphics;
    char *framebuffer;
    float *zbuffer;
    int *color_buffer;
    L3D_Camera camera;
} L3D_Context;

// 文本模式字符
static const char* L3D_TEXT_CHARS = " .,:;oO8@";

/*------------------------------------------------------------------
 * 第二部分：数学辅助函数
 *------------------------------------------------------------------*/

// 自定义三角函数实现
static float l3d_fsin(float x) {
    // 简化正弦实现
    x = x - 2.0f * L3D_PI * (int)(x / (2.0f * L3D_PI));
    
    float sign = 1.0f;
    if (x < 0) {
        sign = -1.0f;
        x = -x;
    }
    
    if (x > L3D_PI) {
        sign = -sign;
        x -= L3D_PI;
    }
    
    if (x > L3D_PI / 2) {
        x = L3D_PI - x;
    }
    
    float x2 = x * x;
    return sign * x * (1.0f - x2 * (1.0f/6.0f - x2 * (1.0f/120.0f - x2 * (1.0f/5040.0f))));
}

static float l3d_fcos(float x) {
    return l3d_fsin(x + L3D_PI / 2.0f);
}

static float l3d_ftan(float x) {
    float s = l3d_fsin(x);
    float c = l3d_fcos(x);
    if (c < 0.0001f && c > -0.0001f) {
        return s > 0 ? 1000000.0f : -1000000.0f;
    }
    return s / c;
}

/*------------------------------------------------------------------
 * 第三部分：矢量运算
 *------------------------------------------------------------------*/

static L3D_Vec3 l3d_vec3_create(float x, float y, float z) {
    L3D_Vec3 v = {x, y, z};
    return v;
}

static L3D_Vec3 l3d_vec3_add(L3D_Vec3 a, L3D_Vec3 b) {
    L3D_Vec3 result = {a.x + b.x, a.y + b.y, a.z + b.z};
    return result;
}

static L3D_Vec3 l3d_vec3_sub(L3D_Vec3 a, L3D_Vec3 b) {
    L3D_Vec3 result = {a.x - b.x, a.y - b.y, a.z - b.z};
    return result;
}

static float l3d_vec3_dot(L3D_Vec3 a, L3D_Vec3 b) {
    return a.x * b.x + a.y * b.y + a.z * b.z;
}

static L3D_Vec3 l3d_vec3_cross(L3D_Vec3 a, L3D_Vec3 b) {
    L3D_Vec3 result = {
        a.y * b.z - a.z * b.y,
        a.z * b.x - a.x * b.z,
        a.x * b.y - a.y * b.x
    };
    return result;
}

static L3D_Vec3 l3d_vec3_normalize(L3D_Vec3 v) {
    float len = l_fsqrt(v.x * v.x + v.y * v.y + v.z * v.z);
    if (len > 0.0001f) {
        v.x /= len;
        v.y /= len;
        v.z /= len;
    }
    return v;
}

static float l3d_vec3_length(L3D_Vec3 v) {
    return l_fsqrt(v.x * v.x + v.y * v.y + v.z * v.z);
}

/*------------------------------------------------------------------
 * 第四部分：矩阵运算
 *------------------------------------------------------------------*/

static L3D_Matrix l3d_matrix_identity() {
    L3D_Matrix m = {0};
    for (int i = 0; i < 4; i++) {
        m.m[i][i] = 1.0f;
    }
    return m;
}

static L3D_Matrix l3d_matrix_mul(L3D_Matrix a, L3D_Matrix b) {
    L3D_Matrix result = {0};
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            result.m[i][j] = 0;
            for (int k = 0; k < 4; k++) {
                result.m[i][j] += a.m[i][k] * b.m[k][j];
            }
        }
    }
    return result;
}

static L3D_Matrix l3d_matrix_translate(float x, float y, float z) {
    L3D_Matrix m = l3d_matrix_identity();
    m.m[0][3] = x;
    m.m[1][3] = y;
    m.m[2][3] = z;
    return m;
}

static L3D_Matrix l3d_matrix_rotate_x(float angle) {
    L3D_Matrix m = l3d_matrix_identity();
    float c = l3d_fcos(angle);
    float s = l3d_fsin(angle);
    m.m[1][1] = c;
    m.m[1][2] = -s;
    m.m[2][1] = s;
    m.m[2][2] = c;
    return m;
}

static L3D_Matrix l3d_matrix_rotate_y(float angle) {
    L3D_Matrix m = l3d_matrix_identity();
    float c = l3d_fcos(angle);
    float s = l3d_fsin(angle);
    m.m[0][0] = c;
    m.m[0][2] = s;
    m.m[2][0] = -s;
    m.m[2][2] = c;
    return m;
}

static L3D_Matrix l3d_matrix_rotate_z(float angle) {
    L3D_Matrix m = l3d_matrix_identity();
    float c = l3d_fcos(angle);
    float s = l3d_fsin(angle);
    m.m[0][0] = c;
    m.m[0][1] = -s;
    m.m[1][0] = s;
    m.m[1][1] = c;
    return m;
}

static L3D_Matrix l3d_matrix_scale(float x, float y, float z) {
    L3D_Matrix m = l3d_matrix_identity();
    m.m[0][0] = x;
    m.m[1][1] = y;
    m.m[2][2] = z;
    return m;
}

static L3D_Matrix l3d_matrix_perspective(float fov, float aspect, float near, float far) {
    L3D_Matrix m = {0};
    float tan_half_fov = l3d_ftan(fov * 0.5f);
    
    m.m[0][0] = 1.0f / (aspect * tan_half_fov);
    m.m[1][1] = 1.0f / tan_half_fov;
    m.m[2][2] = far / (far - near);
    m.m[2][3] = -far * near / (far - near);
    m.m[3][2] = 1.0f;
    
    return m;
}

static L3D_Vec3 l3d_vec3_transform(L3D_Vec3 v, L3D_Matrix m) {
    float w = v.x * m.m[0][3] + v.y * m.m[1][3] + v.z * m.m[2][3] + m.m[3][3];
    
    L3D_Vec3 result = {
        (v.x * m.m[0][0] + v.y * m.m[1][0] + v.z * m.m[2][0] + m.m[3][0]) / w,
        (v.x * m.m[0][1] + v.y * m.m[1][1] + v.z * m.m[2][1] + m.m[3][1]) / w,
        (v.x * m.m[0][2] + v.y * m.m[1][2] + v.z * m.m[2][2] + m.m[3][2]) / w
    };
    
    return result;
}

/*------------------------------------------------------------------
 * 第五部分：系统检测
 *------------------------------------------------------------------*/

static int l3d_detect_graphics() {
    // 简化实现：总是返回文本模式
    return 0;
}

static L3D_Context* l3d_create_context(int width, int height, int mode) {
    L3D_Context *ctx = (L3D_Context*)l_malloc(sizeof(L3D_Context));
    L_RETURN_IF_NULL(ctx, 0);
    
    ctx->width = width;
    ctx->height = height;
    ctx->mode = mode;
    ctx->has_graphics = 0;  // 简化：总是文本模式
    
    int buffer_size = width * height;
    
    ctx->framebuffer = (char*)l_malloc(buffer_size + 1);
    if (ctx->framebuffer) {
        ctx->framebuffer[buffer_size] = '\0';
    }
    
    ctx->zbuffer = (float*)l_malloc(buffer_size * sizeof(float));
    if (ctx->zbuffer) {
        for (int i = 0; i < buffer_size; i++) {
            ctx->zbuffer[i] = 1000.0f;
        }
    }
    
    ctx->color_buffer = (int*)l_malloc(buffer_size * sizeof(int));
    
    ctx->camera.position = l3d_vec3_create(0, 0, 5);
    ctx->camera.target = l3d_vec3_create(0, 0, 0);
    ctx->camera.up = l3d_vec3_create(0, 1, 0);
    ctx->camera.fov = 60.0f;
    ctx->camera.aspect = (float)width / (float)height;
    ctx->camera.near = 0.1f;
    ctx->camera.far = 100.0f;
    
    return ctx;
}

static void l3d_destroy_context(L3D_Context *ctx) {
    if (L_IS_NULL(ctx)) return;
    
    if (ctx->framebuffer) l_free(ctx->framebuffer);
    if (ctx->zbuffer) l_free(ctx->zbuffer);
    if (ctx->color_buffer) l_free(ctx->color_buffer);
    l_free(ctx);
}

/*------------------------------------------------------------------
 * 第六部分：渲染核心
 *------------------------------------------------------------------*/

static void l3d_clear(L3D_Context *ctx, char clear_char, int clear_color) {
    if (L_IS_NULL(ctx)) return;
    
    int buffer_size = ctx->width * ctx->height;
    
    if (ctx->framebuffer) {
        for (int i = 0; i < buffer_size; i++) {
            ctx->framebuffer[i] = clear_char;
        }
    }
    
    if (ctx->zbuffer) {
        for (int i = 0; i < buffer_size; i++) {
            ctx->zbuffer[i] = 1000.0f;
        }
    }
    
    if (ctx->color_buffer) {
        for (int i = 0; i < buffer_size; i++) {
            ctx->color_buffer[i] = clear_color;
        }
    }
}

static L3D_Vec3 l3d_calculate_normal(L3D_Vec3 v0, L3D_Vec3 v1, L3D_Vec3 v2) {
    L3D_Vec3 a = l3d_vec3_sub(v1, v0);
    L3D_Vec3 b = l3d_vec3_sub(v2, v0);
    return l3d_vec3_normalize(l3d_vec3_cross(a, b));
}

static void l3d_draw_point(L3D_Context *ctx, int x, int y, float z, int color) {
    if (L_IS_NULL(ctx) || L_IS_NULL(ctx->zbuffer) || L_IS_NULL(ctx->color_buffer)) {
        return;
    }
    
    if (x < 0 || x >= ctx->width || y < 0 || y >= ctx->height) {
        return;
    }
    
    int index = y * ctx->width + x;
    
    if (z >= 0 && z < ctx->zbuffer[index]) {
        ctx->zbuffer[index] = z;
        ctx->color_buffer[index] = color;
        
        int char_index = (int)(z * 8);
        if (char_index < 0) char_index = 0;
        if (char_index > 7) char_index = 7;
        
        if (ctx->framebuffer) {
            ctx->framebuffer[index] = L3D_TEXT_CHARS[char_index];
        }
    }
}

static void l3d_draw_line(L3D_Context *ctx, L3D_Vec3 v0, L3D_Vec3 v1, int color) {
    if (L_IS_NULL(ctx)) return;
    
    int x0 = (int)((v0.x + 1) * 0.5 * ctx->width);
    int y0 = (int)((1 - (v0.y + 1) * 0.5) * ctx->height);
    int x1 = (int)((v1.x + 1) * 0.5 * ctx->width);
    int y1 = (int)((1 - (v1.y + 1) * 0.5) * ctx->height);
    
    float z0 = v0.z;
    float z1 = v1.z;
    
    int dx = x1 - x0;
    int dy = y1 - y0;
    int steps = 0;
    
    if (dx < 0) dx = -dx;
    if (dy < 0) dy = -dy;
    
    if (dx > dy) {
        steps = dx;
    } else {
        steps = dy;
    }
    
    if (steps == 0) {
        l3d_draw_point(ctx, x0, y0, (z0 + z1) * 0.5f, color);
        return;
    }
    
    float x_inc = (float)dx / steps;
    float y_inc = (float)dy / steps;
    float z_inc = (z1 - z0) / steps;
    
    float x = (float)x0;
    float y = (float)y0;
    float z = z0;
    
    for (int i = 0; i <= steps; i++) {
        l3d_draw_point(ctx, (int)x, (int)y, z, color);
        x += x_inc;
        y += y_inc;
        z += z_inc;
    }
}

static void l3d_draw_triangle(L3D_Context *ctx, L3D_Triangle tri, int color) {
    if (L_IS_NULL(ctx)) return;
    
    L3D_Vec3 v0 = {tri.v[0].x, tri.v[0].y, tri.v[0].z};
    L3D_Vec3 v1 = {tri.v[1].x, tri.v[1].y, tri.v[1].z};
    L3D_Vec3 v2 = {tri.v[2].x, tri.v[2].y, tri.v[2].z};
    
    l3d_draw_line(ctx, v0, v1, color);
    l3d_draw_line(ctx, v1, v2, color);
    l3d_draw_line(ctx, v2, v0, color);
}

static void l3d_draw_grid(L3D_Context *ctx, float size, int divisions, int color) {
    if (L_IS_NULL(ctx)) return;
    
    float step = size / divisions;
    float half_size = size * 0.5f;
    
    for (int i = 0; i <= divisions; i++) {
        float pos = -half_size + i * step;
        
        L3D_Vec3 v0 = {-half_size, 0, pos};
        L3D_Vec3 v1 = {half_size, 0, pos};
        l3d_draw_line(ctx, v0, v1, color);
        
        v0 = l3d_vec3_create(pos, 0, -half_size);
        v1 = l3d_vec3_create(pos, 0, half_size);
        l3d_draw_line(ctx, v0, v1, color);
    }
}

static void l3d_draw_cube(L3D_Context *ctx, L3D_Vec3 center, float size, L3D_Matrix transform, int color) {
    if (L_IS_NULL(ctx)) return;
    
    float half = size * 0.5f;
    
    L3D_Vec3 vertices[8] = {
        {-half, -half, -half}, {half, -half, -half},
        {half, half, -half}, {-half, half, -half},
        {-half, -half, half}, {half, -half, half},
        {half, half, half}, {-half, half, half}
    };
    
    for (int i = 0; i < 8; i++) {
        vertices[i] = l3d_vec3_add(vertices[i], center);
        vertices[i] = l3d_vec3_transform(vertices[i], transform);
    }
    
    int edges[12][2] = {
        {0,1}, {1,2}, {2,3}, {3,0},
        {4,5}, {5,6}, {6,7}, {7,4},
        {0,4}, {1,5}, {2,6}, {3,7}
    };
    
    for (int i = 0; i < 12; i++) {
        l3d_draw_line(ctx, vertices[edges[i][0]], vertices[edges[i][1]], color);
    }
}

static void l3d_draw_sphere(L3D_Context *ctx, L3D_Vec3 center, float radius, int segments, int color) {
    if (L_IS_NULL(ctx)) return;
    
    for (int i = 0; i < segments; i++) {
        float theta1 = 2.0f * L3D_PI * i / segments;
        float theta2 = 2.0f * L3D_PI * (i + 1) / segments;
        
        for (int j = 0; j <= segments/2; j++) {
            float phi1 = L3D_PI * j / (segments/2);
            float phi2 = L3D_PI * (j + 1) / (segments/2);
            
            L3D_Vec3 v1 = {
                radius * l3d_fsin(phi1) * l3d_fcos(theta1),
                radius * l3d_fcos(phi1),
                radius * l3d_fsin(phi1) * l3d_fsin(theta1)
            };
            
            L3D_Vec3 v2 = {
                radius * l3d_fsin(phi2) * l3d_fcos(theta1),
                radius * l3d_fcos(phi2),
                radius * l3d_fsin(phi2) * l3d_fsin(theta1)
            };
            
            v1 = l3d_vec3_add(v1, center);
            v2 = l3d_vec3_add(v2, center);
            l3d_draw_line(ctx, v1, v2, color);
        }
    }
    
    for (int j = 0; j <= segments/2; j++) {
        float phi = L3D_PI * j / (segments/2);
        
        for (int i = 0; i < segments; i++) {
            float theta1 = 2.0f * L3D_PI * i / segments;
            float theta2 = 2.0f * L3D_PI * (i + 1) / segments;
            
            L3D_Vec3 v1 = {
                radius * l3d_fsin(phi) * l3d_fcos(theta1),
                radius * l3d_fcos(phi),
                radius * l3d_fsin(phi) * l3d_fsin(theta1)
            };
            
            L3D_Vec3 v2 = {
                radius * l3d_fsin(phi) * l3d_fcos(theta2),
                radius * l3d_fcos(phi),
                radius * l3d_fsin(phi) * l3d_fsin(theta2)
            };
            
            v1 = l3d_vec3_add(v1, center);
            v2 = l3d_vec3_add(v2, center);
            l3d_draw_line(ctx, v1, v2, color);
        }
    }
}

/*------------------------------------------------------------------
 * 第七部分：显示输出
 *------------------------------------------------------------------*/

static void l3d_display_text(L3D_Context *ctx) {
    if (L_IS_NULL(ctx) || L_IS_NULL(ctx->framebuffer)) {
        return;
    }
    
    l_puts("\033[2J\033[H");
    
    for (int y = 0; y < ctx->height; y++) {
        for (int x = 0; x < ctx->width; x++) {
            char c = ctx->framebuffer[y * ctx->width + x];
            l_putchar(c);
        }
        l_putchar('\n');
    }
}

static void l3d_display_graphical(L3D_Context *ctx) {
    if (L_IS_NULL(ctx)) return;
    
    l_puts("\033[2J\033[H");
    
    for (int y = 0; y < ctx->height; y += 2) {
        for (int x = 0; x < ctx->width; x++) {
            if (ctx->zbuffer && ctx->zbuffer[y * ctx->width + x] < 999.0f) {
                l_putchar('*');
            } else {
                l_putchar(' ');
            }
        }
        l_putchar('\n');
    }
}

static void l3d_render(L3D_Context *ctx) {
    if (L_IS_NULL(ctx)) return;
    
    if (ctx->mode == L3D_MODE_TEXT) {
        l3d_display_text(ctx);
    } else {
        l3d_display_graphical(ctx);
    }
}

/*------------------------------------------------------------------
 * 第八部分：演示函数
 *------------------------------------------------------------------*/

static void l3d_demo_rotating_cube() {
    l_puts("=== 3D旋转立方体演示 ===");
    
    L3D_Context *ctx = l3d_create_context(80, 40, L3D_MODE_TEXT);
    if (L_IS_NULL(ctx)) {
        l_puts("无法创建3D上下文");
        return;
    }
    
    float angle = 0;
    
    for (int frame = 0; frame < 50; frame++) {
        l3d_clear(ctx, ' ', 0);
        
        L3D_Matrix rot_y = l3d_matrix_rotate_y(angle);
        L3D_Matrix rot_x = l3d_matrix_rotate_x(angle * 0.7f);
        L3D_Matrix transform = l3d_matrix_mul(rot_y, rot_x);
        
        L3D_Vec3 origin = {0, 0, 0};
        L3D_Vec3 x_axis = {2, 0, 0};
        L3D_Vec3 y_axis = {0, 2, 0};
        L3D_Vec3 z_axis = {0, 0, 2};
        
        l3d_draw_line(ctx, origin, x_axis, 0xFF0000);
        l3d_draw_line(ctx, origin, y_axis, 0x00FF00);
        l3d_draw_line(ctx, origin, z_axis, 0x0000FF);
        
        l3d_draw_grid(ctx, 5.0f, 10, 0x333333);
        
        l3d_draw_cube(ctx, origin, 1.0f, transform, 0xFFFFFF);
        
        L3D_Vec3 sphere_pos = {0, 1.5f, 0};
        l3d_draw_sphere(ctx, sphere_pos, 0.5f, 12, 0xFFFF00);
        
        l3d_render(ctx);
        
        angle += 0.1f;
        l_sleep(0, 100000000);
    }
    
    l3d_destroy_context(ctx);
    l_puts("=== 演示结束 ===");
}

static void l3d_demo_simple_scene() {
    l_puts("=== 3D简单场景演示 ===");
    
    L3D_Context *ctx = l3d_create_context(60, 30, L3D_MODE_TEXT);
    if (L_IS_NULL(ctx)) {
        l_puts("无法创建3D上下文");
        return;
    }
    
    l3d_clear(ctx, '.', 0);
    
    L3D_Vec3 origin = {0, 0, 0};
    L3D_Vec3 x_axis = {1, 0, 0};
    L3D_Vec3 y_axis = {0, 1, 0};
    L3D_Vec3 z_axis = {0, 0, 1};
    
    l3d_draw_line(ctx, origin, x_axis, 0xFF0000);
    l3d_draw_line(ctx, origin, y_axis, 0x00FF00);
    l3d_draw_line(ctx, origin, z_axis, 0x0000FF);
    
    l3d_draw_grid(ctx, 4.0f, 8, 0x333333);
    
    L3D_Vec3 cube_pos = {0.5f, 0.5f, 0.5f};
    l3d_draw_cube(ctx, cube_pos, 0.5f, l3d_matrix_identity(), 0xFFFFFF);
    
    l3d_render(ctx);
    
    l3d_destroy_context(ctx);
    l_puts("=== 演示结束 ===");
}

static void l3d_demo() {
    l_puts("\n=== 3D渲染库演示 ===");
    
    l_puts("\n1. 简单场景演示");
    l3d_demo_simple_scene();
    
    l_puts("\n2. 旋转立方体演示");
    l_puts("按Ctrl+C退出...");
    l_sleep(1, 0);
    
    l3d_demo_rotating_cube();
    
    l_puts("\n=== 所有演示完成 ===");
}

/*------------------------------------------------------------------
 * 第九部分：工具函数
 *------------------------------------------------------------------*/

static int l3d_get_mode(L3D_Context *ctx) {
    L_RETURN_IF_NULL(ctx, L3D_MODE_TEXT);
    return ctx->mode;
}

static int l3d_has_graphics() {
    return 0;  // 简化实现
}

static void l3d_set_camera(L3D_Context *ctx, L3D_Camera camera) {
    if (L_IS_NULL(ctx)) return;
    ctx->camera = camera;
}

static L3D_Camera l3d_get_camera(L3D_Context *ctx) {
    L3D_Camera default_cam = {0};
    L_RETURN_IF_NULL(ctx, default_cam);
    return ctx->camera;
}

#endif /* L_3D_H */
