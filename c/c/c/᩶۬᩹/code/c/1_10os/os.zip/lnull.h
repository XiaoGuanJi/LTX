/**
 * Copyright [2023] [LAOLIPEF]
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * lnull.h - 安全的 NULL 定义
 * 修复指针到整型的转换警告
 */

#ifndef L_NULL_H
#define L_NULL_H

#include "lstdios.h"

// 1. 基础 NULL 定义
#define L_NULL 0
#define L_NULL_PTR ((void*)0)

// 2. 特殊空值定义
#define L_NULL_FD (-1)           // 无效文件描述符
#define L_NULL_HANDLE 0          // 无效句柄
#define L_NULL_ID (-1)           // 无效ID
#define L_NULL_SIZE 0            // 空大小
#define L_NULL_INDEX (-1)        // 无效索引

// 3. 类型安全的空值常量
typedef enum {
    NULL_TYPE_PTR = 0,      // 指针类型
    NULL_TYPE_FD = 1,       // 文件描述符
    NULL_TYPE_HANDLE = 2,   // 句柄
    NULL_TYPE_ID = 3,       // ID
    NULL_TYPE_SIZE = 4      // 大小
} NullType;

// 4. 统一的空值结构
typedef struct {
    NullType type;
    union {
        void *ptr;
        int fd;
        long handle;
        int id;
        int size;
    } value;
} NullableValue;

// 5. 类型安全的空值创建
static inline NullableValue make_null_ptr() {
    NullableValue nv;
    nv.type = NULL_TYPE_PTR;
    nv.value.ptr = L_NULL_PTR;
    return nv;
}

static inline NullableValue make_null_fd() {
    NullableValue nv;
    nv.type = NULL_TYPE_FD;
    nv.value.fd = L_NULL_FD;
    return nv;
}

static inline NullableValue make_null_handle() {
    NullableValue nv;
    nv.type = NULL_TYPE_HANDLE;
    nv.value.handle = L_NULL_HANDLE;
    return nv;
}

// 6. 安全的空值检查（修复了类型转换问题）
static inline int is_null(const NullableValue *nv) {
    if (nv == L_NULL_PTR) return L_TRUE;
    
    switch (nv->type) {
        case NULL_TYPE_PTR:
            return (nv->value.ptr == L_NULL_PTR) ? L_TRUE : L_FALSE;
        case NULL_TYPE_FD:
            return (nv->value.fd == L_NULL_FD) ? L_TRUE : L_FALSE;
        case NULL_TYPE_HANDLE:
            return (nv->value.handle == L_NULL_HANDLE) ? L_TRUE : L_FALSE;
        case NULL_TYPE_ID:
            return (nv->value.id == L_NULL_ID) ? L_TRUE : L_FALSE;
        case NULL_TYPE_SIZE:
            return (nv->value.size == L_NULL_SIZE) ? L_TRUE : L_FALSE;
        default:
            return L_TRUE;  // 未知类型视为空
    }
}

// 7. 宏定义（避免函数调用开销）
#define L_IS_NULL(ptr) ((ptr) == L_NULL_PTR)
#define L_IS_NULL_FD(fd) ((fd) == L_NULL_FD)
#define L_IS_NULL_HANDLE(handle) ((handle) == L_NULL_HANDLE)
#define L_IS_NULL_ID(id) ((id) == L_NULL_ID)
#define L_IS_NULL_SIZE(size) ((size) == L_NULL_SIZE)

#define L_IS_VALID(ptr) ((ptr) != L_NULL_PTR)
#define L_IS_VALID_FD(fd) ((fd) != L_NULL_FD)
#define L_IS_VALID_HANDLE(handle) ((handle) != L_NULL_HANDLE)
#define L_IS_VALID_ID(id) ((id) != L_NULL_ID)
#define L_IS_VALID_SIZE(size) ((size) != L_NULL_SIZE)

// 8. 空值断言（安全的类型检查）
#define L_NULL_ASSERT(ptr, msg) \
    do { \
        if ((ptr) == L_NULL_PTR) { \
            l_set_color(L_COLOR_RED, L_COLOR_BLACK); \
            l_print("[空值断言] "); \
            l_reset_color(); \
            l_print(__FILE__); \
            l_print(":"); \
            l_putint(__LINE__); \
            l_print(": "); \
            l_print(msg); \
            l_puts(""); \
            l_exit(L_EINVAL); \
        } \
    } while(0)

#define L_FD_ASSERT(fd, msg) \
    do { \
        if ((fd) == L_NULL_FD) { \
            l_set_color(L_COLOR_RED, L_COLOR_BLACK); \
            l_print("[文件描述符断言] "); \
            l_reset_color(); \
            l_print(__FILE__); \
            l_print(":"); \
            l_putint(__LINE__); \
            l_print(": "); \
            l_print(msg); \
            l_puts(""); \
            l_exit(L_EBADF); \
        } \
    } while(0)

// 9. 安全返回宏
#define L_RETURN_IF_NULL(ptr, retval) \
    do { \
        if ((ptr) == L_NULL_PTR) { \
            return (retval); \
        } \
    } while(0)

#define L_RETURN_IF_NULL_FD(fd, retval) \
    do { \
        if ((fd) == L_NULL_FD) { \
            return (retval); \
        } \
    } while(0)

// 10. 空值日志
#define L_LOG_NULL(ptr, name) \
    do { \
        if ((ptr) == L_NULL_PTR) { \
            l_set_color(L_COLOR_YELLOW, L_COLOR_BLACK); \
            l_print("[警告] 空指针: "); \
            l_reset_color(); \
            l_print(name); \
            l_puts(""); \
        } \
    } while(0)

// 11. 通用空值转换（无类型转换警告）
static inline int ptr_to_safe_int(void *ptr) {
    // 将指针转换为安全的整数表示
    if (ptr == L_NULL_PTR) {
        return 0;
    }
    
    // 使用位移操作避免直接转换警告
    long addr = (long)ptr;
    return (int)(addr & 0xFFFFFFFF);
}

// 12. 空值比较函数
static inline int compare_null(void *a, void *b) {
    if (a == L_NULL_PTR && b == L_NULL_PTR) return 0;
    if (a == L_NULL_PTR) return -1;
    if (b == L_NULL_PTR) return 1;
    
    // 比较指针值
    if ((long)a < (long)b) return -1;
    if ((long)a > (long)b) return 1;
    return 0;
}

// 13. 空值包装器
typedef struct {
    void *data;
    int (*validator)(void*);
} NullGuard;

static inline int validate_null_guard(NullGuard *guard) {
    if (guard == L_NULL_PTR) return L_FALSE;
    if (guard->data == L_NULL_PTR) return L_FALSE;
    if (guard->validator == L_NULL_PTR) return L_TRUE;  // 无验证器也通过
    
    return guard->validator(guard->data);
}

// 14. 空值链
typedef struct NullChainNode {
    void *data;
    struct NullChainNode *next;
} NullChainNode;

static inline NullChainNode* create_null_chain_node(void *data) {
    NullChainNode *node = (NullChainNode*)l_malloc(sizeof(NullChainNode));
    if (node) {
        node->data = data;
        node->next = L_NULL_PTR;
    }
    return node;
}

// 15. 空值映射函数
typedef void* (*NullMapper)(void*);

static inline void* map_if_not_null(void *ptr, NullMapper mapper) {
    if (ptr == L_NULL_PTR || mapper == L_NULL_PTR) {
        return L_NULL_PTR;
    }
    return mapper(ptr);
}

// 16. 空值过滤器
typedef int (*NullFilter)(void*);

static inline int filter_if_not_null(void *ptr, NullFilter filter) {
    if (ptr == L_NULL_PTR || filter == L_NULL_PTR) {
        return L_FALSE;
    }
    return filter(ptr);
}

// 17. 内存安全的空值处理
static inline void* null_safe_alloc(int size, const char *purpose) {
    if (size <= 0) {
        l_printf("错误: 无效的内存大小 %d 用于 %s\n", size, purpose ? purpose : "未知");
        return L_NULL_PTR;
    }
    
    void *ptr = l_malloc(size);
    if (ptr == L_NULL_PTR) {
        l_printf("错误: 无法分配 %d 字节内存用于 %s\n", size, purpose ? purpose : "未知");
    } else {
        // 用0初始化内存
        char *p = (char*)ptr;
        for (int i = 0; i < size; i++) {
            p[i] = 0;
        }
    }
    
    return ptr;
}

// 18. 字符串空值安全处理
static inline const char* null_safe_str(const char *str, const char *default_str) {
    if (str == L_NULL_PTR || str[0] == '\0') {
        return (default_str != L_NULL_PTR) ? default_str : "(空)";
    }
    return str;
}

static inline int null_safe_strlen(const char *str) {
    if (str == L_NULL_PTR) return 0;
    
    int len = 0;
    while (str[len]) len++;
    return len;
}

// 19. 演示函数
static inline void demo_null_features() {
    l_puts("\n=== 空值处理演示 ===");
    
    // 测试基本空值检查
    void *ptr1 = L_NULL_PTR;
    void *ptr2 = (void*)0x1234;
    
    l_print("ptr1 是空值: ");
    l_putint(L_IS_NULL(ptr1));
    l_puts("");
    
    l_print("ptr2 是空值: ");
    l_putint(L_IS_NULL(ptr2));
    l_puts("");
    
    // 测试文件描述符
    int fd1 = L_NULL_FD;
    int fd2 = 5;
    
    l_print("fd1 是无效fd: ");
    l_putint(L_IS_NULL_FD(fd1));
    l_puts("");
    
    l_print("fd2 是无效fd: ");
    l_putint(L_IS_NULL_FD(fd2));
    l_puts("");
    
    // 测试字符串安全处理
    const char *empty_str = "";
    const char *null_str = L_NULL_PTR;
    const char *normal_str = "Hello World";
    
    l_print("空字符串长度: ");
    l_putint(null_safe_strlen(empty_str));
    l_puts("");
    
    l_print("NULL字符串长度: ");
    l_putint(null_safe_strlen(null_str));
    l_puts("");
    
    l_print("正常字符串长度: ");
    l_putint(null_safe_strlen(normal_str));
    l_puts("");
    
    l_print("安全字符串(null): ");
    l_print(null_safe_str(null_str, "默认字符串"));
    l_puts("");
    
    l_print("安全字符串(空): ");
    l_print(null_safe_str(empty_str, "默认字符串"));
    l_puts("");
    
    l_puts("=== 演示结束 ===");
}

// 20. 空值工具函数
static inline void print_null_info(const char *name, void *ptr) {
    l_set_color(L_COLOR_CYAN, L_COLOR_BLACK);
    l_print("[空值信息] ");
    l_reset_color();
    l_print(name);
    l_print(": ");
    
    if (ptr == L_NULL_PTR) {
        l_set_color(L_COLOR_RED, L_COLOR_BLACK);
        l_print("NULL");
    } else {
        l_set_color(L_COLOR_GREEN, L_COLOR_BLACK);
        l_print("有效指针");
        l_print(" (0x");
        l_puthex((long)ptr);
        l_print(")");
    }
    l_reset_color();
    l_puts("");
}

// 21. 空值计数器
typedef struct {
    int null_count;
    int total_count;
} NullStats;

static inline NullStats* create_null_stats() {
    NullStats *stats = (NullStats*)null_safe_alloc(sizeof(NullStats), "空值统计");
    if (stats) {
        stats->null_count = 0;
        stats->total_count = 0;
    }
    return stats;
}

static inline void update_null_stats(NullStats *stats, void *ptr) {
    if (stats) {
        stats->total_count++;
        if (ptr == L_NULL_PTR) {
            stats->null_count++;
        }
    }
}

static inline void print_null_stats(NullStats *stats) {
    if (stats) {
        l_printf("空值统计: %d/%d (%.1f%%)\n", 
                stats->null_count, 
                stats->total_count,
                stats->total_count > 0 ? 
                (stats->null_count * 100.0 / stats->total_count) : 0.0);
    }
}

#endif /* L_NULL_H */
