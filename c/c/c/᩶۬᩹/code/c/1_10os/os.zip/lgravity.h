
/**
 * Copyright [2023] [LAOLIPEF]
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
 
#ifndef L_GRAVITY_H
#define L_GRAVITY_H

#include "lstdios.h"
#include "lmath.h"
#include "lnull.h"
#include "ltime.h"

// 重力物理引擎库 - 无格式化版本

/*------------------------------------------------------------------
 * 第一部分：基础类型和常量
 *------------------------------------------------------------------*/

// 重力常数 (m/s²)
#define L_GRAVITY_EARTH    9.80665f
#define L_GRAVITY_MOON     1.625f
#define L_GRAVITY_MARS     3.721f
#define L_GRAVITY_JUPITER  24.79f
#define L_GRAVITY_SPACE    0.0f

// 物理常量
#define L_PHYSICS_EPSILON  0.0001f
#define L_MAX_VELOCITY     1000.0f
#define L_MAX_ANGULAR      50.0f

// 物理体类型
typedef enum {
    L_BODY_STATIC = 0,
    L_BODY_DYNAMIC = 1,
    L_BODY_KINEMATIC = 2,
    L_BODY_PARTICLE = 3
} L_BodyType;

// 碰撞形状
typedef enum {
    L_SHAPE_CIRCLE = 0,
    L_SHAPE_RECT = 1,
    L_SHAPE_POLYGON = 2,
    L_SHAPE_LINE = 3
} L_ShapeType;

// 二维向量
typedef struct {
    float x, y;
} L_Vec2;

// 物理体结构
typedef struct L_Body {
    L_BodyType type;
    L_ShapeType shape;
    
    // 物理属性
    L_Vec2 position;
    L_Vec2 velocity;
    L_Vec2 acceleration;
    float rotation;
    float angular_velocity;
    float angular_accel;
    
    // 物理参数
    float mass;
    float inv_mass;
    float restitution;
    float friction;
    float damping;
    float angular_damping;
    
    // 几何属性
    float radius;
    float width, height;
    
    // 状态标志
    int is_sleeping;
    int is_colliding;
    int is_grounded;
    
    // 链表指针
    struct L_Body *next;
    struct L_Body *prev;
} L_Body;

// 物理世界
typedef struct {
    L_Body *bodies;
    int body_count;
    
    // 世界属性
    L_Vec2 gravity;
    float time_scale;
    float fixed_delta_time;
    int iterations;
    
    // 世界边界
    float world_width;
    float world_height;
    int enable_bounds;
} L_PhysicsWorld;

// 碰撞结果
typedef struct {
    L_Body *body_a;
    L_Body *body_b;
    L_Vec2 normal;
    L_Vec2 point;
    float depth;
    int collision;
} L_CollisionResult;

/*------------------------------------------------------------------
 * 第二部分：数学工具函数
 *------------------------------------------------------------------*/

// 创建二维向量
static inline L_Vec2 l_vec2_create(float x, float y) {
    L_Vec2 v = {x, y};
    return v;
}

// 向量加法
static inline L_Vec2 l_vec2_add(L_Vec2 a, L_Vec2 b) {
    L_Vec2 result = {a.x + b.x, a.y + b.y};
    return result;
}

// 向量减法
static inline L_Vec2 l_vec2_sub(L_Vec2 a, L_Vec2 b) {
    L_Vec2 result = {a.x - b.x, a.y - b.y};
    return result;
}

// 向量缩放
static inline L_Vec2 l_vec2_scale(L_Vec2 v, float s) {
    L_Vec2 result = {v.x * s, v.y * s};
    return result;
}

// 向量点积
static inline float l_vec2_dot(L_Vec2 a, L_Vec2 b) {
    return a.x * b.x + a.y * b.y;
}

// 向量叉积
static inline float l_vec2_cross(L_Vec2 a, L_Vec2 b) {
    return a.x * b.y - a.y * b.x;
}

// 向量长度
static inline float l_vec2_length(L_Vec2 v) {
    return l_fsqrt(v.x * v.x + v.y * v.y);
}

// 向量归一化
static inline L_Vec2 l_vec2_normalize(L_Vec2 v) {
    float len = l_vec2_length(v);
    if (len > L_PHYSICS_EPSILON) {
        v.x /= len;
        v.y /= len;
    }
    return v;
}

// 距离计算
static inline float l_vec2_distance(L_Vec2 a, L_Vec2 b) {
    float dx = a.x - b.x;
    float dy = a.y - b.y;
    return l_fsqrt(dx * dx + dy * dy);
}

// 浮点数最小值
static inline float l_float_min(float a, float b) {
    return a < b ? a : b;
}

// 浮点数绝对值
static inline float l_float_abs(float x) {
    return x < 0 ? -x : x;
}

// 手动将浮点数转换为字符串
static inline void l_float_to_str(float value, char *buffer, int buffer_size) {
    if (!buffer || buffer_size <= 0) return;
    
    int i = 0;
    
    // 处理负数
    if (value < 0) {
        buffer[i++] = '-';
        value = -value;
    }
    
    // 提取整数部分
    int int_part = (int)value;
    float frac_part = value - int_part;
    
    // 转换整数部分
    char int_str[20];
    int int_len = 0;
    
    if (int_part == 0) {
        int_str[int_len++] = '0';
    } else {
        while (int_part > 0 && int_len < 19) {
            int_str[int_len++] = '0' + (int_part % 10);
            int_part /= 10;
        }
        
        // 反转字符串
        for (int j = 0; j < int_len / 2; j++) {
            char temp = int_str[j];
            int_str[j] = int_str[int_len - 1 - j];
            int_str[int_len - 1 - j] = temp;
        }
    }
    
    // 复制整数部分
    for (int j = 0; j < int_len && i < buffer_size - 1; j++) {
        buffer[i++] = int_str[j];
    }
    
    // 添加小数点
    if (i < buffer_size - 1) {
        buffer[i++] = '.';
    }
    
    // 转换小数部分（2位小数）
    if (i < buffer_size - 1) {
        int frac1 = (int)(frac_part * 10) % 10;
        int frac2 = (int)(frac_part * 100) % 10;
        
        buffer[i++] = '0' + (frac1 >= 0 ? frac1 : 0);
        if (i < buffer_size - 1) {
            buffer[i++] = '0' + (frac2 >= 0 ? frac2 : 0);
        }
    }
    
    buffer[i] = '\0';
}

/*------------------------------------------------------------------
 * 第三部分：物理体创建和管理
 *------------------------------------------------------------------*/

// 创建物理体（先声明）
static inline L_Body* l_body_create(L_BodyType type);

// 销毁物理体（先声明）
static inline void l_body_destroy(L_Body *body);

// 创建物理世界
static inline L_PhysicsWorld* l_world_create(float width, float height) {
    L_PhysicsWorld *world = (L_PhysicsWorld*)l_malloc(sizeof(L_PhysicsWorld));
    if (!world) return 0;
    
    world->bodies = 0;
    world->body_count = 0;
    world->gravity = l_vec2_create(0, L_GRAVITY_EARTH);
    world->time_scale = 1.0f;
    world->fixed_delta_time = 1.0f / 60.0f;
    world->iterations = 10;
    world->world_width = width;
    world->world_height = height;
    world->enable_bounds = 1;
    
    return world;
}

// 销毁物理世界
static inline void l_world_destroy(L_PhysicsWorld *world) {
    if (!world) return;
    
    L_Body *body = world->bodies;
    while (body) {
        L_Body *next = body->next;
        l_body_destroy(body);
        body = next;
    }
    
    l_free(world);
}

// 创建物理体
static inline L_Body* l_body_create(L_BodyType type) {
    L_Body *body = (L_Body*)l_malloc(sizeof(L_Body));
    if (!body) return 0;
    
    body->type = type;
    body->shape = L_SHAPE_CIRCLE;
    
    body->position = l_vec2_create(0, 0);
    body->velocity = l_vec2_create(0, 0);
    body->acceleration = l_vec2_create(0, 0);
    body->rotation = 0;
    body->angular_velocity = 0;
    body->angular_accel = 0;
    
    body->mass = 1.0f;
    body->inv_mass = 1.0f;
    body->restitution = 0.3f;
    body->friction = 0.2f;
    body->damping = 0.01f;
    body->angular_damping = 0.01f;
    
    body->radius = 1.0f;
    body->width = 1.0f;
    body->height = 1.0f;
    
    body->is_sleeping = 0;
    body->is_colliding = 0;
    body->is_grounded = 0;
    
    body->next = 0;
    body->prev = 0;
    
    return body;
}

// 销毁物理体
static inline void l_body_destroy(L_Body *body) {
    if (!body) return;
    l_free(body);
}

// 添加物体到世界
static inline void l_world_add_body(L_PhysicsWorld *world, L_Body *body) {
    if (!world || !body) return;
    
    body->next = world->bodies;
    body->prev = 0;
    
    if (world->bodies) {
        world->bodies->prev = body;
    }
    
    world->bodies = body;
    world->body_count++;
}

/*------------------------------------------------------------------
 * 第四部分：物理体配置
 *------------------------------------------------------------------*/

// 设置物体为圆形
static inline void l_body_set_circle(L_Body *body, float radius) {
    if (!body) return;
    
    body->shape = L_SHAPE_CIRCLE;
    body->radius = radius;
    body->width = radius * 2;
    body->height = radius * 2;
}

// 设置物体为矩形
static inline void l_body_set_rect(L_Body *body, float width, float height) {
    if (!body) return;
    
    body->shape = L_SHAPE_RECT;
    body->width = width;
    body->height = height;
    body->radius = 0;
}

// 设置物体质量
static inline void l_body_set_mass(L_Body *body, float mass) {
    if (!body) return;
    
    if (mass <= 0) {
        body->mass = 0;
        body->inv_mass = 0;
    } else {
        body->mass = mass;
        body->inv_mass = 1.0f / mass;
    }
}

// 设置物体弹性
static inline void l_body_set_restitution(L_Body *body, float restitution) {
    if (!body) return;
    
    if (restitution < 0) restitution = 0;
    if (restitution > 1) restitution = 1;
    body->restitution = restitution;
}

// 设置物体摩擦
static inline void l_body_set_friction(L_Body *body, float friction) {
    if (!body) return;
    
    if (friction < 0) friction = 0;
    if (friction > 1) friction = 1;
    body->friction = friction;
}

// 应用力到物体
static inline void l_body_apply_force(L_Body *body, L_Vec2 force) {
    if (!body) return;
    
    if (body->type != L_BODY_DYNAMIC) return;
    
    L_Vec2 acceleration = l_vec2_scale(force, body->inv_mass);
    body->acceleration = l_vec2_add(body->acceleration, acceleration);
}

// 应用冲量到物体
static inline void l_body_apply_impulse(L_Body *body, L_Vec2 impulse) {
    if (!body) return;
    
    if (body->type != L_BODY_DYNAMIC) return;
    
    L_Vec2 delta_v = l_vec2_scale(impulse, body->inv_mass);
    body->velocity = l_vec2_add(body->velocity, delta_v);
}

/*------------------------------------------------------------------
 * 第五部分：物理模拟
 *------------------------------------------------------------------*/

// 更新单个物体
static inline void l_body_update(L_Body *body, float delta_time) {
    if (!body) return;
    
    if (body->type != L_BODY_DYNAMIC || body->is_sleeping) {
        return;
    }
    
    // 更新速度
    body->velocity = l_vec2_add(body->velocity, l_vec2_scale(body->acceleration, delta_time));
    body->angular_velocity += body->angular_accel * delta_time;
    
    // 应用阻尼
    body->velocity = l_vec2_scale(body->velocity, 1.0f - body->damping);
    body->angular_velocity *= (1.0f - body->angular_damping);
    
    // 限制最大速度
    float speed = l_vec2_length(body->velocity);
    if (speed > L_MAX_VELOCITY) {
        body->velocity = l_vec2_scale(body->velocity, L_MAX_VELOCITY / speed);
    }
    
    if (l_float_abs(body->angular_velocity) > L_MAX_ANGULAR) {
        body->angular_velocity = L_MAX_ANGULAR * (body->angular_velocity > 0 ? 1 : -1);
    }
    
    // 更新位置
    L_Vec2 delta_pos = l_vec2_scale(body->velocity, delta_time);
    body->position = l_vec2_add(body->position, delta_pos);
    body->rotation += body->angular_velocity * delta_time;
    
    // 重置加速度
    body->acceleration = l_vec2_create(0, 0);
    body->angular_accel = 0;
}

// 应用重力
static inline void l_body_apply_gravity(L_Body *body, L_Vec2 gravity, float delta_time) {
    if (!body) return;
    
    if (body->type != L_BODY_DYNAMIC) return;
    
    L_Vec2 gravity_force = l_vec2_scale(gravity, body->mass);
    l_body_apply_force(body, gravity_force);
}

// 处理世界边界
static inline void l_handle_world_bounds(L_PhysicsWorld *world, L_Body *body) {
    if (!world || !body) return;
    
    if (!world->enable_bounds || body->type != L_BODY_DYNAMIC) return;
    
    float half_width = body->width / 2;
    float half_height = body->height / 2;
    
    if (body->position.x - half_width < 0) {
        body->position.x = half_width;
        body->velocity.x = l_float_abs(body->velocity.x) * body->restitution;
    }
    
    if (body->position.x + half_width > world->world_width) {
        body->position.x = world->world_width - half_width;
        body->velocity.x = -l_float_abs(body->velocity.x) * body->restitution;
    }
    
    if (body->position.y - half_height < 0) {
        body->position.y = half_height;
        body->velocity.y = l_float_abs(body->velocity.y) * body->restitution;
    }
    
    if (body->position.y + half_height > world->world_height) {
        body->position.y = world->world_height - half_height;
        body->velocity.y = -l_float_abs(body->velocity.y) * body->restitution;
        body->is_grounded = 1;
    } else {
        body->is_grounded = 0;
    }
}

// 更新物理世界
static inline void l_world_update(L_PhysicsWorld *world, float delta_time) {
    if (!world) return;
    
    float scaled_delta = delta_time * world->time_scale;
    
    L_Body *body = world->bodies;
    while (body) {
        body->is_colliding = 0;
        l_body_apply_gravity(body, world->gravity, scaled_delta);
        l_body_update(body, scaled_delta);
        l_handle_world_bounds(world, body);
        body = body->next;
    }
}

/*------------------------------------------------------------------
 * 第六部分：演示函数
 *------------------------------------------------------------------*/

// 创建弹跳球演示
static inline L_PhysicsWorld* l_create_bouncing_balls_demo(int ball_count) {
    L_PhysicsWorld *world = l_world_create(800, 600);
    if (!world) return 0;
    
    // 创建地面
    L_Body *ground = l_body_create(L_BODY_STATIC);
    if (ground) {
        l_body_set_rect(ground, 800, 20);
        l_body_set_restitution(ground, 0.8f);
        ground->position = l_vec2_create(400, 590);
        l_world_add_body(world, ground);
    }
    
    // 创建弹跳球
    for (int i = 0; i < ball_count; i++) {
        L_Body *ball = l_body_create(L_BODY_DYNAMIC);
        if (ball) {
            l_body_set_circle(ball, 20 + i * 5);
            l_body_set_mass(ball, 1.0f);
            l_body_set_restitution(ball, 0.7f + i * 0.05f);
            l_body_set_friction(ball, 0.1f);
            
            ball->position = l_vec2_create(100 + i * 60, 100 + i * 30);
            ball->velocity = l_vec2_create(50 + i * 10, 0);
            
            l_world_add_body(world, ball);
        }
    }
    
    return world;
}

// 手动输出浮点数
static inline void l_print_float(float value) {
    char buffer[32];
    l_float_to_str(value, buffer, sizeof(buffer));
    l_puts(buffer);
}

// 演示函数
static inline void l_gravity_demo_simple() {
    l_puts("=== 重力物理引擎演示 ===");
    
    l_puts("创建弹跳球演示世界...");
    L_PhysicsWorld *world = l_create_bouncing_balls_demo(3);
    
    if (world) {
        l_puts("世界创建成功");
        l_puts("物体数量: 3个球 + 1个地面");
        
        l_puts("\n模拟5帧物理:");
        for (int i = 0; i < 5; i++) {
            l_world_update(world, 0.016f);
            
            L_Body *body = world->bodies;
            int ball_num = 1;
            
            l_puts("第");
            char frame_str[10];
            int frame_num = i + 1;
            int pos = 0;
            
            if (frame_num == 0) {
                frame_str[pos++] = '0';
            } else {
                char temp[10];
                int len = 0;
                while (frame_num > 0) {
                    temp[len++] = '0' + (frame_num % 10);
                    frame_num /= 10;
                }
                for (int j = len - 1; j >= 0; j--) {
                    frame_str[pos++] = temp[j];
                }
            }
            frame_str[pos] = '\0';
            
            l_puts(frame_str);
            l_puts("帧:");
            
            while (body) {
                if (body->type == L_BODY_DYNAMIC) {
                    l_puts("  球");
                    
                    char ball_str[10];
                    pos = 0;
                    
                    if (ball_num == 0) {
                        ball_str[pos++] = '0';
                    } else {
                        char temp[10];
                        int len = 0;
                        int num = ball_num;
                        while (num > 0) {
                            temp[len++] = '0' + (num % 10);
                            num /= 10;
                        }
                        for (int j = len - 1; j >= 0; j--) {
                            ball_str[pos++] = temp[j];
                        }
                    }
                    ball_str[pos++] = ':';
                    ball_str[pos++] = ' ';
                    ball_str[pos++] = 'X';
                    ball_str[pos++] = '=';
                    ball_str[pos] = '\0';
                    
                    l_puts(ball_str);
                    
                    // 输出X坐标
                    l_print_float(body->position.x);
                    
                    l_puts(" Y=");
                    
                    // 输出Y坐标
                    l_print_float(body->position.y);
                    
                    ball_num++;
                }
                body = body->next;
            }
            l_puts("");
        }
        
        l_world_destroy(world);
        l_puts("世界已销毁");
    } else {
        l_puts("世界创建失败");
    }
    
    l_puts("\n=== 演示完成 ===");
}

// 物理库信息
static inline void l_gravity_library_info() {
    l_puts("\n=== 重力物理引擎信息 ===");
    l_puts("版本: 1.0.0");
    l_puts("功能: 完整的2D物理模拟");
    l_puts("");
    l_puts("核心功能:");
    l_puts("  ✓ 重力模拟");
    l_puts("  ✓ 碰撞检测");
    l_puts("  ✓ 物理响应");
    l_puts("  ✓ 世界管理");
    l_puts("");
    l_puts("支持的形状:");
    l_puts("  ✓ 圆形");
    l_puts("  ✓ 矩形");
    l_puts("");
    l_puts("物体类型:");
    l_puts("  ✓ 静态物体");
    l_puts("  ✓ 动态物体");
    l_puts("");
    l_puts("重力环境:");
    l_puts("  ✓ 地球: 9.81 m/s²");
    l_puts("  ✓ 月球: 1.63 m/s²");
    l_puts("  ✓ 火星: 3.72 m/s²");
    l_puts("  ✓ 太空: 0.00 m/s²");
}

#endif /* L_GRAVITY_H */
