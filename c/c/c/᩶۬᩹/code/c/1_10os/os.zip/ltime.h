#ifndef L_TIME_H
#define L_TIME_H

#include "lstdios.h"
#include "lnull.h"

#define L_TIME_SYS_TIME 201
#define L_TIME_SYS_GETTIMEOFDAY 169
#define L_TIME_SYS_CLOCK_GETTIME 113
#define L_TIME_SYS_NANOSLEEP 101

#define L_TIME_CLOCK_REALTIME 0
#define L_TIME_CLOCK_MONOTONIC 1
#define L_TIME_CLOCK_PROCESS_CPUTIME_ID 2
#define L_TIME_CLOCK_THREAD_CPUTIME_ID 3
#define L_TIME_CLOCK_BOOTTIME 7

typedef struct {
    long tv_sec;
    long tv_nsec;
} L_TimeSpec;

typedef struct {
    long tv_sec;
    long tv_usec;
} L_TimeVal;

typedef struct {
    long seconds;
    long nanoseconds;
} L_TimeSpan;

typedef struct {
    int year;
    int month;
    int day;
    int hour;
    int minute;
    int second;
    int millisecond;
    int weekday;
    int yearday;
} L_DateTime;

static const char* L_MONTH_NAMES_EN[12] = {
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
};

static const char* L_WEEKDAY_NAMES_EN[7] = {
    "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"
};

static const char* L_MONTH_NAMES_CN[12] = {
    "一月", "二月", "三月", "四月", "五月", "六月",
    "七月", "八月", "九月", "十月", "十一月", "十二月"
};

static const char* L_WEEKDAY_NAMES_CN[7] = {
    "星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"
};

static inline long l_gettime() {
    long ret;
    __asm__ volatile (
        "mov x8, %[syscall_num]\n"
        "svc 0"
        : "=r" (ret)
        : [syscall_num] "I" (L_TIME_SYS_TIME)
        : "x8", "memory"
    );
    return ret;
}

static inline int l_gettimeofday(L_TimeVal *tv) {
    long ret;
    __asm__ volatile (
        "mov x8, %[syscall_num]\n"
        "svc 0"
        : "=r" (ret)
        : [syscall_num] "I" (L_TIME_SYS_GETTIMEOFDAY), "r" (tv)
        : "x8", "memory"
    );
    return (int)ret;
}

static inline int l_clock_gettime(int clk_id, L_TimeSpec *ts) {
    long ret;
    __asm__ volatile (
        "mov x8, %[syscall_num]\n"
        "svc 0"
        : "=r" (ret)
        : [syscall_num] "I" (L_TIME_SYS_CLOCK_GETTIME), "r" (clk_id), "r" (ts)
        : "x8", "memory"
    );
    return (int)ret;
}

static inline long l_get_timestamp() {
    return l_gettime();
}

static inline long long l_get_timestamp_ms() {
    L_TimeVal tv;
    l_gettimeofday(&tv);
    return (long long)tv.tv_sec * 1000LL + tv.tv_usec / 1000;
}

static inline long long l_get_timestamp_us() {
    L_TimeVal tv;
    l_gettimeofday(&tv);
    return (long long)tv.tv_sec * 1000000LL + tv.tv_usec;
}

static inline long long l_get_monotonic_time() {
    L_TimeSpec ts;
    l_clock_gettime(L_TIME_CLOCK_MONOTONIC, &ts);
    return (long long)ts.tv_sec * 1000000000LL + ts.tv_nsec;
}

static inline int l_nanosleep(const L_TimeSpec *req) {
    L_TimeSpec rem = {0, 0};
    return l_syscall(L_TIME_SYS_NANOSLEEP, (long)req, (long)&rem, 0, 0, 0, 0);
}

static inline int l_is_leap_year(int year) {
    return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
}

static inline int l_days_in_month(int year, int month) {
    static const int days[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    if (month == 2 && l_is_leap_year(year)) {
        return 29;
    }
    if (month >= 1 && month <= 12) {
        return days[month - 1];
    }
    return 0;
}

static L_DateTime l_timestamp_to_datetime(long timestamp) {
    L_DateTime dt = {0};
    long days, rem;
    
    days = timestamp / 86400;
    rem = timestamp % 86400;
    
    dt.weekday = (days + 4) % 7;
    
    int year = 1970;
    while (days >= (l_is_leap_year(year) ? 366 : 365)) {
        days -= l_is_leap_year(year) ? 366 : 365;
        year++;
    }
    dt.year = year;
    dt.yearday = (int)days;
    
    int month = 1;
    while (days >= l_days_in_month(year, month)) {
        days -= l_days_in_month(year, month);
        month++;
    }
    dt.month = month;
    dt.day = (int)days + 1;
    
    dt.hour = (int)(rem / 3600);
    dt.minute = (int)((rem % 3600) / 60);
    dt.second = (int)(rem % 60);
    
    return dt;
}

static long l_datetime_to_timestamp(const L_DateTime *dt) {
    L_RETURN_IF_NULL(dt, 0);
    
    long days = 0;
    
    for (int y = 1970; y < dt->year; y++) {
        days += l_is_leap_year(y) ? 366 : 365;
    }
    
    for (int m = 1; m < dt->month; m++) {
        days += l_days_in_month(dt->year, m);
    }
    
    days += (dt->day - 1);
    
    long seconds = days * 86400L;
    seconds += dt->hour * 3600L;
    seconds += dt->minute * 60L;
    seconds += dt->second;
    
    return seconds;
}

static int l_format_int(char *buffer, int buffer_size, int value, int width, int zero_pad) {
    L_RETURN_IF_NULL(buffer, 0);
    if (buffer_size <= 0) return 0;
    
    char temp[32];
    int len = 0;
    int v = value;
    
    do {
        temp[len++] = '0' + (v % 10);
        v /= 10;
    } while (v > 0 && len < 31);
    
    for (int i = 0; i < len / 2; i++) {
        char tmp = temp[i];
        temp[i] = temp[len - 1 - i];
        temp[len - 1 - i] = tmp;
    }
    
    int pos = 0;
    while (zero_pad && len < width && pos < buffer_size - 1) {
        buffer[pos++] = '0';
        width--;
    }
    
    for (int i = 0; i < len && pos < buffer_size - 1; i++) {
        buffer[pos++] = temp[i];
    }
    
    buffer[pos] = '\0';
    return pos;
}

static void l_format_datetime(const L_DateTime *dt, char *buffer, int buffer_size, const char *format) {
    if (L_IS_NULL(dt) || L_IS_NULL(buffer) || L_IS_NULL(format) || buffer_size <= 0) {
        return;
    }
    
    int pos = 0;
    const char *p = format;
    
    while (*p && pos < buffer_size - 1) {
        if (*p == '%') {
            p++;
            switch (*p) {
                case 'Y':
                    pos += l_format_int(buffer + pos, buffer_size - pos, dt->year, 4, 1);
                    break;
                case 'y':
                    pos += l_format_int(buffer + pos, buffer_size - pos, dt->year % 100, 2, 1);
                    break;
                case 'm':
                    pos += l_format_int(buffer + pos, buffer_size - pos, dt->month, 2, 1);
                    break;
                case 'd':
                    pos += l_format_int(buffer + pos, buffer_size - pos, dt->day, 2, 1);
                    break;
                case 'H':
                    pos += l_format_int(buffer + pos, buffer_size - pos, dt->hour, 2, 1);
                    break;
                case 'M':
                    pos += l_format_int(buffer + pos, buffer_size - pos, dt->minute, 2, 1);
                    break;
                case 'S':
                    pos += l_format_int(buffer + pos, buffer_size - pos, dt->second, 2, 1);
                    break;
                case 'w':
                    if (pos < buffer_size - 1) {
                        buffer[pos++] = '0' + dt->weekday;
                    }
                    break;
                case 'F':
                    if (pos < buffer_size - 10) {
                        buffer[pos++] = '0' + (dt->year / 1000);
                        buffer[pos++] = '0' + ((dt->year / 100) % 10);
                        buffer[pos++] = '0' + ((dt->year / 10) % 10);
                        buffer[pos++] = '0' + (dt->year % 10);
                        buffer[pos++] = '-';
                        buffer[pos++] = '0' + (dt->month / 10);
                        buffer[pos++] = '0' + (dt->month % 10);
                        buffer[pos++] = '-';
                        buffer[pos++] = '0' + (dt->day / 10);
                        buffer[pos++] = '0' + (dt->day % 10);
                    }
                    break;
                case 'T':
                    if (pos < buffer_size - 9) {
                        buffer[pos++] = '0' + (dt->hour / 10);
                        buffer[pos++] = '0' + (dt->hour % 10);
                        buffer[pos++] = ':';
                        buffer[pos++] = '0' + (dt->minute / 10);
                        buffer[pos++] = '0' + (dt->minute % 10);
                        buffer[pos++] = ':';
                        buffer[pos++] = '0' + (dt->second / 10);
                        buffer[pos++] = '0' + (dt->second % 10);
                    }
                    break;
                case '%':
                    if (pos < buffer_size - 1) {
                        buffer[pos++] = '%';
                    }
                    break;
                default:
                    if (pos < buffer_size - 1) {
                        buffer[pos++] = *p;
                    }
                    break;
            }
        } else {
            if (pos < buffer_size - 1) {
                buffer[pos++] = *p;
            }
        }
        p++;
    }
    
    buffer[pos] = '\0';
}

static void l_current_time_str(char *buffer, int buffer_size, const char *format) {
    long timestamp = l_get_timestamp();
    L_DateTime dt = l_timestamp_to_datetime(timestamp);
    l_format_datetime(&dt, buffer, buffer_size, format);
}

static L_TimeSpan l_time_diff(long timestamp1, long timestamp2) {
    L_TimeSpan span;
    long diff = timestamp1 - timestamp2;
    if (diff < 0) diff = -diff;
    span.seconds = diff;
    span.nanoseconds = 0;
    return span;
}

static void l_format_timespan(const L_TimeSpan *span, char *buffer, int buffer_size) {
    if (L_IS_NULL(span) || L_IS_NULL(buffer) || buffer_size <= 0) {
        return;
    }
    
    long seconds = span->seconds;
    long days = seconds / 86400;
    seconds %= 86400;
    long hours = seconds / 3600;
    seconds %= 3600;
    long minutes = seconds / 60;
    seconds %= 60;
    
    int pos = 0;
    
    if (days > 0) {
        pos += l_format_int(buffer + pos, buffer_size - pos, (int)days, 0, 0);
        if (pos < buffer_size - 3) {
            buffer[pos++] = 'd';
            buffer[pos++] = 'a';
            buffer[pos++] = 'y';
        }
    }
    
    if (hours > 0 || days > 0) {
        pos += l_format_int(buffer + pos, buffer_size - pos, (int)hours, 2, 1);
        if (pos < buffer_size - 1) {
            buffer[pos++] = ':';
        }
    }
    
    if (minutes > 0 || hours > 0 || days > 0) {
        pos += l_format_int(buffer + pos, buffer_size - pos, (int)minutes, 2, 1);
        if (pos < buffer_size - 1) {
            buffer[pos++] = ':';
        }
    }
    
    pos += l_format_int(buffer + pos, buffer_size - pos, (int)seconds, 2, 1);
    
    buffer[pos] = '\0';
}

typedef struct {
    long long start_time;
    long long end_time;
} L_Timer;

static inline void l_timer_start(L_Timer *timer) {
    if (L_IS_NULL(timer)) return;
    
    L_TimeSpec ts;
    l_clock_gettime(L_TIME_CLOCK_MONOTONIC, &ts);
    timer->start_time = (long long)ts.tv_sec * 1000000000LL + ts.tv_nsec;
}

static inline void l_timer_stop(L_Timer *timer) {
    if (L_IS_NULL(timer)) return;
    
    L_TimeSpec ts;
    l_clock_gettime(L_TIME_CLOCK_MONOTONIC, &ts);
    timer->end_time = (long long)ts.tv_sec * 1000000000LL + ts.tv_nsec;
}

static inline long long l_timer_elapsed_ns(const L_Timer *timer) {
    if (L_IS_NULL(timer) || timer->end_time < timer->start_time) return 0;
    return timer->end_time - timer->start_time;
}

static inline double l_timer_elapsed_ms(const L_Timer *timer) {
    return l_timer_elapsed_ns(timer) / 1000000.0;
}

static void l_time_demo() {
    l_puts("\n=== 时间库功能演示 ===");
    
    l_print("当前时间戳 (秒): ");
    l_putint(l_get_timestamp());
    l_puts("");
    
    l_print("当前时间戳 (毫秒): ");
    l_putint(l_get_timestamp_ms());
    l_puts("");
    
    l_print("当前时间戳 (微秒): ");
    l_putint(l_get_timestamp_us());
    l_puts("");
    
    long now = l_get_timestamp();
    L_DateTime dt = l_timestamp_to_datetime(now);
    
    l_print("当前日期时间: ");
    l_printf("%04d-%02d-%02d %02d:%02d:%02d (星期%d)\n", 
             dt.year, dt.month, dt.day, dt.hour, dt.minute, dt.second, dt.weekday);
    
    char time_str[64];
    l_current_time_str(time_str, sizeof(time_str), "%F %T");
    l_print("格式化时间: ");
    l_puts(time_str);
    
    l_current_time_str(time_str, sizeof(time_str), "%Y年%m月%d日 %H:%M:%S");
    l_puts(time_str);
    
    l_puts("\n--- 时间差计算演示 ---");
    long time1 = l_get_timestamp();
    l_print("等待1秒...");
    l_puts("");
    l_sleep(1, 0);
    long time2 = l_get_timestamp();
    
    L_TimeSpan diff = l_time_diff(time2, time1);
    l_format_timespan(&diff, time_str, sizeof(time_str));
    l_print("时间差: ");
    l_puts(time_str);
    
    l_puts("\n--- 性能计时演示 ---");
    L_Timer timer;
    l_timer_start(&timer);
    
    volatile int sum = 0;
    for (int i = 0; i < 1000000; i++) {
        sum += i;
    }
    
    l_timer_stop(&timer);
    l_print("循环计算耗时: ");
    l_printf("%.0f 纳秒 (%.3f 毫秒)\n", 
             (double)l_timer_elapsed_ns(&timer), 
             l_timer_elapsed_ms(&timer));
    
    l_puts("\n--- 闰年判断演示 ---");
    int test_years[] = {1900, 2000, 2024, 2100};
    for (int i = 0; i < 4; i++) {
        l_printf("%d 年是闰年吗? %s\n", 
                 test_years[i], 
                 l_is_leap_year(test_years[i]) ? "是" : "否");
    }
    
    l_puts("=== 演示结束 ===");
}

#endif /* L_TIME_H */
