/**
 * Copyright [2023] [LAOLIPEF]
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
 
#ifndef L_MATH_H
#define L_MATH_H

#include "lstdios.h"  // 包含基础库，用于错误处理

// 数学常数定义
#define L_MATH_E          2718281828  // e * 10^9
#define L_MATH_PI         3141592654  // π * 10^9
#define L_MATH_TAU        6283185307  // 2π * 10^9
#define L_MATH_SQRT2      1414213562  // √2 * 10^9
#define L_MATH_SQRT1_2    707106781   // √0.5 * 10^9
#define L_MATH_LN2        693147180   // ln2 * 10^9
#define L_MATH_LN10       2302585093  // ln10 * 10^9
#define L_MATH_DEG_TO_RAD 174532925   // π/180 * 10^9
#define L_MATH_RAD_TO_DEG 572957795   // 180/π * 10^9

// 浮点类型（固定精度）
typedef long l_fixed;  // 定点数：16.16格式（16位整数，16位小数）
#define L_FIXED_SHIFT 16
#define L_FIXED_ONE   ((l_fixed)1 << L_FIXED_SHIFT)
#define L_FIXED_HALF  ((l_fixed)1 << (L_FIXED_SHIFT - 1))

// 错误码 - 数学特定错误（基于拼音九键）
#define L_EMATH_DOMAIN    -61   // 61=ma: 定义域错误
#define L_EMATH_RANGE     -62   // 62=mb: 值域错误
#define L_EMATH_OVERFLOW  -65   // 65=me: 数学溢出

// ==================== 定点数基本操作 ====================

// 数学库特有的绝对值函数
static l_fixed l_fabs(l_fixed x) {
    return (x < 0) ? -x : x;
}

// 数学库特有的最大值/最小值
static l_fixed l_fmax(l_fixed a, l_fixed b) {
    return (a > b) ? a : b;
}

static l_fixed l_fmin(l_fixed a, l_fixed b) {
    return (a < b) ? a : b;
}

// 钳制函数
static l_fixed l_fclamp(l_fixed x, l_fixed min, l_fixed max) {
    if (x < min) return min;
    if (x > max) return max;
    return x;
}

// 线性插值
static l_fixed l_flerp(l_fixed a, l_fixed b, l_fixed t) {
    // a + (b - a) * t
    return a + (((b - a) * t) >> L_FIXED_SHIFT);
}

// 映射范围
static l_fixed l_fmap(l_fixed x, l_fixed in_min, l_fixed in_max, 
                     l_fixed out_min, l_fixed out_max) {
    if (in_max == in_min) return out_min;
    l_fixed t = ((x - in_min) << L_FIXED_SHIFT) / (in_max - in_min);
    return l_flerp(out_min, out_max, t);
}

// 符号函数
static int l_fsign(l_fixed x) {
    if (x > 0) return 1;
    if (x < 0) return -1;
    return 0;
}

// 步进函数
static l_fixed l_fstep(l_fixed edge, l_fixed x) {
    return (x < edge) ? 0 : L_FIXED_ONE;
}

// 平滑步进函数
static l_fixed l_fsmoothstep(l_fixed edge0, l_fixed edge1, l_fixed x) {
    x = l_fclamp(((x - edge0) << L_FIXED_SHIFT) / (edge1 - edge0), 0, L_FIXED_ONE);
    l_fixed temp = (3 - ((2 * x) >> L_FIXED_SHIFT));
    return (x * x * temp) >> L_FIXED_SHIFT;
}

// ==================== 定点数转换 ====================

// 整数转定点数
static l_fixed l_int_to_fixed(int n) {
    return (l_fixed)n << L_FIXED_SHIFT;
}

// 定点数转整数（四舍五入）
static int l_fixed_to_int(l_fixed x) {
    return (int)((x + L_FIXED_HALF) >> L_FIXED_SHIFT);
}

// 定点数转整数（向下取整）
static int l_fixed_floor(l_fixed x) {
    return (int)(x >> L_FIXED_SHIFT);
}

// 定点数转整数（向上取整）
static int l_fixed_ceil(l_fixed x) {
    return (int)((x + (L_FIXED_ONE - 1)) >> L_FIXED_SHIFT);
}

// 定点数转浮点字符串
static char* l_fixed_to_str(l_fixed x, char *buf, int precision) {
    int int_part = (int)(x >> L_FIXED_SHIFT);
    l_fixed frac_part = l_fabs(x) & (L_FIXED_ONE - 1);
    
    // 处理负数
    if (x < 0 && int_part == 0) {
        buf[0] = '-';
        buf[1] = '0';
        l_strcpy(buf + 2, "");
    } else {
        l_itoa(int_part, buf, 10);
    }
    
    int len = l_strlen(buf);
    
    if (precision > 0 && precision <= 6) {
        buf[len++] = '.';
        
        // 计算小数部分
        for (int i = 0; i < precision; i++) {
            frac_part *= 10;
            int digit = (int)(frac_part >> L_FIXED_SHIFT);
            buf[len++] = '0' + (char)digit;
            frac_part &= (L_FIXED_ONE - 1);
        }
        buf[len] = '\0';
    }
    
    return buf;
}

// 字符串转定点数
static l_fixed l_str_to_fixed(const char *str) {
    int int_part = 0;
    l_fixed frac_part = 0;
    int sign = 1;
    int i = 0;
    
    // 处理符号
    if (str[0] == '-') {
        sign = -1;
        i++;
    } else if (str[0] == '+') {
        i++;
    }
    
    // 整数部分
    while (str[i] >= '0' && str[i] <= '9') {
        int_part = int_part * 10 + (str[i] - '0');
        i++;
    }
    
    // 小数部分
    if (str[i] == '.') {
        i++;
        l_fixed factor = L_FIXED_ONE / 10;
        while (str[i] >= '0' && str[i] <= '9' && factor > 0) {
            frac_part += (str[i] - '0') * factor;
            factor /= 10;
            i++;
        }
    }
    
    l_fixed result = (l_fixed)(sign * int_part) << L_FIXED_SHIFT;
    result += sign * frac_part;
    
    return result;
}

// ==================== 幂和指数函数 ====================

// 整数幂
static int l_ipow(int base, int exp) {
    int result = 1;
    int b = base;
    int e = exp;
    
    while (e > 0) {
        if (e & 1) {
            result *= b;
        }
        b *= b;
        e >>= 1;
    }
    return result;
}

// 定点数平方
static l_fixed l_fsqr(l_fixed x) {
    return (x * x) >> L_FIXED_SHIFT;
}

// 平方根（快速整数平方根）
static l_fixed l_fsqrt(l_fixed x) {
    if (x <= 0) return 0;
    
    l_fixed root = 0;
    l_fixed rem = 0;
    l_fixed divisor = 0;
    
    for (int i = 15; i >= 0; i--) {
        root <<= 1;
        rem = (rem << 2) | ((x >> (i * 2 + L_FIXED_SHIFT)) & 3);
        divisor = (root << 1) | 1;
        
        if (divisor <= rem) {
            rem -= divisor;
            root |= 1;
        }
    }
    
    return root;
}

// 立方根
static l_fixed l_fcbrt(l_fixed x) {
    if (x == 0) return 0;
    
    l_fixed result = x;
    l_fixed prev = 0;
    
    for (int i = 0; i < 20; i++) {  // 迭代20次
        prev = result;
        l_fixed sqr = (result * result) >> L_FIXED_SHIFT;
        result = (2 * result + ((x << L_FIXED_SHIFT) / sqr)) / 3;
        
        if (l_fabs(result - prev) < 2) break;
    }
    
    return result;
}

// 倒数
static l_fixed l_frecip(l_fixed x) {
    if (x == 0) return 0x7FFFFFFF;  // 返回极大值
    return ((l_fixed)1 << (L_FIXED_SHIFT * 2)) / x;
}

// 指数函数 e^x（近似）
static l_fixed l_fexp(l_fixed x) {
    // 处理大数
    l_fixed limit = 10 << L_FIXED_SHIFT;
    if (x > limit) return 0x7FFFFFFF;
    if (x < -limit) return 0;
    
    // 使用近似公式：e^x ≈ 1 + x + x²/2
    l_fixed x2 = (x * x) >> L_FIXED_SHIFT;
    l_fixed x3 = (x2 * x) >> L_FIXED_SHIFT;
    
    return L_FIXED_ONE + x + (x2 >> 1) + (x3 / 6);
}

// 自然对数 ln(x)（近似）
static l_fixed l_fln(l_fixed x) {
    if (x <= 0) return 0x80000000;
    
    // 简单近似：ln(x) ≈ 2*(x-1)/(x+1) 对于x接近1
    if (x > (L_FIXED_ONE >> 1) && x < (L_FIXED_ONE << 1)) {
        l_fixed y = (x - L_FIXED_ONE) << 1;
        l_fixed denom = x + L_FIXED_ONE;
        return (y << L_FIXED_SHIFT) / denom;
    }
    
    // 对于其他值，使用查表法近似
    if (x < L_FIXED_ONE) {
        return -l_fln((L_FIXED_ONE << L_FIXED_SHIFT) / x);
    }
    
    // 二分查找近似
    l_fixed low = 0;
    l_fixed high = 10 << L_FIXED_SHIFT;  // ln(10) ≈ 2.3026
    
    for (int i = 0; i < 16; i++) {
        l_fixed mid = (low + high) >> 1;
        l_fixed exp_mid = l_fexp(mid);
        
        if (exp_mid < x) {
            low = mid;
        } else {
            high = mid;
        }
    }
    
    return low;
}

// 以10为底的对数
static l_fixed l_flog10(l_fixed x) {
    l_fixed ln_x = l_fln(x);
    if (ln_x == 0x80000000) return 0x80000000;
    
    return (ln_x << L_FIXED_SHIFT) / 2302585093;  // 除以ln(10)
}

// 幂函数 x^y
static l_fixed l_fpow(l_fixed x, l_fixed y) {
    if (x == 0) return 0;
    if (y == 0) return L_FIXED_ONE;
    
    l_fixed ln_x = l_fln(x);
    if (ln_x == 0x80000000) return 0x80000000;
    
    l_fixed exponent = (y * ln_x) >> L_FIXED_SHIFT;
    return l_fexp(exponent);
}

// ==================== 随机数生成 ====================

// 线性同余生成器
static unsigned long l_rand_seed = 1;

static void l_srand(unsigned long seed) {
    l_rand_seed = seed;
}

static int l_rand(void) {
    l_rand_seed = l_rand_seed * 1103515245 + 12345;
    return (int)((l_rand_seed >> 16) & 0x7FFF);
}

// 生成指定范围的随机整数
static int l_rand_range(int min, int max) {
    if (min >= max) return min;
    return min + (l_rand() % (max - min + 1));
}

// 生成随机定点数 [0, 1)
static l_fixed l_frand(void) {
    return ((l_fixed)l_rand() << L_FIXED_SHIFT) / 0x7FFF;
}

// 生成指定范围的随机定点数
static l_fixed l_frand_range(l_fixed min, l_fixed max) {
    l_fixed range = max - min;
    l_fixed rand_val = l_frand();
    return min + ((range * rand_val) >> L_FIXED_SHIFT);
}

// 高斯随机数（Box-Muller变换简化版）
static l_fixed l_frand_gaussian(l_fixed mean, l_fixed stddev) {
    // 使用中心极限定理近似
    l_fixed sum = 0;
    for (int i = 0; i < 12; i++) {
        sum += l_frand();
    }
    sum = sum >> 1;  // 平均值约为0.5
    
    // 标准化到标准正态分布
    l_fixed z = (sum - (6 * L_FIXED_ONE)) >> 2;
    
    return mean + ((stddev * z) >> L_FIXED_SHIFT);
}

// ==================== 几何函数 ====================

// 点是否在矩形内
static int l_point_in_rect(l_fixed px, l_fixed py, 
                          l_fixed rx, l_fixed ry, l_fixed rw, l_fixed rh) {
    return (px >= rx && px <= rx + rw && py >= ry && py <= ry + rh);
}

// 点是否在圆内
static int l_point_in_circle(l_fixed px, l_fixed py, 
                            l_fixed cx, l_fixed cy, l_fixed radius) {
    l_fixed dx = px - cx;
    l_fixed dy = py - cy;
    l_fixed dist_sq = l_fsqr(dx) + l_fsqr(dy);
    return dist_sq <= l_fsqr(radius);
}

// 两点间欧氏距离
static l_fixed l_distance(l_fixed x1, l_fixed y1, l_fixed x2, l_fixed y2) {
    l_fixed dx = x1 - x2;
    l_fixed dy = y1 - y2;
    return l_fsqrt(l_fsqr(dx) + l_fsqr(dy));
}

// 曼哈顿距离
static l_fixed l_manhattan_dist(l_fixed x1, l_fixed y1, l_fixed x2, l_fixed y2) {
    return l_fabs(x1 - x2) + l_fabs(y1 - y2);
}

// 切比雪夫距离
static l_fixed l_chebyshev_dist(l_fixed x1, l_fixed y1, l_fixed x2, l_fixed y2) {
    l_fixed dx = l_fabs(x1 - x2);
    l_fixed dy = l_fabs(y1 - y2);
    return l_fmax(dx, dy);
}

// 线段长度
static l_fixed l_line_length(l_fixed x1, l_fixed y1, l_fixed x2, l_fixed y2) {
    return l_distance(x1, y1, x2, y2);
}

// 矩形面积
static l_fixed l_rect_area(l_fixed w, l_fixed h) {
    return (w * h) >> L_FIXED_SHIFT;
}

// 矩形周长
static l_fixed l_rect_perimeter(l_fixed w, l_fixed h) {
    return 2 * (w + h);
}

// 圆面积
static l_fixed l_circle_area(l_fixed radius) {
    l_fixed r2 = l_fsqr(radius);
    return ((l_fixed)3141592654 * r2) >> 30;  // π * r²
}

// 圆周长
static l_fixed l_circle_circumference(l_fixed radius) {
    return 2 * (((l_fixed)3141592654 * radius) >> 30);
}

// ==================== 实用数学函数 ====================

// 阶乘
static long l_factorial(int n) {
    if (n < 0) return 0;
    if (n > 20) return 0;  // 防止溢出
    
    long result = 1;
    for (int i = 2; i <= n; i++) {
        result *= i;
    }
    return result;
}

// 双阶乘
static long l_double_factorial(int n) {
    if (n <= 0) return 1;
    
    long result = 1;
    for (int i = n; i > 0; i -= 2) {
        result *= i;
    }
    return result;
}

// 组合数 C(n, k)
static long l_combinations(int n, int k) {
    if (k < 0 || k > n) return 0;
    if (k > n - k) k = n - k;
    
    long result = 1;
    for (int i = 1; i <= k; i++) {
        result = result * (n - k + i) / i;
    }
    return result;
}

// 排列数 P(n, k)
static long l_permutations(int n, int k) {
    if (k < 0 || k > n) return 0;
    
    long result = 1;
    for (int i = 0; i < k; i++) {
        result *= (n - i);
    }
    return result;
}

// 最大公约数
static int l_gcd(int a, int b) {
    while (b != 0) {
        int temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}

// 最小公倍数
static int l_lcm(int a, int b) {
    if (a == 0 || b == 0) return 0;
    return (a / l_gcd(a, b)) * b;
}

// 判断是否为素数
static int l_is_prime(int n) {
    if (n <= 1) return 0;
    if (n <= 3) return 1;
    if (n % 2 == 0 || n % 3 == 0) return 0;
    
    for (int i = 5; i * i <= n; i += 6) {
        if (n % i == 0 || n % (i + 2) == 0) return 0;
    }
    return 1;
}

// 斐波那契数列
static long l_fibonacci(int n) {
    if (n <= 0) return 0;
    if (n == 1) return 1;
    
    long a = 0, b = 1;
    for (int i = 2; i <= n; i++) {
        long temp = a + b;
        a = b;
        b = temp;
    }
    return b;
}

// 判断是否为2的幂
static int l_is_power_of_two(unsigned int n) {
    return n && !(n & (n - 1));
}

// 下一个2的幂
static unsigned int l_next_power_of_two(unsigned int n) {
    n--;
    n |= n >> 1;
    n |= n >> 2;
    n |= n >> 4;
    n |= n >> 8;
    n |= n >> 16;
    n++;
    return n;
}

// 位反转
static unsigned int l_bit_reverse(unsigned int n) {
    n = ((n >> 1) & 0x55555555) | ((n & 0x55555555) << 1);
    n = ((n >> 2) & 0x33333333) | ((n & 0x33333333) << 2);
    n = ((n >> 4) & 0x0F0F0F0F) | ((n & 0x0F0F0F0F) << 4);
    n = ((n >> 8) & 0x00FF00FF) | ((n & 0x00FF00FF) << 8);
    n = ((n >> 16) & 0x0000FFFF) | ((n & 0x0000FFFF) << 16);
    return n;
}

// 汉明重量（统计1的个数）
static int l_popcount(unsigned int n) {
    n = n - ((n >> 1) & 0x55555555);
    n = (n & 0x33333333) + ((n >> 2) & 0x33333333);
    n = (n + (n >> 4)) & 0x0F0F0F0F;
    n = n + (n >> 8);
    n = n + (n >> 16);
    return n & 0x3F;
}

// 前导零个数
static int l_clz(unsigned int n) {
    if (n == 0) return 32;
    
    int count = 0;
    if (n <= 0x0000FFFF) { count += 16; n <<= 16; }
    if (n <= 0x00FFFFFF) { count += 8;  n <<= 8;  }
    if (n <= 0x0FFFFFFF) { count += 4;  n <<= 4;  }
    if (n <= 0x3FFFFFFF) { count += 2;  n <<= 2;  }
    if (n <= 0x7FFFFFFF) { count += 1;  n <<= 1;  }
    return count;
}

// 尾随零个数
static int l_ctz(unsigned int n) {
    if (n == 0) return 32;
    return 32 - l_clz(n & -n) - 1;
}

// ==================== 解方程函数 ====================

// 解一元二次方程 ax² + bx + c = 0
// 返回解的数量，解存储在roots中
static int l_solve_quadratic(l_fixed a, l_fixed b, l_fixed c, l_fixed roots[2]) {
    if (a == 0) {  // 退化为一次方程
        if (b == 0) return 0;
        roots[0] = (-c << L_FIXED_SHIFT) / b;
        return 1;
    }
    
    l_fixed delta = l_fsqr(b) - ((a * c) << (L_FIXED_SHIFT + 1));
    if (delta < 0) return 0;
    
    l_fixed sqrt_delta = l_fsqrt(delta);
    roots[0] = (-b + sqrt_delta) * L_FIXED_ONE / (a << 1);
    roots[1] = (-b - sqrt_delta) * L_FIXED_ONE / (a << 1);
    
    return 2;
}

// 贝塞尔曲线
static l_fixed l_bezier_quad(l_fixed p0, l_fixed p1, l_fixed p2, l_fixed t) {
    l_fixed one_minus_t = L_FIXED_ONE - t;
    l_fixed a = l_fsqr(one_minus_t);
    l_fixed b = (2 * one_minus_t * t) >> L_FIXED_SHIFT;
    l_fixed c = l_fsqr(t);
    
    return (a * p0 + b * p1 + c * p2) >> L_FIXED_SHIFT;
}

static l_fixed l_bezier_cubic(l_fixed p0, l_fixed p1, l_fixed p2, l_fixed p3, l_fixed t) {
    l_fixed one_minus_t = L_FIXED_ONE - t;
    l_fixed a = (l_fsqr(one_minus_t) * one_minus_t) >> L_FIXED_SHIFT;
    l_fixed b = (3 * l_fsqr(one_minus_t) * t) >> L_FIXED_SHIFT;
    l_fixed c = (3 * one_minus_t * l_fsqr(t)) >> L_FIXED_SHIFT;
    l_fixed d = (l_fsqr(t) * t) >> L_FIXED_SHIFT;
    
    return (a * p0 + b * p1 + c * p2 + d * p3) >> L_FIXED_SHIFT;
}

// ==================== 统计函数 ====================

// 平均值
static l_fixed l_mean(const l_fixed *data, int n) {
    if (n <= 0) return 0;
    
    l_fixed sum = 0;
    for (int i = 0; i < n; i++) {
        sum += data[i];
    }
    return sum / n;
}

// 方差
static l_fixed l_variance(const l_fixed *data, int n) {
    if (n <= 1) return 0;
    
    l_fixed avg = l_mean(data, n);
    l_fixed sum_sq = 0;
    
    for (int i = 0; i < n; i++) {
        l_fixed diff = data[i] - avg;
        sum_sq += l_fsqr(diff);
    }
    
    return sum_sq / (n - 1);
}

// 标准差
static l_fixed l_stddev(const l_fixed *data, int n) {
    return l_fsqrt(l_variance(data, n));
}

// 中位数
static l_fixed l_median(l_fixed *data, int n) {
    if (n <= 0) return 0;
    
    // 简单排序（冒泡）
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (data[j] > data[j + 1]) {
                l_fixed temp = data[j];
                data[j] = data[j + 1];
                data[j + 1] = temp;
            }
        }
    }
    
    if (n % 2 == 0) {
        return (data[n/2 - 1] + data[n/2]) >> 1;
    } else {
        return data[n/2];
    }
}

// 相关系数
static l_fixed l_correlation(const l_fixed *x, const l_fixed *y, int n) {
    if (n <= 1) return 0;
    
    l_fixed mean_x = l_mean(x, n);
    l_fixed mean_y = l_mean(y, n);
    l_fixed sum_xy = 0, sum_x2 = 0, sum_y2 = 0;
    
    for (int i = 0; i < n; i++) {
        l_fixed dx = x[i] - mean_x;
        l_fixed dy = y[i] - mean_y;
        sum_xy += (dx * dy) >> L_FIXED_SHIFT;
        sum_x2 += l_fsqr(dx);
        sum_y2 += l_fsqr(dy);
    }
    
    if (sum_x2 == 0 || sum_y2 == 0) return 0;
    
    l_fixed denom = l_fsqrt((sum_x2 * sum_y2) >> L_FIXED_SHIFT);
    if (denom == 0) return 0;
    
    return (sum_xy << L_FIXED_SHIFT) / denom;
}

// ==================== 调试和演示函数 ====================

static void l_math_demo(void) {
    l_puts("\n=== LAOLIPEF 数学库演示 ===");
    
    // 测试定点数
    l_fixed fx1 = l_int_to_fixed(3);
    l_fixed fx2 = l_int_to_fixed(2);
    l_fixed result = (fx1 * fx2) >> L_FIXED_SHIFT;
    
    l_printf("定点数测试: 3 * 2 = %d\n", l_fixed_to_int(result));
    
    // 测试平方根
    l_fixed num = l_int_to_fixed(25);
    l_fixed sqrt_val = l_fsqrt(num);
    l_printf("√25 = %d (实际: %d)\n", 5, l_fixed_to_int(sqrt_val));
    
    // 测试随机数
    l_srand(l_time());
    l_printf("随机数[1,100]: %d\n", l_rand_range(1, 100));
    
    // 测试几何距离
    l_fixed dist = l_distance(l_int_to_fixed(0), l_int_to_fixed(0), 
                            l_int_to_fixed(3), l_int_to_fixed(4));
    l_printf("点(0,0)到(3,4)距离 = 5 (实际: %d.%02d)\n", 
             l_fixed_to_int(dist),
             ((dist & 0xFFFF) * 100) >> 16);
    
    // 测试阶乘
    l_printf("5! = %ld\n", l_factorial(5));
    
    // 测试素数
    l_printf("17是素数吗? %s\n", l_is_prime(17) ? "是" : "否");
    l_printf("15是素数吗? %s\n", l_is_prime(15) ? "是" : "否");
    
    // 测试斐波那契
    l_printf("斐波那契(10) = %ld\n", l_fibonacci(10));
    
    // 测试贝塞尔曲线
    l_fixed p0 = l_int_to_fixed(0);
    l_fixed p1 = l_int_to_fixed(5);
    l_fixed p2 = l_int_to_fixed(10);
    l_fixed bezier = l_bezier_quad(p0, p1, p2, L_FIXED_HALF);
    l_printf("贝塞尔曲线中点: %d\n", l_fixed_to_int(bezier));
    
    l_puts("数学库演示完成");
}

// 性能测试函数
static void l_math_benchmark(void) {
    l_puts("\n=== 数学库性能测试 ===");
    
    long start_time = l_time();
    int iterations = 100000;
    
    // 测试平方根性能
    l_fixed sum = 0;
    for (int i = 1; i <= iterations; i++) {
        sum += l_fsqrt(l_int_to_fixed(i));
    }
    
    long end_time = l_time();
    l_printf("计算 %d 次平方根耗时: %ld 毫秒\n", 
             iterations, (end_time - start_time) * 1000);
    
    l_printf("结果校验: %d.%04d\n", 
             l_fixed_to_int(sum / iterations),
             (((sum / iterations) & 0xFFFF) * 10000) >> 16);
}

#endif // L_MATH_H
