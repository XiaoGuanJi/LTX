#ifndef L_DESKTOP_H
#define L_DESKTOP_H

#include "lstdios.h"
#include "lmath.h"
#include "lnull.h"
#include "ltime.h"
#include "l3d.h"
#include "lnet.h"
#include "lgravity.h"

// 桌面环境模拟器
// 用单个程序模拟完整的桌面体验

/*------------------------------------------------------------------
 * 第一部分：基本类型和常量
 *------------------------------------------------------------------*/

// 使用lstdios.h中定义的颜色，避免重复定义
#define L_DESKTOP_COLOR_BLUE       L_COLOR_BLUE
#define L_DESKTOP_COLOR_GREEN      L_COLOR_GREEN
#define L_DESKTOP_COLOR_CYAN       L_COLOR_CYAN
#define L_DESKTOP_COLOR_RED        L_COLOR_RED
#define L_DESKTOP_COLOR_MAGENTA    L_COLOR_MAGENTA
#define L_DESKTOP_COLOR_YELLOW     L_COLOR_YELLOW
#define L_DESKTOP_COLOR_WHITE      L_COLOR_WHITE
#define L_DESKTOP_COLOR_BLACK      L_COLOR_BLACK
#define L_DESKTOP_COLOR_GRAY       8  // 灰色

// 桌面配置
#define L_DESKTOP_WIDTH    80
#define L_DESKTOP_HEIGHT   30
#define L_MAX_WINDOWS      10
#define L_MAX_ICONS        20
#define L_MAX_TASKS        10

// 窗口状态
typedef enum {
    L_WINDOW_NORMAL = 0,
    L_WINDOW_MINIMIZED = 1,
    L_WINDOW_MAXIMIZED = 2,
    L_WINDOW_CLOSED = 3
} L_WindowState;

// 图标类型
typedef enum {
    L_ICON_FILE = 0,
    L_ICON_FOLDER = 1,
    L_ICON_APP = 2,
    L_ICON_SETTINGS = 3,
    L_ICON_TRASH = 4
} L_IconType;

// 鼠标状态
typedef struct {
    int x, y;
    int left_pressed;
    int right_pressed;
    int middle_pressed;
} L_MouseState;

// 键盘状态
typedef struct {
    int key;
    int pressed;
    int special;  // 特殊键
} L_KeyState;

/*------------------------------------------------------------------
 * 第二部分：桌面元素
 *------------------------------------------------------------------*/

// 窗口结构
typedef struct L_Window {
    int id;
    char title[32];
    int x, y;
    int width, height;
    L_WindowState state;
    int is_active;
    int is_moving;
    int can_resize;
    int can_close;
    int can_minimize;
    int can_maximize;
    
    // 窗口内容
    char **content;
    int content_lines;
    
    // 回调函数
    void (*on_draw)(struct L_Window *win);
    void (*on_update)(struct L_Window *win, float delta);
    void (*on_close)(struct L_Window *win);
    
    // 用户数据
    void *user_data;
    
    struct L_Window *next;
} L_Window;

// 图标结构
typedef struct {
    int id;
    char name[32];
    L_IconType type;
    int x, y;
    int selected;
    void (*on_click)(void);
} L_Icon;

// 任务栏项目
typedef struct {
    int id;
    char name[16];
    L_Window *window;
    int is_minimized;
} L_TaskItem;

/*------------------------------------------------------------------
 * 第三部分：桌面管理器
 *------------------------------------------------------------------*/

// 桌面管理器
typedef struct {
    // 显示区域
    char screen[L_DESKTOP_HEIGHT][L_DESKTOP_WIDTH];
    int colors[L_DESKTOP_HEIGHT][L_DESKTOP_WIDTH];
    
    // 桌面元素
    L_Window *windows;
    L_Window *active_window;
    int window_count;
    
    L_Icon icons[L_MAX_ICONS];
    int icon_count;
    
    L_TaskItem tasks[L_MAX_TASKS];
    int task_count;
    
    // 输入状态
    L_MouseState mouse;
    L_KeyState keyboard;
    
    // 桌面状态
    int running;
    int show_taskbar;
    int show_icons;
    char wallpaper[64];
    
    // 性能统计
    long frame_count;
    long start_time;
    float fps;
} L_Desktop;

/*------------------------------------------------------------------
 * 第四部分：基本函数
 *------------------------------------------------------------------*/

// 手动格式化字符串函数
static inline void l_strformat(char *buffer, int size, const char *format, ...) {
    if (!buffer || size <= 0 || !format) {
        if (size > 0) buffer[0] = '\0';
        return;
    }
    
    // 简化的格式化处理
    int i = 0;
    int buf_pos = 0;
    
    while (format[i] && buf_pos < size - 1) {
        if (format[i] == '%') {
            i++;
            if (format[i] == 's') {
                // 字符串
                const char *str = "(string)";
                while (*str && buf_pos < size - 1) {
                    buffer[buf_pos++] = *str++;
                }
            } else if (format[i] == 'd') {
                // 整数
                int num = 0;
                char num_str[20];
                int num_pos = 0;
                
                if (num == 0) {
                    num_str[num_pos++] = '0';
                } else {
                    char temp[20];
                    int len = 0;
                    int n = num;
                    while (n > 0) {
                        temp[len++] = '0' + (n % 10);
                        n /= 10;
                    }
                    for (int j = len - 1; j >= 0; j--) {
                        num_str[num_pos++] = temp[j];
                    }
                }
                num_str[num_pos] = '\0';
                
                for (int j = 0; num_str[j] && buf_pos < size - 1; j++) {
                    buffer[buf_pos++] = num_str[j];
                }
            } else if (format[i] == 'f') {
                // 浮点数
                float fnum = 0.0f;
                char fstr[32];
                l_float_to_str(fnum, fstr, sizeof(fstr));
                
                for (int j = 0; fstr[j] && buf_pos < size - 1; j++) {
                    buffer[buf_pos++] = fstr[j];
                }
            } else if (format[i] == 'l' && format[i+1] == 'd') {
                // 长整数
                i++;
                long lnum = 0;
                char lstr[20];
                int lpos = 0;
                
                if (lnum == 0) {
                    lstr[lpos++] = '0';
                } else {
                    char temp[20];
                    int len = 0;
                    long n = lnum;
                    while (n > 0) {
                        temp[len++] = '0' + (n % 10);
                        n /= 10;
                    }
                    for (int j = len - 1; j >= 0; j--) {
                        lstr[lpos++] = temp[j];
                    }
                }
                lstr[lpos] = '\0';
                
                for (int j = 0; lstr[j] && buf_pos < size - 1; j++) {
                    buffer[buf_pos++] = lstr[j];
                }
            } else if (format[i] == 'c') {
                // 字符
                if (buf_pos < size - 1) {
                    buffer[buf_pos++] = '?';
                }
            } else {
                // 未知格式，直接复制
                if (buf_pos < size - 1) {
                    buffer[buf_pos++] = format[i];
                }
            }
        } else {
            buffer[buf_pos++] = format[i];
        }
        i++;
    }
    
    buffer[buf_pos] = '\0';
}

// 浮点数转字符串（从lgravity.h复制）
static inline void l_float_to_str_simple(float value, char *buffer, int buffer_size) {
    if (!buffer || buffer_size <= 0) return;
    
    int i = 0;
    
    if (value < 0) {
        buffer[i++] = '-';
        value = -value;
    }
    
    int int_part = (int)value;
    float frac_part = value - int_part;
    
    char int_str[20];
    int int_len = 0;
    
    if (int_part == 0) {
        int_str[int_len++] = '0';
    } else {
        while (int_part > 0 && int_len < 19) {
            int_str[int_len++] = '0' + (int_part % 10);
            int_part /= 10;
        }
        
        for (int j = 0; j < int_len / 2; j++) {
            char temp = int_str[j];
            int_str[j] = int_str[int_len - 1 - j];
            int_str[int_len - 1 - j] = temp;
        }
    }
    
    for (int j = 0; j < int_len && i < buffer_size - 1; j++) {
        buffer[i++] = int_str[j];
    }
    
    if (i < buffer_size - 1) {
        buffer[i++] = '.';
    }
    
    if (i < buffer_size - 1) {
        int frac1 = (int)(frac_part * 10) % 10;
        int frac2 = (int)(frac_part * 100) % 10;
        
        buffer[i++] = '0' + (frac1 >= 0 ? frac1 : 0);
        if (i < buffer_size - 1) {
            buffer[i++] = '0' + (frac2 >= 0 ? frac2 : 0);
        }
    }
    
    buffer[i] = '\0';
}

// 创建桌面
static inline L_Desktop* l_desktop_create() {
    L_Desktop *desktop = (L_Desktop*)l_malloc(sizeof(L_Desktop));
    if (!desktop) return 0;
    
    for (int y = 0; y < L_DESKTOP_HEIGHT; y++) {
        for (int x = 0; x < L_DESKTOP_WIDTH; x++) {
            desktop->screen[y][x] = ' ';
            desktop->colors[y][x] = L_DESKTOP_COLOR_BLACK;
        }
    }
    
    desktop->windows = 0;
    desktop->active_window = 0;
    desktop->window_count = 0;
    desktop->icon_count = 0;
    desktop->task_count = 0;
    
    desktop->mouse.x = 0;
    desktop->mouse.y = 0;
    desktop->mouse.left_pressed = 0;
    desktop->mouse.right_pressed = 0;
    desktop->mouse.middle_pressed = 0;
    
    desktop->keyboard.key = 0;
    desktop->keyboard.pressed = 0;
    desktop->keyboard.special = 0;
    
    desktop->running = 1;
    desktop->show_taskbar = 1;
    desktop->show_icons = 1;
    l_strcpy(desktop->wallpaper, "default");
    
    desktop->frame_count = 0;
    desktop->start_time = l_get_timestamp();
    desktop->fps = 0.0f;
    
    return desktop;
}

// 销毁桌面
static inline void l_desktop_destroy(L_Desktop *desktop) {
    if (!desktop) return;
    
    L_Window *win = desktop->windows;
    while (win) {
        L_Window *next = win->next;
        if (win->content) {
            for (int i = 0; i < win->content_lines; i++) {
                l_free(win->content[i]);
            }
            l_free(win->content);
        }
        l_free(win);
        win = next;
    }
    
    l_free(desktop);
}

// 清空屏幕
static inline void l_desktop_clear(L_Desktop *desktop, char ch, int color) {
    if (!desktop) return;
    
    for (int y = 0; y < L_DESKTOP_HEIGHT; y++) {
        for (int x = 0; x < L_DESKTOP_WIDTH; x++) {
            desktop->screen[y][x] = ch;
            desktop->colors[y][x] = color;
        }
    }
}

// 绘制字符
static inline void l_desktop_draw_char(L_Desktop *desktop, int x, int y, char ch, int color) {
    if (!desktop) return;
    if (x < 0 || x >= L_DESKTOP_WIDTH || y < 0 || y >= L_DESKTOP_HEIGHT) return;
    
    desktop->screen[y][x] = ch;
    desktop->colors[y][x] = color;
}

// 绘制字符串
static inline void l_desktop_draw_text(L_Desktop *desktop, int x, int y, const char *text, int color) {
    if (!desktop || !text) return;
    
    int pos = x;
    for (int i = 0; text[i] && pos < L_DESKTOP_WIDTH; i++) {
        l_desktop_draw_char(desktop, pos, y, text[i], color);
        pos++;
    }
}

// 绘制矩形
static inline void l_desktop_draw_rect(L_Desktop *desktop, int x, int y, int w, int h, 
                                       char border, int border_color, char fill, int fill_color) {
    if (!desktop) return;
    
    for (int dy = y; dy < y + h && dy < L_DESKTOP_HEIGHT; dy++) {
        for (int dx = x; dx < x + w && dx < L_DESKTOP_WIDTH; dx++) {
            if (dx >= 0 && dy >= 0) {
                desktop->screen[dy][dx] = fill;
                desktop->colors[dy][dx] = fill_color;
            }
        }
    }
    
    for (int dx = x; dx < x + w && dx < L_DESKTOP_WIDTH; dx++) {
        if (dx >= 0 && y >= 0) {
            desktop->screen[y][dx] = border;
            desktop->colors[y][dx] = border_color;
        }
        if (dx >= 0 && y + h - 1 >= 0 && y + h - 1 < L_DESKTOP_HEIGHT) {
            desktop->screen[y + h - 1][dx] = border;
            desktop->colors[y + h - 1][dx] = border_color;
        }
    }
    
    for (int dy = y; dy < y + h && dy < L_DESKTOP_HEIGHT; dy++) {
        if (dy >= 0 && x >= 0) {
            desktop->screen[dy][x] = border;
            desktop->colors[dy][x] = border_color;
        }
        if (dy >= 0 && x + w - 1 >= 0 && x + w - 1 < L_DESKTOP_WIDTH) {
            desktop->screen[dy][x + w - 1] = border;
            desktop->colors[dy][x + w - 1] = border_color;
        }
    }
}

// 渲染桌面
static inline void l_desktop_render(L_Desktop *desktop) {
    if (!desktop) return;
    
    l_puts("\033[2J\033[H");
    
    for (int y = 0; y < L_DESKTOP_HEIGHT; y++) {
        for (int x = 0; x < L_DESKTOP_WIDTH; x++) {
            int color = desktop->colors[y][x];
            if (color != L_DESKTOP_COLOR_BLACK) {
                l_printf("\033[3%dm", color);
            }
            
            l_putchar(desktop->screen[y][x]);
            
            if (color != L_DESKTOP_COLOR_BLACK) {
                l_puts("\033[0m");
            }
        }
        l_putchar('\n');
    }
}

/*------------------------------------------------------------------
 * 第五部分：窗口管理
 *------------------------------------------------------------------*/

// 创建窗口
static inline L_Window* l_window_create(L_Desktop *desktop, const char *title, 
                                        int x, int y, int width, int height) {
    if (!desktop || !title) return 0;
    
    L_Window *win = (L_Window*)l_malloc(sizeof(L_Window));
    if (!win) return 0;
    
    win->id = desktop->window_count;
    l_strncpy(win->title, title, 31);
    win->x = x;
    win->y = y;
    win->width = width;
    win->height = height;
    win->state = L_WINDOW_NORMAL;
    win->is_active = 0;
    win->is_moving = 0;
    win->can_resize = 1;
    win->can_close = 1;
    win->can_minimize = 1;
    win->can_maximize = 1;
    
    win->content = 0;
    win->content_lines = 0;
    
    win->on_draw = 0;
    win->on_update = 0;
    win->on_close = 0;
    win->user_data = 0;
    
    win->next = desktop->windows;
    desktop->windows = win;
    desktop->window_count++;
    
    desktop->active_window = win;
    win->is_active = 1;
    
    return win;
}

// 绘制窗口
static inline void l_window_draw(L_Desktop *desktop, L_Window *win) {
    if (!desktop || !win || win->state == L_WINDOW_MINIMIZED) return;
    
    l_desktop_draw_rect(desktop, win->x, win->y, win->width, win->height, 
                       '#', win->is_active ? L_DESKTOP_COLOR_CYAN : L_DESKTOP_COLOR_GRAY,
                       ' ', L_DESKTOP_COLOR_BLACK);
    
    char title_bar[34];
    l_strformat(title_bar, sizeof(title_bar), " %s ", win->title);
    l_desktop_draw_text(desktop, win->x + 2, win->y, title_bar, 
                       win->is_active ? L_DESKTOP_COLOR_CYAN : L_DESKTOP_COLOR_WHITE);
    
    if (win->can_close) {
        l_desktop_draw_char(desktop, win->x + win->width - 3, win->y, 'X', L_DESKTOP_COLOR_RED);
    }
    if (win->can_minimize) {
        l_desktop_draw_char(desktop, win->x + win->width - 5, win->y, '_', L_DESKTOP_COLOR_YELLOW);
    }
    if (win->can_maximize) {
        l_desktop_draw_char(desktop, win->x + win->width - 7, win->y, 'M', L_DESKTOP_COLOR_GREEN);
    }
    
    if (win->on_draw) {
        win->on_draw(win);
    }
}

// 关闭窗口
static inline void l_window_close(L_Desktop *desktop, L_Window *win) {
    if (!desktop || !win) return;
    
    if (win->on_close) {
        win->on_close(win);
    }
    
    L_Window *prev = 0;
    L_Window *current = desktop->windows;
    
    while (current) {
        if (current == win) {
            if (prev) {
                prev->next = current->next;
            } else {
                desktop->windows = current->next;
            }
            
            if (current->content) {
                for (int i = 0; i < current->content_lines; i++) {
                    l_free(current->content[i]);
                }
                l_free(current->content);
            }
            
            l_free(current);
            desktop->window_count--;
            
            if (desktop->active_window == win) {
                desktop->active_window = desktop->windows;
                if (desktop->active_window) {
                    desktop->active_window->is_active = 1;
                }
            }
            
            break;
        }
        prev = current;
        current = current->next;
    }
}

/*------------------------------------------------------------------
 * 第六部分：图标管理
 *------------------------------------------------------------------*/

// 创建图标
static inline L_Icon* l_icon_create(L_Desktop *desktop, const char *name, 
                                    L_IconType type, int x, int y) {
    if (!desktop || !name || desktop->icon_count >= L_MAX_ICONS) return 0;
    
    L_Icon *icon = &desktop->icons[desktop->icon_count];
    icon->id = desktop->icon_count;
    l_strncpy(icon->name, name, 31);
    icon->type = type;
    icon->x = x;
    icon->y = y;
    icon->selected = 0;
    icon->on_click = 0;
    
    desktop->icon_count++;
    return icon;
}

// 绘制图标
static inline void l_icon_draw(L_Desktop *desktop, L_Icon *icon) {
    if (!desktop || !icon) return;
    
    char icon_char = '?';
    switch (icon->type) {
        case L_ICON_FILE: icon_char = 'F'; break;
        case L_ICON_FOLDER: icon_char = 'D'; break;
        case L_ICON_APP: icon_char = 'A'; break;
        case L_ICON_SETTINGS: icon_char = 'S'; break;
        case L_ICON_TRASH: icon_char = 'T'; break;
    }
    
    l_desktop_draw_char(desktop, icon->x, icon->y, '[', 
                       icon->selected ? L_DESKTOP_COLOR_CYAN : L_DESKTOP_COLOR_WHITE);
    l_desktop_draw_char(desktop, icon->x + 1, icon->y, icon_char, 
                       icon->selected ? L_DESKTOP_COLOR_CYAN : L_DESKTOP_COLOR_YELLOW);
    l_desktop_draw_char(desktop, icon->x + 2, icon->y, ']', 
                       icon->selected ? L_DESKTOP_COLOR_CYAN : L_DESKTOP_COLOR_WHITE);
    
    l_desktop_draw_text(desktop, icon->x, icon->y + 1, icon->name, 
                       icon->selected ? L_DESKTOP_COLOR_CYAN : L_DESKTOP_COLOR_WHITE);
}

/*------------------------------------------------------------------
 * 第七部分：任务栏
 *------------------------------------------------------------------*/

// 绘制任务栏
static inline void l_desktop_draw_taskbar(L_Desktop *desktop) {
    if (!desktop || !desktop->show_taskbar) return;
    
    int taskbar_y = L_DESKTOP_HEIGHT - 3;
    
    l_desktop_draw_rect(desktop, 0, taskbar_y, L_DESKTOP_WIDTH, 3, 
                       '-', L_DESKTOP_COLOR_GRAY, ' ', L_DESKTOP_COLOR_BLACK);
    
    l_desktop_draw_text(desktop, 2, taskbar_y + 1, "START", L_DESKTOP_COLOR_GREEN);
    
    long current_time = l_get_timestamp() - desktop->start_time;
    char time_str[20];
    l_strformat(time_str, sizeof(time_str), "Time: %ld", current_time);
    l_desktop_draw_text(desktop, L_DESKTOP_WIDTH - 15, taskbar_y + 1, time_str, L_DESKTOP_COLOR_WHITE);
    
    char fps_str[20];
    l_float_to_str_simple(desktop->fps, fps_str, sizeof(fps_str));
    char fps_full[30];
    l_strformat(fps_full, sizeof(fps_full), "FPS: %s", fps_str);
    l_desktop_draw_text(desktop, L_DESKTOP_WIDTH - 30, taskbar_y + 1, fps_full, L_DESKTOP_COLOR_WHITE);
    
    int x_pos = 10;
    L_Window *win = desktop->windows;
    while (win && x_pos < L_DESKTOP_WIDTH - 40) {
        char win_btn[20];
        l_strformat(win_btn, sizeof(win_btn), "[%s]", win->title);
        
        int color = win->is_active ? L_DESKTOP_COLOR_CYAN : L_DESKTOP_COLOR_WHITE;
        if (win->state == L_WINDOW_MINIMIZED) {
            color = L_DESKTOP_COLOR_GRAY;
        }
        
        l_desktop_draw_text(desktop, x_pos, taskbar_y + 1, win_btn, color);
        x_pos += l_strlen(win_btn) + 2;
        win = win->next;
    }
}

/*------------------------------------------------------------------
 * 第八部分：输入处理
 *------------------------------------------------------------------*/

// 处理鼠标输入
static inline void l_desktop_handle_mouse(L_Desktop *desktop) {
    if (!desktop) return;
    
    static int mouse_dir = 1;
    desktop->mouse.x += mouse_dir;
    if (desktop->mouse.x <= 0 || desktop->mouse.x >= L_DESKTOP_WIDTH - 1) {
        mouse_dir = -mouse_dir;
    }
    
    l_desktop_draw_char(desktop, desktop->mouse.x, desktop->mouse.y, '@', L_DESKTOP_COLOR_WHITE);
}

// 桌面核心循环
static inline void l_desktop_update(L_Desktop *desktop, float delta_time) {
    if (!desktop) return;
    
    desktop->frame_count++;
    if (desktop->frame_count % 60 == 0) {
        long current_time = l_get_timestamp();
        float elapsed = (float)(current_time - desktop->start_time);
        if (elapsed > 0) {
            desktop->fps = desktop->frame_count / elapsed;
        }
    }
    
    l_desktop_handle_mouse(desktop);
    
    L_Window *win = desktop->windows;
    while (win) {
        if (win->on_update) {
            win->on_update(win, delta_time);
        }
        win = win->next;
    }
}

// 绘制桌面
static inline void l_desktop_draw(L_Desktop *desktop) {
    if (!desktop) return;
    
    l_desktop_clear(desktop, '.', L_DESKTOP_COLOR_BLACK);
    
    l_desktop_draw_text(desktop, 2, 2, "LAOLIPEF Desktop v1.0", L_DESKTOP_COLOR_CYAN);
    l_desktop_draw_text(desktop, 2, 3, "A complete desktop in a single program", L_DESKTOP_COLOR_WHITE);
    
    if (desktop->show_icons) {
        for (int i = 0; i < desktop->icon_count; i++) {
            l_icon_draw(desktop, &desktop->icons[i]);
        }
    }
    
    L_Window *win = desktop->windows;
    while (win) {
        l_window_draw(desktop, win);
        win = win->next;
    }
    
    l_desktop_draw_taskbar(desktop);
}

// 桌面主循环
static inline void l_desktop_run(L_Desktop *desktop) {
    if (!desktop) return;
    
    l_puts("LAOLIPEF Desktop starting...");
    l_puts("Press Ctrl+C to exit");
    l_puts("");
    
    long last_time = l_get_timestamp();
    
    while (desktop->running) {
        long current_time = l_get_timestamp();
        float delta_time = (current_time - last_time) / 1000.0f;
        last_time = current_time;
        
        if (delta_time > 0.1f) delta_time = 0.1f;
        
        l_desktop_update(desktop, delta_time);
        l_desktop_draw(desktop);
        l_desktop_render(desktop);
        
        for (int i = 0; i < 1000000; i++) {
            __asm__ volatile("nop");
        }
    }
}

/*------------------------------------------------------------------
 * 第九部分：应用程序示例
 *------------------------------------------------------------------*/

// 文本编辑器窗口回调
static void l_text_editor_draw(L_Window *win) {
    if (!win) return;
    
    L_Desktop *desktop = (L_Desktop*)win->user_data;
    if (!desktop) return;
    
    l_desktop_draw_text(desktop, win->x + 2, win->y + 2, "Text Editor", L_DESKTOP_COLOR_WHITE);
    l_desktop_draw_text(desktop, win->x + 2, win->y + 4, "Line 1: Hello World!", L_DESKTOP_COLOR_GREEN);
    l_desktop_draw_text(desktop, win->x + 2, win->y + 5, "Line 2: Type here...", L_DESKTOP_COLOR_GREEN);
    l_desktop_draw_text(desktop, win->x + 2, win->y + 7, "Status: Ready", L_DESKTOP_COLOR_YELLOW);
}

static void l_text_editor_update(L_Window *win, float delta) {
    // 空实现
}

// 计算器窗口回调
static void l_calculator_draw(L_Window *win) {
    if (!win) return;
    
    L_Desktop *desktop = (L_Desktop*)win->user_data;
    if (!desktop) return;
    
    l_desktop_draw_text(desktop, win->x + 2, win->y + 2, "Calculator", L_DESKTOP_COLOR_WHITE);
    l_desktop_draw_rect(desktop, win->x + 2, win->y + 4, 20, 3, '#', L_DESKTOP_COLOR_GRAY, ' ', L_DESKTOP_COLOR_BLACK);
    l_desktop_draw_text(desktop, win->x + 4, win->y + 5, "0", L_DESKTOP_COLOR_WHITE);
    
    l_desktop_draw_text(desktop, win->x + 2, win->y + 8, "[7][8][9][+]", L_DESKTOP_COLOR_CYAN);
    l_desktop_draw_text(desktop, win->x + 2, win->y + 9, "[4][5][6][-]", L_DESKTOP_COLOR_CYAN);
    l_desktop_draw_text(desktop, win->x + 2, win->y + 10, "[1][2][3][*]", L_DESKTOP_COLOR_CYAN);
    l_desktop_draw_text(desktop, win->x + 2, win->y + 11, "[0][.][=][/]", L_DESKTOP_COLOR_CYAN);
}

// 系统信息窗口回调
static void l_system_info_draw(L_Window *win) {
    if (!win) return;
    
    L_Desktop *desktop = (L_Desktop*)win->user_data;
    if (!desktop) return;
    
    l_desktop_draw_text(desktop, win->x + 2, win->y + 2, "System Information", L_DESKTOP_COLOR_WHITE);
    
    char info[64];
    l_strformat(info, sizeof(info), "Windows: %d", desktop->window_count);
    l_desktop_draw_text(desktop, win->x + 2, win->y + 4, info, L_DESKTOP_COLOR_GREEN);
    
    l_strformat(info, sizeof(info), "Icons: %d", desktop->icon_count);
    l_desktop_draw_text(desktop, win->x + 2, win->y + 5, info, L_DESKTOP_COLOR_GREEN);
    
    char fps_str[20];
    l_float_to_str_simple(desktop->fps, fps_str, sizeof(fps_str));
    l_strformat(info, sizeof(info), "FPS: %s", fps_str);
    l_desktop_draw_text(desktop, win->x + 2, win->y + 6, info, L_DESKTOP_COLOR_GREEN);
    
    long uptime = l_get_timestamp() - desktop->start_time;
    l_strformat(info, sizeof(info), "Uptime: %lds", uptime);
    l_desktop_draw_text(desktop, win->x + 2, win->y + 7, info, L_DESKTOP_COLOR_GREEN);
}

// 演示函数
static inline void l_desktop_demo() {
    l_puts("=== LAOLIPEF Desktop Demo ===");
    
    L_Desktop *desktop = l_desktop_create();
    if (!desktop) {
        l_puts("Failed to create desktop");
        return;
    }
    
    l_icon_create(desktop, "My Documents", L_ICON_FOLDER, 5, 5);
    l_icon_create(desktop, "Text Editor", L_ICON_APP, 5, 10);
    l_icon_create(desktop, "Calculator", L_ICON_APP, 5, 15);
    l_icon_create(desktop, "Settings", L_ICON_SETTINGS, 5, 20);
    l_icon_create(desktop, "Trash", L_ICON_TRASH, 5, 25);
    
    L_Window *editor = l_window_create(desktop, "Text Editor", 20, 5, 40, 15);
    if (editor) {
        editor->user_data = desktop;
        editor->on_draw = l_text_editor_draw;
        editor->on_update = l_text_editor_update;
    }
    
    L_Window *calc = l_window_create(desktop, "Calculator", 25, 10, 30, 15);
    if (calc) {
        calc->user_data = desktop;
        calc->on_draw = l_calculator_draw;
    }
    
    L_Window *sysinfo = l_window_create(desktop, "System Info", 10, 8, 35, 12);
    if (sysinfo) {
        sysinfo->user_data = desktop;
        sysinfo->on_draw = l_system_info_draw;
    }
    
    l_puts("Desktop created with:");
    l_puts("  - 3 application windows");
    l_puts("  - 5 desktop icons");
    l_puts("  - Taskbar with system info");
    l_puts("");
    l_puts("Starting desktop loop...");
    l_puts("");
    
    l_desktop_run(desktop);
    
    l_desktop_destroy(desktop);
    l_puts("\nDesktop closed");
}

// 桌面系统信息
static inline void l_desktop_system_info() {
    l_puts("\n=== LAOLIPEF Desktop System ===");
    l_puts("Version: 1.0.0");
    l_puts("Type: User-space Desktop Simulator");
    l_puts("Resolution: 80x30 characters");
    l_puts("");
    l_puts("Features:");
    l_puts("  ✓ Window management");
    l_puts("  ✓ Desktop icons");
    l_puts("  ✓ Taskbar with clock");
    l_puts("  ✓ Mouse cursor simulation");
    l_puts("  ✓ Multiple application support");
    l_puts("  ✓ FPS counter and performance stats");
    l_puts("");
    l_puts("Built on LAOLIPEF Framework:");
    l_puts("  ✓ lstdios.h - System and I/O");
    l_puts("  ✓ lmath.h   - Mathematics");
    l_puts("  ✓ lnull.h   - Safety");
    l_puts("  ✓ ltime.h   - Timing");
    l_puts("  ✓ l3d.h     - Graphics");
    l_puts("  ✓ lnet.h    - Networking");
    l_puts("  ✓ lgravity.h- Physics");
    l_puts("");
    l_puts("A complete desktop in a single C program!");
}

#endif /* L_DESKTOP_H */
