// main_desktop.c
#include "ldesktop.h"

int main() {
    l_puts("========================================");
    l_puts("   LAOLIPEF 桌面环境模拟器");
    l_puts("========================================\n");
    
    l_desktop_demo();
    l_desktop_system_info();
    
    l_puts("\n========================================");
    l_puts("   演示完成 - 桌面环境正常");
    l_puts("========================================");
    
    return 0;
}
