gcc -c ldesktop.h
gcc -c main.c
g++ main.o -o main
chmod 755 main.sh
chmod 755 main
./main
