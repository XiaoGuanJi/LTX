/**
 * Copyright [2023] [LAOLIPEF]
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */



#include <iostream>
using namespace std;

void showMenu() {
    cout << "请选择操作：" << endl;
    cout << "1. 加法" << endl;
    cout << "2. 减法" << endl;
    cout << "3. 乘法" << endl;
    cout << "4. 除法" << endl;
    cout << "5. 退出" << endl;
}

int main() {
    int choice;
    double num1, num2, result;

    while (true) {
        showMenu();
        cin >> choice;

        if (choice == 5) {
            cout << "退出程序。" << endl;
            break;
        }

        cout << "输入第一个数字: ";
        cin >> num1;
        cout << "输入第二个数字: ";
        cin >> num2;

        switch (choice) {
            case 1:
                result = num1 + num2;
                cout << "结果: " << result << endl;
                break;
            case 2:
                result = num1 - num2;
                cout << "结果: " << result << endl;
                break;
            case 3:
                result = num1 * num2;
                cout << "结果: " << result << endl;
                break;
            case 4:
                if (num2 != 0) {
                    result = num1 / num2;
                    cout << "结果: " << result << endl;
                } else {
                    cout << "错误: 除数不能为零。" << endl;
                }
                break;
            default:
                cout << "无效的选择，请重新输入。" << endl;
        }
    }

    return 0;
}
