/**
 * Copyright [2023] [LAOLIPEF]
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>

// 常量定义
#define MAX_EXPR_LEN 256      // 表达式最大长度
#define MAX_STACK_SIZE 100    // 栈的最大大小
#define PI 3.14159265358979323846

// 运算符优先级定义
typedef enum {
    PREC_NONE = 0,
    PREC_LOWEST = 1,
    PREC_SUM = 2,      // +, -
    PREC_PRODUCT = 3,  // *, /
    PREC_POWER = 4,    // ^
    PREC_UNARY = 5,    // 一元运算符
    PREC_PAREN = 6     // 括号
} Precedence;

// 运算符结合性
typedef enum {
    ASSOC_LEFT,   // 左结合
    ASSOC_RIGHT   // 右结合
} Associativity;

// 运算符结构体
typedef struct {
    char symbol;          // 运算符符号
    Precedence prec;      // 优先级
    Associativity assoc;  // 结合性
} Operator;

// 栈数据结构
typedef struct {
    double data[MAX_STACK_SIZE];
    int top;
} Stack;

typedef struct {
    char data[MAX_STACK_SIZE];
    int top;
} CharStack;

// 函数声明
void initStack(Stack *s);
void initCharStack(CharStack *s);
int isStackEmpty(Stack *s);
int isCharStackEmpty(CharStack *s);
void push(Stack *s, double value);
void pushChar(CharStack *s, char value);
double pop(Stack *s);
char popChar(CharStack *s);
double peek(Stack *s);
char peekChar(CharStack *s);

double evaluateExpression(const char *expr);
double applyOperation(double a, double b, char op);
int isOperator(char c);
Precedence getPrecedence(char op);
Associativity getAssociativity(char op);
int isDigitOrPoint(char c);
int isFunction(const char *str, int *len);
double evaluateFunction(const char *func, double arg);
void infixToPostfix(const char *infix, char *postfix);
double evaluatePostfix(const char *postfix);
void displayMenu();
void simpleCalculator();
void advancedCalculator();

int main() {
    int choice;
    
    printf("=== 高级计算器 ===\n");
    
    do {
        printf("\n请选择计算器模式:\n");
        printf("1. 简易计算器（单步运算）\n");
        printf("2. 高级计算器（支持表达式和函数）\n");
        printf("3. 退出\n");
        printf("请输入你的选择 (1-3): ");
        
        if (scanf("%d", &choice) != 1) {
            printf("输入无效！\n");
        }
        
        switch (choice) {
            case 1:
                simpleCalculator();
                break;
            case 2:
                advancedCalculator();
                break;
            case 3:
                printf("感谢使用，再见！\n");
                break;
            default:
                printf("无效选择，请输入1-3之间的数字。\n");
        }
        
    } while (choice != 3);
    
    return 0;
}

// 栈操作函数
void initStack(Stack *s) { s->top = -1; }
void initCharStack(CharStack *s) { s->top = -1; }
int isStackEmpty(Stack *s) { return s->top == -1; }
int isCharStackEmpty(CharStack *s) { return s->top == -1; }

void push(Stack *s, double value) {
    if (s->top < MAX_STACK_SIZE - 1) {
        s->data[++(s->top)] = value;
    }
}

void pushChar(CharStack *s, char value) {
    if (s->top < MAX_STACK_SIZE - 1) {
        s->data[++(s->top)] = value;
    }
}

double pop(Stack *s) {
    if (!isStackEmpty(s)) {
        return s->data[(s->top)--];
    }
    return 0.0;
}

char popChar(CharStack *s) {
    if (!isCharStackEmpty(s)) {
        return s->data[(s->top)--];
    }
    return '\0';
}

double peek(Stack *s) {
    if (!isStackEmpty(s)) {
        return s->data[s->top];
    }
    return 0.0;
}

char peekChar(CharStack *s) {
    if (!isCharStackEmpty(s)) {
        return s->data[s->top];
    }
    return '\0';
}

/**
 * 检查字符是否为运算符
 * @param c 要检查的字符
 * @return 1如果是运算符，否则0
 */
int isOperator(char c) {
    return c == '+' || c == '-' || c == '*' || c == '/' || c == '^' || c == '%';
}

/**
 * 获取运算符优先级
 * @param op 运算符
 * @return 优先级值
 */
Precedence getPrecedence(char op) {
    switch (op) {
        case '+':
        case '-':
            return PREC_SUM;
        case '*':
        case '/':
        case '%':
            return PREC_PRODUCT;
        case '^':
            return PREC_POWER;
        default:
            return PREC_NONE;
    }
}

/**
 * 获取运算符结合性
 * @param op 运算符
 * @return 结合性
 */
Associativity getAssociativity(char op) {
    switch (op) {
        case '^':
            return ASSOC_RIGHT;  // 幂运算是右结合
        default:
            return ASSOC_LEFT;   // 其他运算是左结合
    }
}

/**
 * 检查字符是否为数字或小数点
 * @param c 要检查的字符
 * @return 1如果是数字或小数点，否则0
 */
int isDigitOrPoint(char c) {
    return (c >= '0' && c <= '9') || c == '.' || c == 'e' || c == 'E';
}

/**
 * 检查是否为函数名
 * @param str 要检查的字符串
 * @param len 返回函数名的长度
 * @return 1如果是函数，否则0
 */
int isFunction(const char *str, int *len) {
    const char *functions[] = {
        "sin", "cos", "tan", "asin", "acos", "atan",
        "sqrt", "log", "ln", "exp", "abs"
    };
    
    for (int i = 0; i < 11; i++) {
        int func_len = strlen(functions[i]);
        if (strncmp(str, functions[i], func_len) == 0) {
            *len = func_len;
            return 1;
        }
    }
    return 0;
}

/**
 * 计算函数值
 * @param func 函数名
 * @param arg 函数参数
 * @return 函数计算结果
 */
double evaluateFunction(const char *func, double arg) {
    if (strcmp(func, "sin") == 0) return sin(arg);
    if (strcmp(func, "cos") == 0) return cos(arg);
    if (strcmp(func, "tan") == 0) return tan(arg);
    if (strcmp(func, "asin") == 0) return asin(arg);
    if (strcmp(func, "acos") == 0) return acos(arg);
    if (strcmp(func, "atan") == 0) return atan(arg);
    if (strcmp(func, "sqrt") == 0) return sqrt(arg);
    if (strcmp(func, "log") == 0) return log10(arg);
    if (strcmp(func, "ln") == 0) return log(arg);
    if (strcmp(func, "exp") == 0) return exp(arg);
    if (strcmp(func, "abs") == 0) return fabs(arg);
    
    return 0.0;
}

/**
 * 应用二元运算
 * @param a 第一个操作数
 * @param b 第二个操作数
 * @param op 运算符
 * @return 运算结果
 */
double applyOperation(double a, double b, char op) {
    switch (op) {
        case '+': return a + b;
        case '-': return a - b;
        case '*': return a * b;
        case '/':
            if (b == 0) {
                printf("错误：除数不能为零！\n");
                exit(1);
            }
            return a / b;
        case '^': return pow(a, b);
        case '%': 
            if ((int)b == 0) {
                printf("错误：取模运算的第二个操作数不能为零！\n");
                exit(1);
            }
            return (int)a % (int)b;
        default: return 0;
    }
}

/**
 * 中缀表达式转后缀表达式（逆波兰表示法）
 * @param infix 中缀表达式
 * @param postfix 后缀表达式输出
 */
void infixToPostfix(const char *infix, char *postfix) {
    CharStack opStack;
    initCharStack(&opStack);
    
    int i = 0, j = 0;
    int len = strlen(infix);
    int isUnary = 1;  // 标记是否可能是一元运算符
    
    while (i < len) {
        char c = infix[i];
        
        // 跳过空格
        if (isspace(c)) {
            i++;
            continue;
        }
        
        // 处理数字
        if (isdigit(c) || c == '.') {
            while (i < len && (isdigit(infix[i]) || infix[i] == '.')) {
                postfix[j++] = infix[i++];
            }
            postfix[j++] = ' ';  // 数字后加空格分隔
            isUnary = 0;  // 数字后面不可能是一元运算符
            continue;
        }
        
        // 处理函数
        int func_len = 0;
        if (isalpha(c)) {
            if (isFunction(&infix[i], &func_len)) {
                // 将函数名和参数作为一个整体处理
                for (int k = 0; k < func_len; k++) {
                    postfix[j++] = infix[i++];
                }
                // 函数后面会接括号，暂时不处理参数
                isUnary = 0;
                continue;
            }
        }
        
        // 处理左括号
        if (c == '(') {
            pushChar(&opStack, c);
            isUnary = 1;  // 左括号后可能是一元运算符
            i++;
            continue;
        }
        
        // 处理右括号
        if (c == ')') {
            while (!isCharStackEmpty(&opStack) && peekChar(&opStack) != '(') {
                postfix[j++] = popChar(&opStack);
                postfix[j++] = ' ';
            }
            if (!isCharStackEmpty(&opStack) && peekChar(&opStack) == '(') {
                popChar(&opStack);
            }
            isUnary = 0;  // 右括号后不可能是一元运算符
            i++;
            continue;
        }
        
        // 处理运算符
        if (isOperator(c)) {
            // 处理一元运算符（负号）
            if (c == '-' && isUnary) {
                // 将一元负号转换为特殊符号 '~'
                pushChar(&opStack, '~');
            } else {
                // 处理二元运算符
                while (!isCharStackEmpty(&opStack) && 
                       peekChar(&opStack) != '(' &&
                       ((getPrecedence(peekChar(&opStack)) > getPrecedence(c)) ||
                        (getPrecedence(peekChar(&opStack)) == getPrecedence(c) && 
                         getAssociativity(c) == ASSOC_LEFT))) {
                    postfix[j++] = popChar(&opStack);
                    postfix[j++] = ' ';
                }
                pushChar(&opStack, c);
            }
            isUnary = 1;  // 运算符后可能是一元运算符
            i++;
            continue;
        }
        
        i++;
    }
    
    // 将栈中剩余运算符弹出
    while (!isCharStackEmpty(&opStack)) {
        char op = popChar(&opStack);
        if (op != '(') {
            postfix[j++] = op;
            postfix[j++] = ' ';
        }
    }
    
    postfix[j] = '\0';  // 字符串结尾
}

/**
 * 计算后缀表达式
 * @param postfix 后缀表达式
 * @return 计算结果
 */
double evaluatePostfix(const char *postfix) {
    Stack numStack;
    initStack(&numStack);
    
    int i = 0;
    int len = strlen(postfix);
    
    while (i < len) {
        // 跳过空格
        if (isspace(postfix[i])) {
            i++;
            continue;
        }
        
        // 处理数字
        if (isdigit(postfix[i]) || postfix[i] == '.') {
            char numStr[50];
            int j = 0;
            while (i < len && (isdigit(postfix[i]) || postfix[i] == '.')) {
                numStr[j++] = postfix[i++];
            }
            numStr[j] = '\0';
            push(&numStack, atof(numStr));
            continue;
        }
        
        // 处理一元运算符（负号）
        if (postfix[i] == '~') {
            if (!isStackEmpty(&numStack)) {
                double a = pop(&numStack);
                push(&numStack, -a);
            }
            i++;
            continue;
        }
        
        // 处理二元运算符
        if (isOperator(postfix[i])) {
            if (numStack.top < 1) {
                printf("错误：表达式无效！\n");
                exit(1);
            }
            double b = pop(&numStack);
            double a = pop(&numStack);
            double result = applyOperation(a, b, postfix[i]);
            push(&numStack, result);
            i++;
            continue;
        }
        
        i++;
    }
    
    if (isStackEmpty(&numStack)) {
        printf("错误：表达式无效！\n");
        return 0.0;
    }
    
    return pop(&numStack);
}

/**
 * 计算表达式
 * @param expr 表达式字符串
 * @return 计算结果
 */
double evaluateExpression(const char *expr) {
    char postfix[MAX_EXPR_LEN];
    infixToPostfix(expr, postfix);
    printf("后缀表达式: %s\n", postfix);
    return evaluatePostfix(postfix);
}

/**
 * 简易计算器模式
 */
void simpleCalculator() {
    printf("\n=== 简易计算器模式 ===\n");
    printf("支持基本运算: +, -, *, /, ^, %%\n");
    printf("示例: 输入 '2+3*4' 会得到 14（遵循运算优先级）\n");
    printf("输入 'quit' 返回主菜单\n\n");
    
    char expr[MAX_EXPR_LEN];
    
    while (1) {
        printf("请输入表达式: ");
        fgets(expr, MAX_EXPR_LEN, stdin);
        expr[strcspn(expr, "\n")] = '\0';  // 去除换行符
        
        if (strcmp(expr, "quit") == 0 || strcmp(expr, "exit") == 0) {
            break;
        }
        
        if (strlen(expr) == 0) {
            continue;
        }
        
        double result = evaluateExpression(expr);
        printf("结果: %s = %.6lf\n\n", expr, result);
    }
}

/**
 * 高级计算器模式
 */
void advancedCalculator() {
    printf("\n=== 高级计算器模式 ===\n");
    printf("支持功能:\n");
    printf("1. 四则运算: +, -, *, /\n");
    printf("2. 幂运算: ^\n");
    printf("3. 取模运算: %%\n");
    printf("4. 括号: ( )\n");
    printf("5. 三角函数: sin(), cos(), tan(), asin(), acos(), atan()\n");
    printf("6. 其他函数: sqrt(), log(), ln(), exp(), abs()\n");
    printf("7. 一元运算符: - (负号)\n");
    printf("示例: 输入 'sin(pi/2) + 2^3 * (4-1)'\n");
    printf("输入 'quit' 返回主菜单\n");
    printf("注意: pi 是圆周率常量 (3.141592653589793)\n\n");
    
    char expr[MAX_EXPR_LEN];
    
    while (1) {
        printf("请输入表达式: ");
        fgets(expr, MAX_EXPR_LEN, stdin);
        expr[strcspn(expr, "\n")] = '\0';  // 去除换行符
        
        if (strcmp(expr, "quit") == 0 || strcmp(expr, "exit") == 0) {
            break;
        }
        
        if (strlen(expr) == 0) {
            continue;
        }
        
        // 将字符串中的"pi"替换为π值
        char processedExpr[MAX_EXPR_LEN] = {0};
        int j = 0;
        for (int i = 0; expr[i] != '\0' && j < MAX_EXPR_LEN - 20; i++) {
            if (strncmp(&expr[i], "pi", 2) == 0 && 
                (i == 0 || !isalpha(expr[i-1])) && 
                (expr[i+2] == '\0' || !isalpha(expr[i+2]))) {
                char piStr[20];
                sprintf(piStr, "%.15lf", PI);
                for (int k = 0; piStr[k] != '\0'; k++) {
                    processedExpr[j++] = piStr[k];
                }
                i++;  // 跳过'p'，下一次循环会处理'i'
            } else {
                processedExpr[j++] = expr[i];
            }
        }
        processedExpr[j] = '\0';
        
        if (strlen(processedExpr) > 0) {
            printf("处理后的表达式: %s\n", processedExpr);
            double result = evaluateExpression(processedExpr);
            printf("结果: %.10lf\n\n", result);
        }
    }
}
