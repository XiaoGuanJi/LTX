REM Copyright 2023 LAOLIPEF
REM Licensed under Apache License, Version 2.0
@echo off
chcp 65001 >nul
echo ========================================
echo    内存优化计算器 - Windows构建脚本
echo ========================================

:: 检查编译器
where g++ >nul 2>&1
if %errorlevel% equ 0 (
    set COMPILER=g++
    goto :compile
)

where clang++ >nul 2>&1
if %errorlevel% equ 0 (
    set COMPILER=clang++
    goto :compile
)

where cl >nul 2>&1
if %errorlevel% equ 0 (
    set COMPILER=cl
    goto :msvc_compile
)

echo 错误: 未找到C++编译器
pause
exit /b 1

:msvc_compile
echo 使用编译器: %COMPILER%
echo 清理构建文件...
del memory_calculator.exe 2>nul

echo 开始编译(MSVC)...
cl /std:c++11 /O1 /EHsc /DNDEBUG main.cpp memory_efficient_calc.cpp lightweight_parser.cpp /Fe:memory_calculator.exe
if %errorlevel% equ 0 goto success
goto fail

:compile
echo 使用编译器: %COMPILER%
echo 清理构建文件...
del memory_calculator.exe 2>nul

echo 开始编译(GCC/Clang)...
%COMPILER% -std=c++11 -Os -s -DNDEBUG -o memory_calculator.exe main.cpp memory_efficient_calc.cpp lightweight_parser.cpp
if %errorlevel% equ 0 goto success
goto fail

:success
echo 构建成功!
if exist memory_calculator.exe (
    for %%F in (memory_calculator.exe) do set size=%%~zF
    echo 可执行文件大小: %size% 字节
)
echo.
echo 运行程序:
echo ========================================
memory_calculator.exe
pause
exit /b 0

:fail
echo 构建失败!
pause
exit /b 1
