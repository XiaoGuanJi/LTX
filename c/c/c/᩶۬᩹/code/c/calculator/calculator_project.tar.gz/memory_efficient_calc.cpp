/**
 * Copyright [2023] [LAOLIPEF]
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <iostream>
#include <cmath>
#include <cctype>
#include <cstring>

namespace efficient_calc {
    
    // 轻量级错误处理（不使用异常，减少内存开销）
    enum ErrorCode {
        SUCCESS = 0,
        ERROR_DIVIDE_BY_ZERO,
        ERROR_INVALID_EXPRESSION,
        ERROR_MEMORY_OVERFLOW,
        ERROR_INVALID_NUMBER,
        ERROR_PARENTHESIS_MISMATCH
    };
    
    // 全局错误状态（节省每个函数传递错误参数的开销）
    thread_local ErrorCode last_error = SUCCESS;
    
    const char* get_last_error() {
        switch (last_error) {
            case ERROR_DIVIDE_BY_ZERO: return "除零错误";
            case ERROR_INVALID_EXPRESSION: return "表达式无效";
            case ERROR_MEMORY_OVERFLOW: return "内存溢出";
            case ERROR_INVALID_NUMBER: return "数字格式错误";
            case ERROR_PARENTHESIS_MISMATCH: return "括号不匹配";
            default: return "无错误";
        }
    }
    
    // 极简栈实现（固定大小，避免动态内存分配）
    template<typename T, int MAX_SIZE = 64>
    class FixedStack {
    private:
        T data[MAX_SIZE];
        int top_index = -1;
        
    public:
        bool push(const T& value) {
            if (top_index >= MAX_SIZE - 1) {
                last_error = ERROR_MEMORY_OVERFLOW;
                return false;
            }
            data[++top_index] = value;
            return true;
        }
        
        bool pop(T& value) {
            if (top_index < 0) {
                return false;
            }
            value = data[top_index--];
            return true;
        }
        
        bool peek(T& value) const {
            if (top_index < 0) {
                return false;
            }
            value = data[top_index];
            return true;
        }
        
        bool empty() const { 
            return top_index < 0; 
        }
        
        int size() const { 
            return top_index + 1; 
        }
        
        void clear() {
            top_index = -1;
        }
    };
    
    // 运算符优先级（使用char而不是string节省内存）
    int get_precedence(char op) {
        switch (op) {
            case '+': 
            case '-': 
                return 1;
            case '*': 
            case '/': 
            case '%': 
                return 2;
            case '^': 
                return 3;
            default: 
                return 0;
        }
    }
    
    bool is_operator(char c) {
        return c == '+' || c == '-' || c == '*' || c == '/' || c == '%' || c == '^';
    }
    
    // 轻量级数字解析（直接操作字符串，不创建临时string）
    bool parse_number(const char*& expr, double& result) {
        const char* start = expr;
        bool has_dot = false;
        int digits = 0;
        
        // 跳过前导空格
        while (std::isspace(*expr)) {
            expr++;
        }
        start = expr;
        
        // 解析数字部分
        while (std::isdigit(*expr) || (*expr == '.' && !has_dot)) {
            if (*expr == '.') {
                has_dot = true;
            } else {
                digits++;
            }
            expr++;
        }
        
        if (digits == 0 && !has_dot) {
            last_error = ERROR_INVALID_NUMBER;
            return false;
        }
        
        // 简单数字解析（避免strtod的开销）
        result = 0.0;
        bool in_fraction = false;
        double fraction_divisor = 1.0;
        
        for (const char* p = start; p < expr; ++p) {
            if (*p == '.') {
                in_fraction = true;
                fraction_divisor = 10.0;
            } else if (in_fraction) {
                result += (*p - '0') / fraction_divisor;
                fraction_divisor *= 10.0;
            } else {
                result = result * 10.0 + (*p - '0');
            }
        }
        
        return true;
    }
    
    // 基本运算函数（内联减少调用开销）
    inline bool calculate_basic(double a, double b, char op, double& result) {
        switch (op) {
            case '+': 
                result = a + b; 
                return true;
            case '-': 
                result = a - b; 
                return true;
            case '*': 
                result = a * b; 
                return true;
            case '/': 
                if (b == 0.0) {
                    last_error = ERROR_DIVIDE_BY_ZERO;
                    return false;
                }
                result = a / b;
                return true;
            case '%':
                if (b == 0.0) {
                    last_error = ERROR_DIVIDE_BY_ZERO;
                    return false;
                }
                result = std::fmod(a, b);
                return true;
            case '^': 
                result = std::pow(a, b); 
                return true;
            default: 
                return false;
        }
    }
    
    // 直接求值法（单次遍历，不使用后缀表达式转换，节省内存）
    bool evaluate_expression_direct(const char* expr, double& result) {
        FixedStack<double, 32> values;
        FixedStack<char, 32> operators;
        
        // 应用运算符的lambda函数
        auto apply_operator = [&]() -> bool {
            if (operators.empty() || values.size() < 2) {
                return false;
            }
            
            char op;
            double b, a;
            operators.pop(op);
            values.pop(b);
            values.pop(a);
            
            double res;
            if (!calculate_basic(a, b, op, res)) {
                return false;
            }
            
            return values.push(res);
        };
        
        const char* original_expr = expr;
        bool expect_operand = true; // true表示期待操作数，false表示期待运算符
        
        while (*expr) {
            if (std::isspace(*expr)) {
                expr++;
                continue;
            }
            
            if (std::isdigit(*expr) || *expr == '.') {
                if (!expect_operand) {
                    last_error = ERROR_INVALID_EXPRESSION;
                    return false;
                }
                
                double num;
                if (!parse_number(expr, num)) {
                    return false;
                }
                if (!values.push(num)) {
                    return false;
                }
                expect_operand = false;
            }
            else if (*expr == '(') {
                if (!expect_operand) {
                    last_error = ERROR_INVALID_EXPRESSION;
                    return false;
                }
                if (!operators.push('(')) {
                    return false;
                }
                expr++;
                expect_operand = true;
            }
            else if (*expr == ')') {
                if (expect_operand) {
                    last_error = ERROR_INVALID_EXPRESSION;
                    return false;
                }
                
                // 应用括号内的所有运算符
                while (!operators.empty()) {
                    char top_op;
                    if (!operators.peek(top_op)) {
                        break;
                    }
                    if (top_op == '(') {
                        break;
                    }
                    if (!apply_operator()) {
                        return false;
                    }
                }
                
                // 弹出左括号
                char left_paren;
                if (!operators.pop(left_paren) || left_paren != '(') {
                    last_error = ERROR_PARENTHESIS_MISMATCH;
                    return false;
                }
                
                expr++;
                expect_operand = false;
            }
            else if (is_operator(*expr)) {
                char current_op = *expr;
                
                // 处理一元负号
                if (current_op == '-' && expect_operand) {
                    expr++;
                    if (std::isdigit(*expr) || *expr == '.') {
                        double num;
                        if (!parse_number(expr, num)) {
                            return false;
                        }
                        if (!values.push(-num)) {
                            return false;
                        }
                    } else if (*expr == '(') {
                        // 处理 -(expression) 的情况
                        if (!operators.push('(')) {
                            return false;
                        }
                        if (!values.push(-1.0) || !operators.push('*')) {
                            return false;
                        }
                        expr++;
                    } else {
                        last_error = ERROR_INVALID_EXPRESSION;
                        return false;
                    }
                    expect_operand = false;
                    continue;
                }
                
                if (expect_operand) {
                    last_error = ERROR_INVALID_EXPRESSION;
                    return false;
                }
                
                // 应用优先级更高的运算符
                while (!operators.empty()) {
                    char top_op;
                    if (!operators.peek(top_op)) {
                        break;
                    }
                    if (top_op == '(') {
                        break;
                    }
                    if (get_precedence(top_op) >= get_precedence(current_op)) {
                        if (!apply_operator()) {
                            return false;
                        }
                    } else {
                        break;
                    }
                }
                
                if (!operators.push(current_op)) {
                    return false;
                }
                expr++;
                expect_operand = true;
            }
            else {
                last_error = ERROR_INVALID_EXPRESSION;
                return false;
            }
        }
        
        // 应用剩余运算符
        while (!operators.empty()) {
            char top_op;
            if (!operators.peek(top_op)) {
                break;
            }
            if (top_op == '(') {
                last_error = ERROR_PARENTHESIS_MISMATCH;
                return false;
            }
            if (!apply_operator()) {
                return false;
            }
        }
        
        if (values.size() != 1) {
            last_error = ERROR_INVALID_EXPRESSION;
            return false;
        }
        
        return values.pop(result);
    }
    
    // 内存使用统计
    struct MemoryStats {
        size_t stack_memory;
        size_t total_memory;
        
        MemoryStats() : stack_memory(0), total_memory(0) {
            // 估算栈内存使用
            stack_memory = sizeof(FixedStack<double, 32>) + sizeof(FixedStack<char, 32>);
            total_memory = stack_memory + sizeof(ErrorCode);
        }
    };
    
    MemoryStats get_memory_stats() {
        return MemoryStats();
    }
    
    // 重置错误状态
    void reset_error() {
        last_error = SUCCESS;
    }
}
