/**
 * Copyright [2023] [LAOLIPEF]
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <iostream>
#include <cctype>
#include <cstring>

namespace lightweight_parser {
    
    using namespace efficient_calc;
    
    // 表达式验证（提前检查，避免无效计算）
    bool validate_expression(const char* expr) {
        int paren_count = 0;
        bool expect_operand = true; // true: 期待操作数, false: 期待运算符
        
        for (int i = 0; expr[i] != '\0'; ++i) {
            char c = expr[i];
            
            if (std::isspace(c)) {
                continue;
            }
            
            if (std::isdigit(c) || c == '.') {
                if (!expect_operand) {
                    return false;
                }
                
                // 验证数字格式
                bool has_dot = (c == '.');
                int j = i;
                while (std::isdigit(expr[j]) || expr[j] == '.') {
                    if (expr[j] == '.') {
                        if (has_dot) {
                            return false; // 多个小数点
                        }
                        has_dot = true;
                    }
                    j++;
                }
                i = j - 1;
                expect_operand = false;
            }
            else if (c == '(') {
                if (!expect_operand) {
                    return false;
                }
                paren_count++;
                expect_operand = true;
            }
            else if (c == ')') {
                if (expect_operand || paren_count <= 0) {
                    return false;
                }
                paren_count--;
                expect_operand = false;
            }
            else if (is_operator(c)) {
                if (expect_operand && c != '-') {
                    return false; // 只有负号可以是一元运算符
                }
                expect_operand = true;
            }
            else {
                return false; // 非法字符
            }
        }
        
        return paren_count == 0 && !expect_operand;
    }
    
    // 表达式简化（移除多余空格）
    void simplify_expression(const char* input, char* output, size_t max_len) {
        size_t j = 0;
        for (size_t i = 0; input[i] != '\0' && j < max_len - 1; ++i) {
            if (!std::isspace(input[i])) {
                output[j++] = input[i];
            }
        }
        output[j] = '\0';
    }
    
    // 批量计算器（复用内存，避免重复分配）
    class BatchCalculator {
    private:
        char expression_buffer[256];
        double results_buffer[64];
        
    public:
        BatchCalculator() {
            // 初始化缓冲区
            std::memset(expression_buffer, 0, sizeof(expression_buffer));
            std::memset(results_buffer, 0, sizeof(results_buffer));
        }
        
        // 计算单个表达式
        bool calculate_single(const char* expression, double& result) {
            // 复制表达式到缓冲区（避免修改原表达式）
            std::strncpy(expression_buffer, expression, sizeof(expression_buffer) - 1);
            expression_buffer[sizeof(expression_buffer) - 1] = '\0';
            
            // 简化表达式
            char simplified[256];
            simplify_expression(expression_buffer, simplified, sizeof(simplified));
            
            if (!validate_expression(simplified)) {
                last_error = ERROR_INVALID_EXPRESSION;
                return false;
            }
            
            return evaluate_expression_direct(simplified, result);
        }
        
        // 计算多个表达式，复用内存
        bool calculate_batch(const char* expressions[], int count, double results[]) {
            if (count > 64) {
                last_error = ERROR_MEMORY_OVERFLOW;
                return false;
            }
            
            for (int i = 0; i < count; ++i) {
                if (!calculate_single(expressions[i], results[i])) {
                    return false;
                }
            }
            return true;
        }
        
        // 获取内存使用信息
        void get_memory_info() {
            auto stats = get_memory_stats();
            std::cout << "批量计算器内存使用:\n";
            std::cout << "表达式缓冲区: " << sizeof(expression_buffer) << " 字节\n";
            std::cout << "结果缓冲区: " << sizeof(results_buffer) << " 字节\n";
            std::cout << "计算栈内存: " << stats.stack_memory << " 字节\n";
            std::cout << "总内存: " << stats.total_memory + sizeof(expression_buffer) + sizeof(results_buffer) 
                      << " 字节\n";
        }
    };
    
    // 性能测试函数
    void performance_test(const char* test_expression, int iterations) {
        std::cout << "性能测试: \"" << test_expression << "\" × " << iterations << " 次\n";
        
        double result;
        auto stats = efficient_calc::get_memory_stats();
        
        std::cout << "内存使用统计:\n";
        std::cout << "计算栈内存: " << stats.stack_memory << " 字节\n";
        std::cout << "总内存开销: " << stats.total_memory << " 字节\n";
        
        int success_count = 0;
        BatchCalculator calc;
        
        // 简单性能测试
        for (int i = 0; i < iterations; ++i) {
            if (calc.calculate_single(test_expression, result)) {
                success_count++;
            }
            efficient_calc::reset_error(); // 重置错误状态
        }
        
        std::cout << "计算成功率: " << success_count << "/" << iterations << " (" 
                  << (success_count * 100.0 / iterations) << "%)\n";
        
        if (success_count > 0) {
            calc.calculate_single(test_expression, result);
            std::cout << "计算结果: " << result << "\n";
        }
        
        std::cout << "测试完成\n\n";
    }
}
