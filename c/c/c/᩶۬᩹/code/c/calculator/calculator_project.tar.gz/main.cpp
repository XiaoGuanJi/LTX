/**
 * Copyright [2023] [LAOLIPEF]
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <iostream>
#include <iomanip>

// 声明函数
namespace efficient_calc {
    bool evaluate_expression_direct(const char* expr, double& result);
    const char* get_last_error();
    struct MemoryStats { size_t stack_memory, total_memory; };
    MemoryStats get_memory_stats();
    void reset_error();
}

namespace lightweight_parser {
    void performance_test(const char* test_expression, int iterations);
    class BatchCalculator;
}

void run_basic_tests() {
    std::cout << "=== 基本运算测试 ===\n";
    
    const char* basic_expressions[] = {
        "2 + 3",            // 5
        "10 - 4",           // 6
        "3 * 4",            // 12
        "15 / 3",           // 5
        "2 ^ 3",            // 8
        "17 % 5",           // 2
    };
    
    for (const auto& expr : basic_expressions) {
        double result;
        bool success = efficient_calc::evaluate_expression_direct(expr, result);
        
        std::cout << std::setw(15) << std::left << expr << " = ";
        if (success) {
            std::cout << result;
        } else {
            std::cout << "错误: " << efficient_calc::get_last_error();
        }
        std::cout << std::endl;
        efficient_calc::reset_error();
    }
}

void run_advanced_tests() {
    std::cout << "\n=== 高级运算测试 ===\n";
    
    const char* advanced_expressions[] = {
        "2 + 3 * 4",           // 14
        "(2 + 3) * 4",         // 20
        "10 - 4 / 2",          // 8
        "2 ^ 3 + 1",           // 9
        "15 % 4 + 2",          // 5
        "-5 + 10",             // 5
        "3.14 * 2",           // 6.28
        "1 + 2 * (3 + 4)",    // 15
        "2 ^ 3 ^ 2",          // 512
        "((1 + 2) * 3) ^ 2",  // 81
    };
    
    for (const auto& expr : advanced_expressions) {
        double result;
        bool success = efficient_calc::evaluate_expression_direct(expr, result);
        
        std::cout << std::setw(25) << std::left << expr << " = ";
        if (success) {
            std::cout << result;
        } else {
            std::cout << "错误: " << efficient_calc::get_last_error();
        }
        std::cout << std::endl;
        efficient_calc::reset_error();
    }
}

void run_error_tests() {
    std::cout << "\n=== 错误处理测试 ===\n";
    
    const char* error_expressions[] = {
        "1 / 0",              // 除零错误
        "2 + ",               // 不完整表达式
        "3 * * 4",            // 连续运算符
        "2 + 3)",             // 括号不匹配
        "(2 + 3",             // 括号不匹配
        "2.3.4 + 5",          // 无效数字
        "abc + 123",          // 非法字符
        "5 + / 3",            // 运算符位置错误
    };
    
    for (const auto& expr : error_expressions) {
        double result;
        bool success = efficient_calc::evaluate_expression_direct(expr, result);
        
        std::cout << std::setw(20) << std::left << expr << " -> ";
        if (!success) {
            std::cout << efficient_calc::get_last_error();
        } else {
            std::cout << result << " (意外成功)";
        }
        std::cout << std::endl;
        efficient_calc::reset_error();
    }
}

void run_performance_tests() {
    std::cout << "\n=== 性能测试 ===\n";
    
    // 简单表达式性能测试
    lightweight_parser::performance_test("2 + 3 * 4 - 5 / 2", 1000);
    
    // 复杂表达式性能测试
    lightweight_parser::performance_test("((1+2)*3-4/2)^2+((5-3)*2)^3", 500);
    
    // 长表达式性能测试
    lightweight_parser::performance_test("1+2+3+4+5+6+7+8+9+10-1-2-3-4-5-6-7-8-9-10", 800);
}

void run_batch_test() {
    std::cout << "\n=== 批量计算测试 ===\n";
    
    const char* batch_expressions[] = {
        "2 + 3",
        "5 * 8",
        "100 / 4", 
        "3 ^ 4",
        "(10 + 5) * 2",
        "2.5 * 4",
        "-3 + 7",
        "15 % 4"
    };
    
    const int expr_count = sizeof(batch_expressions) / sizeof(batch_expressions[0]);
    double results[expr_count];
    
    lightweight_parser::BatchCalculator batch_calc;
    
    if (batch_calc.calculate_batch(batch_expressions, expr_count, results)) {
        std::cout << "批量计算成功!\n";
        for (int i = 0; i < expr_count; ++i) {
            std::cout << std::setw(15) << std::left << batch_expressions[i] 
                      << " = " << results[i] << std::endl;
        }
    } else {
        std::cout << "批量计算失败: " << efficient_calc::get_last_error() << std::endl;
    }
    
    batch_calc.get_memory_info();
}

int main() {
    std::cout << "========================================\n";
    std::cout << "      内存优化计算器 - 完整测试\n";
    std::cout << "========================================\n\n";
    
    auto stats = efficient_calc::get_memory_stats();
    std::cout << "内存优化统计:\n";
    std::cout << "计算栈内存: " << stats.stack_memory << " 字节\n";
    std::cout << "总内存开销: " << stats.total_memory << " 字节\n";
    std::cout << "设计理念: 优先使用栈内存，必要时使用CPU算力\n\n";
    
    // 运行各种测试
    run_basic_tests();
    run_advanced_tests();
    run_error_tests();
    run_performance_tests();
    run_batch_test();
    
    std::cout << "\n========================================\n";
    std::cout << "所有测试完成！\n";
    std::cout << "========================================\n";
    
    return 0;
}
