#!/bin/bash
# Copyright [2023] [LAOLIPEF]
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

echo "========================================"
echo "   内存优化计算器 - 构建脚本"
echo "========================================"

# 检查编译器
if command -v g++ &> /dev/null; then
    COMPILER="g++"
elif command -v clang++ &> /dev/null; then
    COMPILER="clang++"
else
    echo "错误: 未找到C++编译器"
    exit 1
fi

echo "使用编译器: $COMPILER"

# 清理之前的构建
echo "清理构建文件..."
rm -f memory_calculator

# 编译选项说明
# -Os: 优化代码大小
# -fno-exceptions: 禁用异常（减少开销）
# -s: 移除符号表（减小文件大小）
# -DNDEBUG: 禁用断言（发布模式）

echo "开始编译..."
$COMPILER -std=c++11 -Os -fno-exceptions -s -DNDEBUG \
    -o memory_calculator \
    main.cpp \
    memory_efficient_calc.cpp \
    lightweight_parser.cpp

if [ $? -eq 0 ]; then
    echo "构建成功!"
    echo "可执行文件大小: $(stat -c%s memory_calculator) 字节"
    echo ""
    echo "运行程序:"
    echo "========================================"
    ./memory_calculator
else
    echo "构建失败!"
    exit 1
fi
