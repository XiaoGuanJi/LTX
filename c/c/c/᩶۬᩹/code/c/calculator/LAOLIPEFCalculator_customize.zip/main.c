/**
 * Copyright [2023] [LAOLIPEF]
 * 高级控制台计算器
 */

#include "lmath.h"

// 计算器状态
typedef struct {
    l_fixed memory;      // 内存寄存器
    l_fixed last_result; // 上一个结果
    int mode;           // 计算模式: 0=普通, 1=科学, 2=编程
    int angle_mode;     // 角度模式: 0=度, 1=弧度
    int hex_mode;       // 进制模式: 0=十进制, 1=十六进制, 2=二进制
} L_CALCULATOR;

// 计算器初始化
static L_CALCULATOR* l_calculator_new(void) {
    L_CALCULATOR *calc = (L_CALCULATOR*)l_malloc(sizeof(L_CALCULATOR));
    if (!calc) return 0;
    
    calc->memory = 0;
    calc->last_result = 0;
    calc->mode = 0;
    calc->angle_mode = 0;
    calc->hex_mode = 0;
    
    return calc;
}

// 显示计算器标题
static void l_calculator_title(const char *title) {
    l_clear();
    l_set_color(L_COLOR_CYAN, L_COLOR_BLACK);
    l_puts("=========================================");
    l_printf("      LAOLIPEF 高级计算器 v1.0\n");
    l_puts("=========================================");
    l_reset_color();
    
    if (title) {
        l_printf("> %s\n\n", title);
    }
}

// 显示当前状态
static void l_calculator_status(L_CALCULATOR *calc) {
    l_set_color(L_COLOR_YELLOW, L_COLOR_BLACK);
    l_printf("[状态] 模式: ");
    
    switch (calc->mode) {
        case 0: l_print("普通"); break;
        case 1: l_print("科学"); break;
        case 2: l_print("编程"); break;
    }
    
    l_printf(" | 角度: %s | 进制: ", 
             calc->angle_mode ? "弧度" : "度");
    
    switch (calc->hex_mode) {
        case 0: l_print("十进制"); break;
        case 1: l_print("十六进制"); break;
        case 2: l_print("二进制"); break;
    }
    
    l_printf("\n");
    l_reset_color();
}

// 数值显示
static void l_calculator_display_value(l_fixed value, int hex_mode) {
    char buffer[64];
    
    l_set_color(L_COLOR_GREEN, L_COLOR_BLACK);
    
    switch (hex_mode) {
        case 0:  // 十进制
            l_fixed_to_str(value, buffer, 6);
            l_printf("结果: %s\n", buffer);
            break;
            
        case 1:  // 十六进制
            l_printf("结果: 0x%08lX\n", (unsigned long)value);
            break;
            
        case 2:  // 二进制
            l_print("结果: ");
            for (int i = 31; i >= 0; i--) {
                l_putchar((value >> i) & 1 ? '1' : '0');
                if (i > 0 && i % 4 == 0) l_putchar(' ');
            }
            l_putchar('\n');
            break;
    }
    l_reset_color();
}

// 输入数值
// 修改整个while循环：
static l_fixed l_calculator_input_number(void) {
    char buffer[128];
    int i = 0;
    int c;  // 改为int类型，可以正确处理EOF
    
    l_print("请输入数值: ");
    
    while ((c = l_getchar()) != '\n') {
        if (c == L_EOF) {  // 现在这是正确的
            buffer[0] = '\0';
            return 0;
        }
        
        if (i < 127 && ((c >= '0' && c <= '9') || 
                        c == '.' || c == '-' || c == '+')) {
            buffer[i++] = (char)c;  // 需要类型转换
            l_putchar((char)c);
        } else if (c == '\b' && i > 0) {  // 退格键
            i--;
            l_print("\b \b");
        }
    }
    // ... 其余代码不变
    
    buffer[i] = '\0';
    
    if (i == 0) {
        return 0;
    }
    
    return l_str_to_fixed(buffer);
}

// 输入操作符
static int l_calculator_input_operator(void) {
    l_puts("\n请选择操作:");
    l_puts("  +  加  -  减  *  乘  /  除");
    l_puts("  ^  幂  s  平方  r  开方");
    l_puts("  m  内存操作  c  清除  q  退出");
    l_print("> ");
    
    return l_getchar();
}

// 基本运算
static l_fixed l_calculator_basic_operation(l_fixed a, l_fixed b, char op, int *error) {
    *error = L_SUCCESS;
    
    switch (op) {
        case '+':
            return a + b;
            
        case '-':
            return a - b;
            
        case '*':
            return (a * b) >> L_FIXED_SHIFT;
            
        case '/':
            if (b == 0) {
                *error = L_EMATH_DOMAIN;
                return 0;
            }
            return (a << L_FIXED_SHIFT) / b;
            
        case '^':
            return l_fpow(a, b);
            
        default:
            *error = L_EINVAL;
            return 0;
    }
}

// 科学计算函数
static l_fixed l_calculator_scientific(l_fixed x, int func, int angle_mode, int *error) {
    *error = L_SUCCESS;
    
    // 角度转弧度
    l_fixed rad = x;
    if (angle_mode == 0) {  // 度转弧度
        rad = (x * 3141592654) / 180000000000;
    }
    
    switch (func) {
        case 's':  // sin
            // 简单近似
            if (rad > (3141592654 >> 1)) {
                rad = 3141592654 - rad;
            }
            return (rad - ((rad * rad * rad) / 6000000000)) >> 10;
            
        case 'c':  // cos
            return l_fsqrt(L_FIXED_ONE - l_fsqr(
                l_calculator_scientific(x, 's', angle_mode, error)));
            
        case 't':  // tan
            {
            l_fixed sin_val = l_calculator_scientific(x, 's', angle_mode, error);
            l_fixed cos_val = l_calculator_scientific(x, 'c', angle_mode, error);
            if (cos_val == 0) {
                *error = L_EMATH_DOMAIN;
                return 0;
            }
            return (sin_val << L_FIXED_SHIFT) / cos_val;
            }
        case 'l':  // ln
            return l_fln(x);
            
        case 'e':  // exp
            return l_fexp(x);
            
        case 'r':  // sqrt
            return l_fsqrt(x);
            
        case '3':  // cbrt
            return l_fcbrt(x);
            
        case '!':  // 阶乘
            {
                int n = l_fixed_to_int(x);
                if (n < 0 || n > 20) {
                    *error = L_EMATH_DOMAIN;
                    return 0;
                }
                return l_int_to_fixed(l_factorial(n));
            }
            
        default:
            *error = L_EINVAL;
            return 0;
    }
}

// 编程计算函数
static unsigned int l_calculator_programming(unsigned int a, unsigned int b, char op, int *error) {
    *error = L_SUCCESS;
    
    switch (op) {
        case '&':  // AND
            return a & b;
            
        case '|':  // OR
            return a | b;
            
        case '^':  // XOR
            return a ^ b;
            
        case '~':  // NOT
            return ~a;
            
        case '<':  // 左移
            return a << b;
            
        case '>':  // 右移
            return a >> b;
            
        case 'c':  // 统计1的个数
            return l_popcount(a);
            
        case 'b':  // 位反转
            return l_bit_reverse(a);
            
        case 'n':  // 下个2的幂
            return l_next_power_of_two(a);
            
        case 'p':  // 判断2的幂
            return l_is_power_of_two(a);
            
        default:
            *error = L_EINVAL;
            return 0;
    }
}

// 内存操作
static void l_calculator_memory_menu(L_CALCULATOR *calc) {
    l_puts("\n内存操作:");
    l_puts("  s  存储当前值");
    l_puts("  r  读取内存");
    l_puts("  c  清除内存");
    l_puts("  a  加到内存");
    l_puts("  b  从内存减去");
    l_puts("  d  显示内存值");
    l_puts("  q  返回主菜单");
    
    l_print("> ");
    
    char op = l_getchar();
    l_getchar();  // 清除换行符
    
    switch (op) {
        case 's':  // 存储
            calc->memory = calc->last_result;
            l_set_color(L_COLOR_GREEN, L_COLOR_BLACK);
            l_puts("已存储到内存");
            l_reset_color();
            break;
            
        case 'r':  // 读取
            calc->last_result = calc->memory;
            l_calculator_display_value(calc->memory, calc->hex_mode);
            break;
            
        case 'c':  // 清除
            calc->memory = 0;
            l_set_color(L_COLOR_GREEN, L_COLOR_BLACK);
            l_puts("内存已清除");
            l_reset_color();
            break;
            
        case 'a':  // 加到内存
            calc->memory += calc->last_result;
            l_puts("已加到内存");
            break;
            
        case 'b':  // 从内存减去
            calc->memory -= calc->last_result;
            l_puts("已从内存减去");
            break;
            
        case 'd':  // 显示
            l_calculator_display_value(calc->memory, calc->hex_mode);
            break;
    }
}

// 科学计算菜单
static void l_calculator_scientific_menu(L_CALCULATOR *calc) {
    l_puts("\n科学计算:");
    l_puts("  s  sin     c  cos     t  tan");
    l_puts("  l  ln      e  exp     r  sqrt");
    l_puts("  3  cbrt    !  阶乘    ^  幂");
    l_puts("  g  对数    m  切换角度模式");
    l_puts("  q  返回主菜单");
    
    l_print("> ");
    
    char op = l_getchar();
    l_getchar();  // 清除换行符
    
    if (op == 'm') {  // 切换角度模式
        calc->angle_mode = !calc->angle_mode;
        l_printf("角度模式: %s\n", calc->angle_mode ? "弧度" : "度");
        return;
    }
    
    if (op == 'q') return;
    
    l_fixed x = l_calculator_input_number();
    int error = L_SUCCESS;
    l_fixed result = 0;
    
    if (op == 'g') {  // 对数
        l_puts("请输入底数: ");
        l_fixed base = l_calculator_input_number();
        if (base <= 0) {
            l_perror("底数必须大于0", L_EMATH_DOMAIN);
            return;
        }
        
        l_fixed ln_x = l_fln(x);
        l_fixed ln_base = l_fln(base);
        
        if (ln_base == 0) {
            l_perror("底数错误", L_EMATH_DOMAIN);
            return;
        }
        
        result = (ln_x << L_FIXED_SHIFT) / ln_base;
    } else if (op == '!') {  // 阶乘
        int n = l_fixed_to_int(x);
        if (n < 0) {
            l_perror("阶乘不能为负数", L_EMATH_DOMAIN);
            return;
        }
        result = l_int_to_fixed(l_factorial(n));
    } else {
        result = l_calculator_scientific(x, op, calc->angle_mode, &error);
    }
    
    if (error == L_SUCCESS) {
        calc->last_result = result;
        l_calculator_display_value(result, calc->hex_mode);
    } else {
        l_perror("计算错误", error);
    }
}

// 编程计算菜单
static void l_calculator_programming_menu(L_CALCULATOR *calc) {
    l_puts("\n编程计算:");
    l_puts("  &  AND     |  OR      ^  XOR");
    l_puts("  ~  NOT     <  左移    >  右移");
    l_puts("  c  统计1    b  位反转  n  下个2的幂");
    l_puts("  p  判断2的幂  m  切换进制");
    l_puts("  q  返回主菜单");
    
    l_print("> ");
    
    char op = l_getchar();
    l_getchar();  // 清除换行符
    
    if (op == 'm') {  // 切换进制
        calc->hex_mode = (calc->hex_mode + 1) % 3;
        l_printf("进制模式: ");
        switch (calc->hex_mode) {
            case 0: l_puts("十进制"); break;
            case 1: l_puts("十六进制"); break;
            case 2: l_puts("二进制"); break;
        }
        return;
    }
    
    if (op == 'q') return;
    
    l_puts("请输入数值(十进制):");
    unsigned int a = l_calculator_input_number();
    unsigned int b = 0;
    
    if (op != '~' && op != 'c' && op != 'b' && op != 'n' && op != 'p') {
        l_puts("请输入第二个数值:");
        b = l_calculator_input_number();
    }
    
    int error = L_SUCCESS;
    unsigned int result = l_calculator_programming(a, b, op, &error);
    
    if (error == L_SUCCESS) {
        calc->last_result = result;
        
        // 显示所有进制
        l_set_color(L_COLOR_CYAN, L_COLOR_BLACK);
        l_printf("十进制: %u\n", result);
        l_printf("十六进制: 0x%08X\n", result);
        l_print("二进制: ");
        
        for (int i = 31; i >= 0; i--) {
            l_putchar((result >> i) & 1 ? '1' : '0');
            if (i > 0 && i % 4 == 0) l_putchar(' ');
        }
        l_putchar('\n');
        
        l_reset_color();
    } else {
        l_perror("计算错误", error);
    }
}

// 统计计算菜单
static void l_calculator_statistics_menu(void) {
    l_puts("\n统计计算:");
    l_puts("  a  平均值  v  方差  s  标准差");
    l_puts("  m  中位数  c  相关系数");
    l_puts("  q  返回主菜单");
    
    l_print("> ");
    
    char op = l_getchar();
    l_getchar();  // 清除换行符
    
    if (op == 'q') return;
    
    l_puts("输入数据个数: ");
    int n = l_fixed_to_int(l_calculator_input_number());
    
    if (n <= 0 || n > 100) {
        l_perror("数据个数无效", L_EINVAL);
        return;
    }
    
    l_fixed *data = (l_fixed*)l_malloc(sizeof(l_fixed) * n);
    if (!data) {
        l_perror("内存不足", L_ENOMEM);
        return;
    }
    
    for (int i = 0; i < n; i++) {
        l_printf("数据[%d]: ", i + 1);
        data[i] = l_calculator_input_number();
    }
    
    l_fixed result = 0;
    
    switch (op) {
        case 'a':  // 平均值
            result = l_mean(data, n);
            l_printf("平均值: ");
            break;
            
        case 'v':  // 方差
            result = l_variance(data, n);
            l_printf("方差: ");
            break;
            
        case 's':  // 标准差
            result = l_stddev(data, n);
            l_printf("标准差: ");
            break;
            
        case 'm':  // 中位数
            result = l_median(data, n);
            l_printf("中位数: ");
            break;
            
        case 'c':  // 相关系数
            {
                l_puts("输入第二组数据:");
                l_fixed *data2 = (l_fixed*)l_malloc(sizeof(l_fixed) * n);
                if (!data2) {
                    l_free(data);
                    l_perror("内存不足", L_ENOMEM);
                    return;
                }
                
                for (int i = 0; i < n; i++) {
                    l_printf("数据2[%d]: ", i + 1);
                    data2[i] = l_calculator_input_number();
                }
                
                result = l_correlation(data, data2, n);
                l_free(data2);
                l_printf("相关系数: ");
            }
            break;
            
        default:
            l_free(data);
            l_perror("无效操作", L_EINVAL);
            return;
    }
    
    l_calculator_display_value(result, 0);
    l_free(data);
}

// 几何计算菜单
static void l_calculator_geometry_menu(void) {
    l_puts("\n几何计算:");
    l_puts("  d  距离    a  面积    p  周长");
    l_puts("  c  圆计算  r  矩形计算");
    l_puts("  t  三角形计算");
    l_puts("  q  返回主菜单");
    
    l_print("> ");
    
    char op = l_getchar();
    l_getchar();  // 清除换行符
    
    if (op == 'q') return;
    
    switch (op) {
        case 'd':  // 距离
            {
                l_puts("输入点1 (x1, y1):");
                l_fixed x1 = l_calculator_input_number();
                l_fixed y1 = l_calculator_input_number();
                
                l_puts("输入点2 (x2, y2):");
                l_fixed x2 = l_calculator_input_number();
                l_fixed y2 = l_calculator_input_number();
                
                l_fixed dist = l_distance(x1, y1, x2, y2);
                l_printf("欧氏距离: ");
                l_calculator_display_value(dist, 0);
                
                l_fixed mdist = l_manhattan_dist(x1, y1, x2, y2);
                l_printf("曼哈顿距离: ");
                l_calculator_display_value(mdist, 0);
                
                l_fixed cdist = l_chebyshev_dist(x1, y1, x2, y2);
                l_printf("切比雪夫距离: ");
                l_calculator_display_value(cdist, 0);
            }
            break;
            
        case 'c':  // 圆计算
            {
                l_puts("输入半径:");
                l_fixed radius = l_calculator_input_number();
                
                l_fixed area = l_circle_area(radius);
                l_printf("面积: ");
                l_calculator_display_value(area, 0);
                
                l_fixed circ = l_circle_circumference(radius);
                l_printf("周长: ");
                l_calculator_display_value(circ, 0);
            }
            break;
            
        case 'r':  // 矩形计算
            {
                l_puts("输入宽和高:");
                l_fixed w = l_calculator_input_number();
                l_fixed h = l_calculator_input_number();
                
                l_fixed area = l_rect_area(w, h);
                l_printf("面积: ");
                l_calculator_display_value(area, 0);
                
                l_fixed peri = l_rect_perimeter(w, h);
                l_printf("周长: ");
                l_calculator_display_value(peri, 0);
            }
            break;
            
        default:
            l_perror("暂未实现", L_ENOSYS);
            break;
    }
}

// 单位换算菜单
static void l_calculator_unit_conversion_menu(void) {
    l_puts("\n单位换算:");
    l_puts("  1  角度↔弧度  2  温度(℃↔℉)");
    l_puts("  3  长度换算   4  重量换算");
    l_puts("  q  返回主菜单");
    
    l_print("> ");
    
    char op = l_getchar();
    l_getchar();  // 清除换行符
    
    if (op == 'q') return;
    
    l_fixed value = l_calculator_input_number();
    l_fixed result = 0;
    
    switch (op) {
        case '1':  // 角度↔弧度
            l_printf("%.6f 度 = %.6f 弧度\n", 
                    l_fixed_to_int(value) + ((value & 0xFFFF) * 1.0 / 65536),
                    ((value * 3141592654) >> 16) * 1.0 / 1000000000);
            l_printf("%.6f 弧度 = %.6f 度\n", 
                    l_fixed_to_int(value) + ((value & 0xFFFF) * 1.0 / 65536),
                    ((value * 572957795) >> 16) * 1.0 / 1000000000);
            break;
            
        case '2':  // 温度
            l_printf("%.2f ℃ = %.2f ℉\n", 
                    l_fixed_to_int(value) + ((value & 0xFFFF) * 1.0 / 65536),
                    ((value * 9 / 5 + 32) + ((value & 0xFFFF) * 9.0 / 327680)));
            break;
            
        default:
            l_perror("暂未实现", L_ENOSYS);
            break;
    }
}

// 主菜单
static int l_calculator_main_menu(L_CALCULATOR *calc) {
    l_calculator_title("主菜单");
    l_calculator_status(calc);
    l_calculator_display_value(calc->last_result, calc->hex_mode);
    
    l_puts("\n请选择模式:");
    l_puts("  1  基本计算");
    l_puts("  2  科学计算");
    l_puts("  3  编程计算");
    l_puts("  4  统计计算");
    l_puts("  5  几何计算");
    l_puts("  6  单位换算");
    l_puts("  7  内存操作");
    l_puts("  8  切换模式");
    l_puts("  9  演示所有功能");
    l_puts("  0  退出计算器");
    
    l_print("> ");
    
    char choice = l_getchar();
    l_getchar();  // 清除换行符
    
    switch (choice) {
        case '1':  // 基本计算
            {
                l_calculator_title("基本计算");
                l_puts("输入第一个数:");
                l_fixed a = l_calculator_input_number();
                
                l_fixed b = 0;
                char op = 0;
                int need_second = 1;
                
                while (1) {
                    if (need_second) {
                        l_puts("输入第二个数:");
                        b = l_calculator_input_number();
                    }
                    
                    op = l_calculator_input_operator();
                    l_getchar();  // 清除换行符
                    
                    if (op == 'q') break;
                    
                    if (op == 'm') {  // 内存操作
                        l_calculator_memory_menu(calc);
                        continue;
                    }
                    
                    if (op == 'c') {  // 清除
                        a = 0;
                        l_puts("已清除");
                        break;
                    }
                    
                    int error = L_SUCCESS;
                    l_fixed result = 0;
                    
                    if (op == 's') {  // 平方
                        result = l_fsqr(a);
                        need_second = 0;
                    } else if (op == 'r') {  // 开方
                        result = l_fsqrt(a);
                        need_second = 0;
                    } else {
                        result = l_calculator_basic_operation(a, b, op, &error);
                        need_second = 1;
                    }
                    
                    if (error == L_SUCCESS) {
                        calc->last_result = result;
                        a = result;  // 连续计算
                        l_calculator_display_value(result, calc->hex_mode);
                    } else {
                        l_perror("计算错误", error);
                    }
                }
            }
            break;
            
        case '2':  // 科学计算
            l_calculator_scientific_menu(calc);
            break;
            
        case '3':  // 编程计算
            l_calculator_programming_menu(calc);
            break;
            
        case '4':  // 统计计算
            l_calculator_statistics_menu();
            break;
            
        case '5':  // 几何计算
            l_calculator_geometry_menu();
            break;
            
        case '6':  // 单位换算
            l_calculator_unit_conversion_menu();
            break;
            
        case '7':  // 内存操作
            l_calculator_memory_menu(calc);
            break;
            
        case '8':  // 切换模式
            calc->mode = (calc->mode + 1) % 3;
            l_printf("切换到%s模式\n", 
                     calc->mode == 0 ? "普通" : 
                     calc->mode == 1 ? "科学" : "编程");
            break;
            
        case '9':  // 演示
            l_math_demo();
            l_puts("\n按任意键继续...");
            l_getchar();
            break;
            
        case '0':  // 退出
            return 0;
            
        default:
            l_puts("无效选择!");
            l_msleep(1000);
            break;
    }
    
    l_puts("\n按任意键继续...");
    l_getchar();
    return 1;
}

// 计算器主函数
void l_calculator_main(void) {
    L_CALCULATOR *calc = l_calculator_new();
    if (!calc) {
        l_perror("计算器初始化失败", L_ENOMEM);
        return;
    }
    
    l_srand(l_time());
    
    // 显示欢迎信息
    l_clear();
    l_set_color(L_COLOR_RED, L_COLOR_BLACK);
    l_puts("=========================================");
    l_puts("  欢迎使用 LAOLIPEF 高级计算器 v1.0");
    l_puts("=========================================");
    l_reset_color();
    l_puts("\n特性:");
    l_puts("  • 基本四则运算");
    l_puts("  • 科学计算（三角函数、对数、指数）");
    l_puts("  • 编程计算（位运算、进制转换）");
    l_puts("  • 统计计算（均值、方差、相关性）");
    l_puts("  • 几何计算（距离、面积、周长）");
    l_puts("  • 单位换算");
    l_puts("  • 内存功能");
    l_puts("\n使用拼音九键错误码系统");
    l_puts("\n按任意键开始...");
    l_getchar();
    
    int running = 1;
    while (running) {
        running = l_calculator_main_menu(calc);
    }
    
    // 显示退出信息
    l_calculator_title("感谢使用");
    l_set_color(L_COLOR_GREEN, L_COLOR_BLACK);
    l_puts("计算器已关闭");
    l_reset_color();
    
    l_free(calc);
}

// 主程序入口
int main() {
    l_calculator_main();
    return 0;
}
