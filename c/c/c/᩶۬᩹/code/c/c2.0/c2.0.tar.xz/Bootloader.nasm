; Copyright [2023] [LAOLIPEF]
;
; Licensed under the Apache License, Version 2.0 (the "License");
; you may not use this file except in compliance with the License.
; You may obtain a copy of the License at
;
;     http://www.apache.org/licenses/LICENSE-2.0
;
; Unless required by applicable law or agreed to in writing, software
; distributed under the License is distributed on an "AS IS" BASIS,
; WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
; See the License for the specific language governing permissions and
; limitations under the License.

[BITS 16]
[ORG 0x7C00]

; -------------------------- 常量定义（修复核心问题） --------------------------
TIMEOUT     equ 10
KERNEL_SECTOR  equ 2          ; 内核起始扇区（从第2扇区开始，跳过MBR）
KERNEL_SIZE    equ 10         ; 内核占用扇区数
VIDEO_MEM      equ 0xB800     ; 文本模式视频内存地址
BLUE_COLOR     equ 0x1F       ; 亮白字蓝底（属性字节）
KERNEL_OFFSET  equ 0x8000     ; 内核加载地址（避开MBR占用的0x7C00-0x7DFF）
LANG_CHINESE   equ 1          ; 1=中文 0=英文

; -------------------------- 字符串数据 --------------------------
en_loading  db "Loading...", 0
zh_loading  db 0xB2,0xE2,0xD4,0xDA,0xBC,0xD3,0xBC,0xFE,0x2E,0x2E,0x2E,0  ; "正在加载..."
en_error    db "KERNEL NOT FOUND", 0
zh_error    db 0xBF,0xA8,0xBA,0xCB,0xB6,0xD4,0xCA,0xA7,0  ; "内核丢失"
en_reboot   db "Press any key to reboot", 0
zh_reboot   db 0xB0,0xB4,0xC8,0xCE,0xD2,0xE2,0xBC,0xFC,0xC6,0xF4,0xBA,0xCE,0xCD,0xFC,0  ; "按任意键重启"

; -------------------------- 极简字符输出函数 --------------------------
; 功能：打印以0结尾的字符串  输入：SI=字符串地址  依赖：BIOS int 0x10
print_minimal:
    pusha
    mov ah, 0x0E            ; BIOS TTY输出模式
    mov bh, 0x00            ; 页码0
.print_loop:
    lodsb                   ; 读取一个字符到AL
    or al, al               ; 判断是否到字符串末尾
    jz .done
    int 0x10                ; 调用BIOS中断输出字符
    jmp .print_loop
.done:
    popa
    ret

; -------------------------- 蓝屏错误处理函数 --------------------------
blue_screen:
    pusha
    cli                     ; 禁用中断，防止干扰

    ; 1. 填充全屏蓝色背景
    mov ax, VIDEO_MEM
    mov es, ax              ; ES指向视频内存
    xor di, di              ; DI=0（从左上角开始）
    mov cx, 80*25           ; 字符总数：80列×25行
    mov ax, BLUE_COLOR << 8 | ' '  ; AH=属性  AL=空格字符
    rep stosw               ; 批量填充视频内存

    ; 2. 显示错误信息（左上角）
%if LANG_CHINESE == 1
    mov si, zh_error
%else
    mov si, en_error
%endif
    call print_minimal

    ; 3. 显示重启提示（左下角，第24行第0列）
    mov ah, 0x02            ; BIOS设置光标位置
    mov bh, 0x00            ; 页码0
    mov dh, 24              ; 行号（0~24）
    mov dl, 0               ; 列号（0~79）
    int 0x10
%if LANG_CHINESE == 1
    mov si, zh_reboot
%else
    mov si, en_reboot
%endif
    call print_minimal

    ; 4. 等待按键后重启
    xor ah, ah
    int 0x16                ; 等待键盘输入
    int 0x19                ; 调用BIOS重启功能
    popa
    ret

; -------------------------- 内核存在性检查函数 --------------------------
; 检查逻辑：读取内核第一个扇区 → 验证MZ魔数（0x5A4D）
check_kernel:
    pusha
    mov ah, 0x02            ; BIOS读磁盘扇区功能
    mov al, 1               ; 读取1个扇区
    mov ch, 0               ; 柱面号0
    mov dh, 0               ; 磁头号0
    mov cl, KERNEL_SECTOR   ; 起始扇区号
    mov bx, 0x7E00          ; 临时存储地址（MBR之后的内存）
    int 0x13                ; 调用BIOS中断读盘
    jc .kernel_error        ; CF=1表示读盘失败

    cmp word [0x7E00], 0x5A4D  ; 检查MZ魔数（DOS/PE文件头标志）
    jne .kernel_error       ; 魔数不匹配则报错

    popa
    ret
.kernel_error:
    call blue_screen
    hlt                     ; 死机保护

; -------------------------- 主程序入口 --------------------------
start:
    ; 1. 初始化寄存器与栈（修复栈空间重叠问题）
    cli
    xor ax, ax
    mov ds, ax              ; 数据段DS=0
    mov ss, ax              ; 栈段SS=0
    mov sp, 0x7000          ; 栈顶设为0x7000，避开MBR的0x7C00
    sti

    ; 2. 显示加载提示
%if LANG_CHINESE == 1
    mov si, zh_loading
%else
    mov si, en_loading
%endif
    call print_minimal

    ; 3. 检查内核是否存在
    call check_kernel

    ; 4. 加载内核到指定内存地址
    mov ah, 0x02            ; BIOS读磁盘扇区功能
    mov al, KERNEL_SIZE     ; 读取KERNEL_SIZE个扇区
    mov ch, 0               ; 柱面号0
    mov dh, 0               ; 磁头号0
    mov cl, KERNEL_SECTOR   ; 起始扇区号
    mov bx, KERNEL_OFFSET   ; 内核加载地址
    int 0x13                ; 调用BIOS中断读盘
    jc start                ; 读盘失败则重启

    ; 5. 跳转到内核执行
    jmp KERNEL_OFFSET

; -------------------------- MBR引导程序填充 --------------------------
times 510 - ($ - $$) db 0   ; 填充到510字节
dw 0xAA55                   ; MBR结束标志
