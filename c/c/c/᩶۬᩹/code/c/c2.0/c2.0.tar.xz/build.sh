#!/bin/bash
#
# Copyright [2023] [LAOLIPEF]
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

nasm -f bin Bootloader.nasm -o boot.bin || {
    echo "编译失败"
    exit 1
}

# 检查引导程序大小
BOOT_SIZE=$(stat -c%s boot.bin)
if [ $BOOT_SIZE -gt 512 ]; then
    echo "警告: 引导程序超过512字节(实际: $BOOT_SIZE)"
fi

# 创建磁盘镜像
dd if=/dev/zero of=disk.img bs=1024 count=1440 status=none
dd if=boot.bin of=disk.img conv=notrunc status=none

# 启动测试
echo "启动QEMU..."
qemu-system-i386 -drive format=raw,file=disk.img -nographic
