/**
 * 3D渲染自动演示程序
 */

#include "l3d.h"

int main() {
    l_puts("=== LAOLIPEF 3D 渲染自动演示 ===\n");
    
    // 创建3D渲染上下文
    L3D_Context *ctx = l3d_create_context(80, 40, L3D_MODE_TEXT);
    if (L_IS_NULL(ctx)) {
        l_puts("错误：无法创建3D上下文\n");
        return 1;
    }
    
    // 等待2秒开始
    l_puts("演示将在2秒后开始...\n");
    l_sleep(2, 0);
    
    // 场景1：静态场景
    l_puts("场景1：静态3D场景\n");
    l3d_clear(ctx, ' ', 0);
    
    L3D_Vec3 origin = {0, 0, 0};
    
    // 绘制坐标轴
    l3d_draw_line(ctx, origin, l3d_vec3_create(5, 0, 0), 0xFF0000);
    l3d_draw_line(ctx, origin, l3d_vec3_create(0, 5, 0), 0x00FF00);
    l3d_draw_line(ctx, origin, l3d_vec3_create(0, 0, 5), 0x0000FF);
    
    // 绘制网格
    l3d_draw_grid(ctx, 8.0f, 8, 0x333333);
    
    // 绘制多个几何体
    l3d_draw_cube(ctx, l3d_vec3_create(-3, 0, -3), 1.5f, l3d_matrix_identity(), 0xFF0000);
    l3d_draw_cube(ctx, l3d_vec3_create(3, 0, -3), 1.5f, l3d_matrix_rotate_y(1.0f), 0x00FF00);
    l3d_draw_cube(ctx, l3d_vec3_create(-3, 0, 3), 1.5f, l3d_matrix_rotate_x(1.0f), 0x0000FF);
    l3d_draw_cube(ctx, l3d_vec3_create(3, 0, 3), 1.5f, l3d_matrix_rotate_z(1.0f), 0xFFFF00);
    
    l3d_draw_sphere(ctx, l3d_vec3_create(0, 3, 0), 2.0f, 16, 0xFF00FF);
    
    l3d_render(ctx);
    
    l_puts("\n显示静态场景3秒...");
    l_sleep(3, 0);
    
    // 场景2：旋转动画
    l_puts("\n场景2：3D旋转动画\n");
    
    float angle = 0;
    for (int frame = 0; frame < 60; frame++) {
        l3d_clear(ctx, '.', 0);
        
        // 旋转矩阵
        L3D_Matrix rot = l3d_matrix_rotate_y(angle);
        L3D_Matrix tilt = l3d_matrix_rotate_x(angle * 0.3f);
        L3D_Matrix transform = l3d_matrix_mul(rot, tilt);
        
        // 绘制坐标轴
        l3d_draw_line(ctx, origin, l3d_vec3_create(4, 0, 0), 0xFF0000);
        l3d_draw_line(ctx, origin, l3d_vec3_create(0, 4, 0), 0x00FF00);
        l3d_draw_line(ctx, origin, l3d_vec3_create(0, 0, 4), 0x0000FF);
        
        // 绘制主立方体
        l3d_draw_cube(ctx, origin, 2.5f, transform, 0xFFFFFF);
        
        // 绘制轨道球体
        for (int i = 0; i < 8; i++) {
            float orbit_angle = angle + i * 0.785f;  // 45度
            float radius = 5.0f;
            
            L3D_Vec3 pos = {
                l3d_fcos(orbit_angle) * radius,
                l3d_fsin(orbit_angle * 2) * 2.0f,
                l3d_fsin(orbit_angle) * radius
            };
            
            l3d_draw_sphere(ctx, pos, 0.6f, 10, 0x00FFFF);
        }
        
        l3d_render(ctx);
        
        angle += 0.1f;
        l_sleep(0, 100000000);  // 100ms
    }
    
    l3d_destroy_context(ctx);
    
    l_puts("\n=== 演示完成 ===");
    l_puts("谢谢观看！\n");
    
    return 0;
}
