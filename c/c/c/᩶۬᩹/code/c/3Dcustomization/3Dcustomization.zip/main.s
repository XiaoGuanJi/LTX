	.file	"main.c"
	.text
	.globl	main                            // -- Begin function main
	.p2align	2
	.type	main,@function
main:                                   // @main
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x28, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w28, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	sub	sp, sp, #1136
	sub	x8, x29, #32
	str	x8, [sp, #288]                  // 8-byte Folded Spill
	stur	wzr, [x29, #-4]
	adrp	x0, .L.str
	add	x0, x0, :lo12:.L.str
	bl	l_puts
	mov	w0, #80                         // =0x50
	mov	w1, #40                         // =0x28
	mov	w2, #1                          // =0x1
	bl	l3d_create_context
	ldr	x8, [sp, #288]                  // 8-byte Folded Reload
	str	x0, [x8, #16]
	ldr	x8, [x8, #16]
	cbnz	x8, .LBB0_2
	b	.LBB0_1
.LBB0_1:
	adrp	x0, .L.str.1
	add	x0, x0, :lo12:.L.str.1
	bl	l_puts
	mov	w8, #1                          // =0x1
	stur	w8, [x29, #-4]
	b	.LBB0_11
.LBB0_2:
	adrp	x0, .L.str.2
	add	x0, x0, :lo12:.L.str.2
	bl	l_puts
	mov	x0, #2                          // =0x2
	mov	x1, xzr
	str	x1, [sp, #272]                  // 8-byte Folded Spill
	bl	l_sleep
	adrp	x0, .L.str.3
	add	x0, x0, :lo12:.L.str.3
	bl	l_puts
	ldr	x8, [sp, #288]                  // 8-byte Folded Reload
	ldr	x0, [x8, #16]
	mov	w1, #32                         // =0x20
	mov	w2, wzr
	bl	l3d_clear
	ldr	x8, [sp, #288]                  // 8-byte Folded Reload
	str	xzr, [x8]
	stur	wzr, [x29, #-24]
	ldr	x8, [x8, #16]
	str	x8, [sp, #128]                  // 8-byte Folded Spill
	fmov	s0, #5.00000000
	str	s0, [sp, #148]                  // 4-byte Folded Spill
	movi	d2, #0000000000000000
	str	s2, [sp, #284]                  // 4-byte Folded Spill
	fmov	s1, s2
	bl	l3d_vec3_create
	ldr	x0, [sp, #128]                  // 8-byte Folded Reload
	stur	s0, [x29, #-44]
	stur	s1, [x29, #-40]
	stur	s2, [x29, #-36]
	ldur	s0, [x29, #-32]
	ldur	s1, [x29, #-28]
	ldur	s2, [x29, #-24]
	ldur	s3, [x29, #-44]
	ldur	s4, [x29, #-40]
	ldur	s5, [x29, #-36]
	mov	w1, #16711680                   // =0xff0000
	str	w1, [sp, #180]                  // 4-byte Folded Spill
	bl	l3d_draw_line
	ldr	s1, [sp, #148]                  // 4-byte Folded Reload
	ldr	x8, [sp, #288]                  // 8-byte Folded Reload
	ldr	s2, [sp, #284]                  // 4-byte Folded Reload
	ldr	x8, [x8, #16]
	str	x8, [sp, #136]                  // 8-byte Folded Spill
	fmov	s0, s2
	bl	l3d_vec3_create
	ldr	x0, [sp, #136]                  // 8-byte Folded Reload
	stur	s0, [x29, #-56]
	stur	s1, [x29, #-52]
	stur	s2, [x29, #-48]
	ldur	s0, [x29, #-32]
	ldur	s1, [x29, #-28]
	ldur	s2, [x29, #-24]
	ldur	s3, [x29, #-56]
	ldur	s4, [x29, #-52]
	ldur	s5, [x29, #-48]
	mov	w1, #65280                      // =0xff00
	str	w1, [sp, #200]                  // 4-byte Folded Spill
	bl	l3d_draw_line
	ldr	s2, [sp, #148]                  // 4-byte Folded Reload
	ldr	x8, [sp, #288]                  // 8-byte Folded Reload
	ldr	s1, [sp, #284]                  // 4-byte Folded Reload
	ldr	x8, [x8, #16]
	str	x8, [sp, #152]                  // 8-byte Folded Spill
	fmov	s0, s1
	bl	l3d_vec3_create
	ldr	x0, [sp, #152]                  // 8-byte Folded Reload
	stur	s0, [x29, #-68]
	stur	s1, [x29, #-64]
	stur	s2, [x29, #-60]
	ldur	s0, [x29, #-32]
	ldur	s1, [x29, #-28]
	ldur	s2, [x29, #-24]
	ldur	s3, [x29, #-68]
	ldur	s4, [x29, #-64]
	ldur	s5, [x29, #-60]
	mov	w1, #255                        // =0xff
	str	w1, [sp, #224]                  // 4-byte Folded Spill
	bl	l3d_draw_line
	ldr	x8, [sp, #288]                  // 8-byte Folded Reload
	ldr	x0, [x8, #16]
	fmov	s0, #8.00000000
	mov	w1, #8                          // =0x8
	mov	w2, #13107                      // =0x3333
	movk	w2, #51, lsl #16
	bl	l3d_draw_grid
	ldr	x8, [sp, #288]                  // 8-byte Folded Reload
	ldr	s1, [sp, #284]                  // 4-byte Folded Reload
	ldr	x8, [x8, #16]
	str	x8, [sp, #160]                  // 8-byte Folded Spill
	fmov	s2, #-3.00000000
	str	s2, [sp, #204]                  // 4-byte Folded Spill
	fmov	s0, s2
	bl	l3d_vec3_create
	stur	s0, [x29, #-80]
	stur	s1, [x29, #-76]
	stur	s2, [x29, #-72]
	sub	x8, x29, #144
	str	x8, [sp, #168]                  // 8-byte Folded Spill
	bl	l3d_matrix_identity
	ldr	x0, [sp, #160]                  // 8-byte Folded Reload
	ldr	x1, [sp, #168]                  // 8-byte Folded Reload
	ldr	w2, [sp, #180]                  // 4-byte Folded Reload
	ldur	s0, [x29, #-80]
	ldur	s1, [x29, #-76]
	ldur	s2, [x29, #-72]
	fmov	s3, #1.50000000
	str	s3, [sp, #244]                  // 4-byte Folded Spill
	bl	l3d_draw_cube
	ldr	s2, [sp, #204]                  // 4-byte Folded Reload
	ldr	x8, [sp, #288]                  // 8-byte Folded Reload
	ldr	s1, [sp, #284]                  // 4-byte Folded Reload
	ldr	x8, [x8, #16]
	str	x8, [sp, #184]                  // 8-byte Folded Spill
	fmov	s0, #3.00000000
	str	s0, [sp, #260]                  // 4-byte Folded Spill
	bl	l3d_vec3_create
	stur	s0, [x29, #-156]
	stur	s1, [x29, #-152]
	stur	s2, [x29, #-148]
	sub	x8, x29, #220
	str	x8, [sp, #192]                  // 8-byte Folded Spill
	fmov	s0, #1.00000000
	str	s0, [sp, #228]                  // 4-byte Folded Spill
	bl	l3d_matrix_rotate_y
	ldr	x0, [sp, #184]                  // 8-byte Folded Reload
	ldr	x1, [sp, #192]                  // 8-byte Folded Reload
	ldr	w2, [sp, #200]                  // 4-byte Folded Reload
	ldr	s3, [sp, #244]                  // 4-byte Folded Reload
	ldur	s0, [x29, #-156]
	ldur	s1, [x29, #-152]
	ldur	s2, [x29, #-148]
	bl	l3d_draw_cube
	ldr	s0, [sp, #204]                  // 4-byte Folded Reload
	ldr	s2, [sp, #260]                  // 4-byte Folded Reload
	ldr	x8, [sp, #288]                  // 8-byte Folded Reload
	ldr	s1, [sp, #284]                  // 4-byte Folded Reload
	ldr	x8, [x8, #16]
	str	x8, [sp, #208]                  // 8-byte Folded Spill
	bl	l3d_vec3_create
	fmov	s3, s0
	ldr	s0, [sp, #228]                  // 4-byte Folded Reload
	stur	s3, [x29, #-232]
	stur	s1, [x29, #-228]
	stur	s2, [x29, #-224]
	add	x8, sp, #840
	str	x8, [sp, #216]                  // 8-byte Folded Spill
	bl	l3d_matrix_rotate_x
	ldr	x0, [sp, #208]                  // 8-byte Folded Reload
	ldr	x1, [sp, #216]                  // 8-byte Folded Reload
	ldr	w2, [sp, #224]                  // 4-byte Folded Reload
	ldr	s3, [sp, #244]                  // 4-byte Folded Reload
	ldur	s0, [x29, #-232]
	ldur	s1, [x29, #-228]
	ldur	s2, [x29, #-224]
	bl	l3d_draw_cube
	ldr	s2, [sp, #260]                  // 4-byte Folded Reload
	ldr	x8, [sp, #288]                  // 8-byte Folded Reload
	ldr	s1, [sp, #284]                  // 4-byte Folded Reload
	ldr	x8, [x8, #16]
	str	x8, [sp, #232]                  // 8-byte Folded Spill
	fmov	s0, s2
	bl	l3d_vec3_create
	fmov	s3, s0
	ldr	s0, [sp, #228]                  // 4-byte Folded Reload
	str	s3, [sp, #828]
	str	s1, [sp, #832]
	str	s2, [sp, #836]
	add	x8, sp, #764
	str	x8, [sp, #248]                  // 8-byte Folded Spill
	bl	l3d_matrix_rotate_z
	ldr	x0, [sp, #232]                  // 8-byte Folded Reload
	ldr	s3, [sp, #244]                  // 4-byte Folded Reload
	ldr	x1, [sp, #248]                  // 8-byte Folded Reload
	ldr	s0, [sp, #828]
	ldr	s1, [sp, #832]
	ldr	s2, [sp, #836]
	mov	w2, #16776960                   // =0xffff00
	bl	l3d_draw_cube
	ldr	s1, [sp, #260]                  // 4-byte Folded Reload
	ldr	x8, [sp, #288]                  // 8-byte Folded Reload
	ldr	s2, [sp, #284]                  // 4-byte Folded Reload
	ldr	x8, [x8, #16]
	str	x8, [sp, #264]                  // 8-byte Folded Spill
	fmov	s0, s2
	bl	l3d_vec3_create
	ldr	x0, [sp, #264]                  // 8-byte Folded Reload
	str	s0, [sp, #752]
	str	s1, [sp, #756]
	str	s2, [sp, #760]
	ldr	s0, [sp, #752]
	ldr	s1, [sp, #756]
	ldr	s2, [sp, #760]
	fmov	s3, #2.00000000
	mov	w1, #16                         // =0x10
	mov	w2, #16711935                   // =0xff00ff
	bl	l3d_draw_sphere
	ldr	x8, [sp, #288]                  // 8-byte Folded Reload
	ldr	x0, [x8, #16]
	bl	l3d_render
	adrp	x0, .L.str.4
	add	x0, x0, :lo12:.L.str.4
	bl	l_puts
	ldr	x1, [sp, #272]                  // 8-byte Folded Reload
	mov	x0, #3                          // =0x3
	bl	l_sleep
	adrp	x0, .L.str.5
	add	x0, x0, :lo12:.L.str.5
	bl	l_puts
	ldr	s0, [sp, #284]                  // 4-byte Folded Reload
	str	s0, [sp, #748]
	str	wzr, [sp, #744]
	b	.LBB0_3
.LBB0_3:                                // =>This Loop Header: Depth=1
                                        //     Child Loop BB0_5 Depth 2
	ldr	w8, [sp, #744]
	subs	w8, w8, #60
	b.ge	.LBB0_10
	b	.LBB0_4
.LBB0_4:                                //   in Loop: Header=BB0_3 Depth=1
	ldr	x8, [sp, #288]                  // 8-byte Folded Reload
	ldr	x0, [x8, #16]
	mov	w1, #46                         // =0x2e
	mov	w2, wzr
	bl	l3d_clear
	ldr	s0, [sp, #748]
	add	x8, sp, #680
	str	x8, [sp, #16]                   // 8-byte Folded Spill
	bl	l3d_matrix_rotate_y
	ldr	s0, [sp, #748]
	mov	w8, #39322                      // =0x999a
	movk	w8, #16025, lsl #16
	fmov	s1, w8
	fmul	s0, s0, s1
	add	x8, sp, #616
	str	x8, [sp, #24]                   // 8-byte Folded Spill
	bl	l3d_matrix_rotate_x
	ldr	x1, [sp, #16]                   // 8-byte Folded Reload
	add	x0, sp, #488
	str	x0, [sp, #32]                   // 8-byte Folded Spill
	mov	x2, #64                         // =0x40
	str	x2, [sp, #88]                   // 8-byte Folded Spill
	bl	memcpy
	ldr	x1, [sp, #24]                   // 8-byte Folded Reload
	ldr	x2, [sp, #88]                   // 8-byte Folded Reload
	add	x0, sp, #424
	str	x0, [sp, #40]                   // 8-byte Folded Spill
	bl	memcpy
	ldr	x0, [sp, #32]                   // 8-byte Folded Reload
	ldr	x1, [sp, #40]                   // 8-byte Folded Reload
	add	x8, sp, #552
	str	x8, [sp, #80]                   // 8-byte Folded Spill
	bl	l3d_matrix_mul
	ldr	x8, [sp, #288]                  // 8-byte Folded Reload
	ldr	x8, [x8, #16]
	str	x8, [sp, #48]                   // 8-byte Folded Spill
	fmov	s0, #4.00000000
	str	s0, [sp, #68]                   // 4-byte Folded Spill
	movi	d2, #0000000000000000
	str	s2, [sp, #64]                   // 4-byte Folded Spill
	fmov	s1, s2
	bl	l3d_vec3_create
	ldr	x0, [sp, #48]                   // 8-byte Folded Reload
	str	s0, [sp, #412]
	str	s1, [sp, #416]
	str	s2, [sp, #420]
	ldur	s0, [x29, #-32]
	ldur	s1, [x29, #-28]
	ldur	s2, [x29, #-24]
	ldr	s3, [sp, #412]
	ldr	s4, [sp, #416]
	ldr	s5, [sp, #420]
	mov	w1, #16711680                   // =0xff0000
	bl	l3d_draw_line
	ldr	s2, [sp, #64]                   // 4-byte Folded Reload
	ldr	s1, [sp, #68]                   // 4-byte Folded Reload
	ldr	x8, [sp, #288]                  // 8-byte Folded Reload
	ldr	x8, [x8, #16]
	str	x8, [sp, #56]                   // 8-byte Folded Spill
	fmov	s0, s2
	bl	l3d_vec3_create
	ldr	x0, [sp, #56]                   // 8-byte Folded Reload
	str	s0, [sp, #400]
	str	s1, [sp, #404]
	str	s2, [sp, #408]
	ldur	s0, [x29, #-32]
	ldur	s1, [x29, #-28]
	ldur	s2, [x29, #-24]
	ldr	s3, [sp, #400]
	ldr	s4, [sp, #404]
	ldr	s5, [sp, #408]
	mov	w1, #65280                      // =0xff00
	bl	l3d_draw_line
	ldr	s1, [sp, #64]                   // 4-byte Folded Reload
	ldr	s2, [sp, #68]                   // 4-byte Folded Reload
	ldr	x8, [sp, #288]                  // 8-byte Folded Reload
	ldr	x8, [x8, #16]
	str	x8, [sp, #72]                   // 8-byte Folded Spill
	fmov	s0, s1
	bl	l3d_vec3_create
	ldr	x0, [sp, #72]                   // 8-byte Folded Reload
	str	s0, [sp, #388]
	str	s1, [sp, #392]
	str	s2, [sp, #396]
	ldur	s0, [x29, #-32]
	ldur	s1, [x29, #-28]
	ldur	s2, [x29, #-24]
	ldr	s3, [sp, #388]
	ldr	s4, [sp, #392]
	ldr	s5, [sp, #396]
	mov	w1, #255                        // =0xff
	bl	l3d_draw_line
	ldr	x8, [sp, #288]                  // 8-byte Folded Reload
	ldr	x1, [sp, #80]                   // 8-byte Folded Reload
	ldr	x2, [sp, #88]                   // 8-byte Folded Reload
	ldr	x8, [x8, #16]
	str	x8, [sp, #96]                   // 8-byte Folded Spill
	ldur	s0, [x29, #-32]
	str	s0, [sp, #108]                  // 4-byte Folded Spill
	ldur	s0, [x29, #-28]
	str	s0, [sp, #112]                  // 4-byte Folded Spill
	ldur	s0, [x29, #-24]
	str	s0, [sp, #116]                  // 4-byte Folded Spill
	add	x0, sp, #324
	str	x0, [sp, #120]                  // 8-byte Folded Spill
	bl	memcpy
	ldr	x0, [sp, #96]                   // 8-byte Folded Reload
	ldr	s0, [sp, #108]                  // 4-byte Folded Reload
	ldr	s1, [sp, #112]                  // 4-byte Folded Reload
	ldr	s2, [sp, #116]                  // 4-byte Folded Reload
	ldr	x1, [sp, #120]                  // 8-byte Folded Reload
	fmov	s3, #2.50000000
	mov	w2, #16777215                   // =0xffffff
	bl	l3d_draw_cube
	str	wzr, [sp, #320]
	b	.LBB0_5
.LBB0_5:                                //   Parent Loop BB0_3 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #320]
	subs	w8, w8, #8
	b.ge	.LBB0_8
	b	.LBB0_6
.LBB0_6:                                //   in Loop: Header=BB0_5 Depth=2
	ldr	s2, [sp, #748]
	ldr	s0, [sp, #320]
	scvtf	s0, s0
	mov	w8, #62915                      // =0xf5c3
	movk	w8, #16200, lsl #16
	fmov	s1, w8
	fmadd	s0, s0, s1, s2
	str	s0, [sp, #316]
	fmov	s0, #5.00000000
	str	s0, [sp, #312]
	ldr	s0, [sp, #316]
	bl	l3d_fcos
	ldr	s1, [sp, #312]
	fmul	s0, s0, s1
	str	s0, [sp, #300]
	ldr	s0, [sp, #316]
	fmov	s1, #2.00000000
	str	s1, [sp, #12]                   // 4-byte Folded Spill
	fmul	s0, s0, s1
	bl	l3d_fsin
	ldr	s1, [sp, #12]                   // 4-byte Folded Reload
	fmul	s0, s0, s1
	str	s0, [sp, #304]
	ldr	s0, [sp, #316]
	bl	l3d_fsin
	ldr	x8, [sp, #288]                  // 8-byte Folded Reload
	ldr	s1, [sp, #312]
	fmul	s0, s0, s1
	str	s0, [sp, #308]
	ldr	x0, [x8, #16]
	ldr	s0, [sp, #300]
	ldr	s1, [sp, #304]
	ldr	s2, [sp, #308]
	mov	w8, #39322                      // =0x999a
	movk	w8, #16153, lsl #16
	fmov	s3, w8
	mov	w1, #10                         // =0xa
	mov	w2, #65535                      // =0xffff
	bl	l3d_draw_sphere
	b	.LBB0_7
.LBB0_7:                                //   in Loop: Header=BB0_5 Depth=2
	ldr	w8, [sp, #320]
	add	w8, w8, #1
	str	w8, [sp, #320]
	b	.LBB0_5
.LBB0_8:                                //   in Loop: Header=BB0_3 Depth=1
	ldr	x8, [sp, #288]                  // 8-byte Folded Reload
	ldr	x0, [x8, #16]
	bl	l3d_render
	ldr	s0, [sp, #748]
	mov	w8, #52429                      // =0xcccd
	movk	w8, #15820, lsl #16
	fmov	s1, w8
	fadd	s0, s0, s1
	str	s0, [sp, #748]
	mov	x0, xzr
	mov	x1, #57600                      // =0xe100
	movk	x1, #1525, lsl #16
	bl	l_sleep
	b	.LBB0_9
.LBB0_9:                                //   in Loop: Header=BB0_3 Depth=1
	ldr	w8, [sp, #744]
	add	w8, w8, #1
	str	w8, [sp, #744]
	b	.LBB0_3
.LBB0_10:
	ldr	x8, [sp, #288]                  // 8-byte Folded Reload
	ldr	x0, [x8, #16]
	bl	l3d_destroy_context
	adrp	x0, .L.str.6
	add	x0, x0, :lo12:.L.str.6
	bl	l_puts
	adrp	x0, .L.str.7
	add	x0, x0, :lo12:.L.str.7
	bl	l_puts
	stur	wzr, [x29, #-4]
	b	.LBB0_11
.LBB0_11:
	ldur	w0, [x29, #-4]
	add	sp, sp, #1136
	.cfi_def_cfa wsp, 32
	ldr	x28, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w28
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end0:
	.size	main, .Lfunc_end0-main
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function l_puts
	.type	l_puts,@function
l_puts:                                 // @l_puts
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	wzr, [sp, #4]
	b	.LBB1_1
.LBB1_1:                                // =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #8]
	ldrsw	x9, [sp, #4]
	add	x8, x8, x9
	ldrb	w8, [x8]
	cbz	w8, .LBB1_3
	b	.LBB1_2
.LBB1_2:                                //   in Loop: Header=BB1_1 Depth=1
	ldr	w8, [sp, #4]
	add	w8, w8, #1
	str	w8, [sp, #4]
	b	.LBB1_1
.LBB1_3:
	ldr	x1, [sp, #8]
	ldr	w2, [sp, #4]
	mov	w0, #1                          // =0x1
	bl	l_write
	mov	w0, #10                         // =0xa
	bl	l_putchar
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end1:
	.size	l_puts, .Lfunc_end1-l_puts
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function l3d_create_context
	.type	l3d_create_context,@function
l3d_create_context:                     // @l3d_create_context
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #128
	.cfi_def_cfa_offset 128
	stp	x29, x30, [sp, #112]            // 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	w0, [x29, #-12]
	stur	w1, [x29, #-16]
	stur	w2, [x29, #-20]
	mov	w0, #96                         // =0x60
	bl	l_malloc
	stur	x0, [x29, #-32]
	b	.LBB2_1
.LBB2_1:
	ldur	x8, [x29, #-32]
	cbnz	x8, .LBB2_3
	b	.LBB2_2
.LBB2_2:
                                        // kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	.LBB2_13
.LBB2_3:
	b	.LBB2_4
.LBB2_4:
	ldur	w8, [x29, #-12]
	ldur	x9, [x29, #-32]
	str	w8, [x9]
	ldur	w8, [x29, #-16]
	ldur	x9, [x29, #-32]
	str	w8, [x9, #4]
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-32]
	str	w8, [x9, #8]
	ldur	x8, [x29, #-32]
	str	wzr, [x8, #12]
	ldur	w8, [x29, #-12]
	ldur	w9, [x29, #-16]
	mul	w8, w8, w9
	stur	w8, [x29, #-36]
	ldur	w8, [x29, #-36]
	add	w0, w8, #1
	bl	l_malloc
	ldur	x8, [x29, #-32]
	str	x0, [x8, #16]
	ldur	x8, [x29, #-32]
	ldr	x8, [x8, #16]
	cbz	x8, .LBB2_6
	b	.LBB2_5
.LBB2_5:
	ldur	x8, [x29, #-32]
	ldr	x8, [x8, #16]
	ldursw	x9, [x29, #-36]
	add	x8, x8, x9
	strb	wzr, [x8]
	b	.LBB2_6
.LBB2_6:
	ldursw	x8, [x29, #-36]
	lsl	x8, x8, #2
	mov	w0, w8
	bl	l_malloc
	ldur	x8, [x29, #-32]
	str	x0, [x8, #24]
	ldur	x8, [x29, #-32]
	ldr	x8, [x8, #24]
	cbz	x8, .LBB2_12
	b	.LBB2_7
.LBB2_7:
	stur	wzr, [x29, #-40]
	b	.LBB2_8
.LBB2_8:                                // =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-40]
	ldur	w9, [x29, #-36]
	subs	w8, w8, w9
	b.ge	.LBB2_11
	b	.LBB2_9
.LBB2_9:                                //   in Loop: Header=BB2_8 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x8, [x8, #24]
	ldursw	x9, [x29, #-40]
	mov	w10, #1148846080                // =0x447a0000
	fmov	s0, w10
	str	s0, [x8, x9, lsl #2]
	b	.LBB2_10
.LBB2_10:                               //   in Loop: Header=BB2_8 Depth=1
	ldur	w8, [x29, #-40]
	add	w8, w8, #1
	stur	w8, [x29, #-40]
	b	.LBB2_8
.LBB2_11:
	b	.LBB2_12
.LBB2_12:
	ldursw	x8, [x29, #-36]
	lsl	x8, x8, #2
	mov	w0, w8
	bl	l_malloc
	ldur	x8, [x29, #-32]
	str	x0, [x8, #32]
	ldur	x8, [x29, #-32]
	str	x8, [sp]                        // 8-byte Folded Spill
	movi	d1, #0000000000000000
	str	s1, [sp, #20]                   // 4-byte Folded Spill
	fmov	s0, s1
	fmov	s2, #5.00000000
	bl	l3d_vec3_create
	ldr	x9, [sp]                        // 8-byte Folded Reload
	fmov	s3, s0
	fmov	s0, s2
	ldr	s2, [sp, #20]                   // 4-byte Folded Reload
	stur	s3, [x29, #-52]
	stur	s1, [x29, #-48]
	stur	s0, [x29, #-44]
	ldur	x8, [x29, #-52]
	str	x8, [x9, #40]
	ldur	w8, [x29, #-44]
	str	w8, [x9, #48]
	ldur	x8, [x29, #-32]
	str	x8, [sp, #8]                    // 8-byte Folded Spill
	fmov	s0, s2
	fmov	s1, s2
	bl	l3d_vec3_create
	ldr	x9, [sp, #8]                    // 8-byte Folded Reload
	fmov	s3, s0
	fmov	s0, s2
	ldr	s2, [sp, #20]                   // 4-byte Folded Reload
	str	s3, [sp, #48]
	str	s1, [sp, #52]
	str	s0, [sp, #56]
	ldr	x8, [sp, #48]
	stur	x8, [x9, #52]
	ldr	w8, [sp, #56]
	str	w8, [x9, #60]
	ldur	x8, [x29, #-32]
	str	x8, [sp, #24]                   // 8-byte Folded Spill
	fmov	s0, s2
	fmov	s1, #1.00000000
	bl	l3d_vec3_create
	ldr	x9, [sp, #24]                   // 8-byte Folded Reload
	str	s0, [sp, #36]
	str	s1, [sp, #40]
	str	s2, [sp, #44]
	ldur	x8, [sp, #36]
	str	x8, [x9, #64]
	ldr	w8, [sp, #44]
	str	w8, [x9, #72]
	ldur	x8, [x29, #-32]
	mov	w9, #1114636288                 // =0x42700000
	fmov	s0, w9
	str	s0, [x8, #76]
	ldur	s0, [x29, #-12]
	scvtf	s0, s0
	ldur	s1, [x29, #-16]
	scvtf	s1, s1
	fdiv	s0, s0, s1
	ldur	x8, [x29, #-32]
	str	s0, [x8, #80]
	ldur	x8, [x29, #-32]
	mov	w9, #52429                      // =0xcccd
	movk	w9, #15820, lsl #16
	fmov	s0, w9
	str	s0, [x8, #84]
	ldur	x8, [x29, #-32]
	mov	w9, #1120403456                 // =0x42c80000
	fmov	s0, w9
	str	s0, [x8, #88]
	ldur	x8, [x29, #-32]
	stur	x8, [x29, #-8]
	b	.LBB2_13
.LBB2_13:
	ldur	x0, [x29, #-8]
	.cfi_def_cfa wsp, 128
	ldp	x29, x30, [sp, #112]            // 16-byte Folded Reload
	add	sp, sp, #128
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end2:
	.size	l3d_create_context, .Lfunc_end2-l3d_create_context
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function l_sleep
	.type	l_sleep,@function
l_sleep:                                // @l_sleep
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #64
	.cfi_def_cfa_offset 64
	stp	x29, x30, [sp, #48]             // 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	x1, [x29, #-16]
	ldur	x8, [x29, #-8]
	add	x1, sp, #16
	str	x8, [sp, #16]
	ldur	x8, [x29, #-16]
	str	x8, [sp, #24]
	mov	x2, sp
	str	xzr, [sp]
	str	xzr, [sp, #8]
	mov	x0, #101                        // =0x65
	mov	x6, xzr
	mov	x3, x6
	mov	x4, x6
	mov	x5, x6
	bl	l_syscall
                                        // kill: def $w0 killed $w0 killed $x0
	.cfi_def_cfa wsp, 64
	ldp	x29, x30, [sp, #48]             // 16-byte Folded Reload
	add	sp, sp, #64
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end3:
	.size	l_sleep, .Lfunc_end3-l_sleep
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function l3d_clear
	.type	l3d_clear,@function
l3d_clear:                              // @l3d_clear
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #24]
	strb	w1, [sp, #23]
	str	w2, [sp, #16]
	ldr	x8, [sp, #24]
	cbnz	x8, .LBB4_2
	b	.LBB4_1
.LBB4_1:
	b	.LBB4_20
.LBB4_2:
	ldr	x8, [sp, #24]
	ldr	w8, [x8]
	ldr	x9, [sp, #24]
	ldr	w9, [x9, #4]
	mul	w8, w8, w9
	str	w8, [sp, #12]
	ldr	x8, [sp, #24]
	ldr	x8, [x8, #16]
	cbz	x8, .LBB4_8
	b	.LBB4_3
.LBB4_3:
	str	wzr, [sp, #8]
	b	.LBB4_4
.LBB4_4:                                // =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #8]
	ldr	w9, [sp, #12]
	subs	w8, w8, w9
	b.ge	.LBB4_7
	b	.LBB4_5
.LBB4_5:                                //   in Loop: Header=BB4_4 Depth=1
	ldrb	w8, [sp, #23]
	ldr	x9, [sp, #24]
	ldr	x9, [x9, #16]
	ldrsw	x10, [sp, #8]
	add	x9, x9, x10
	strb	w8, [x9]
	b	.LBB4_6
.LBB4_6:                                //   in Loop: Header=BB4_4 Depth=1
	ldr	w8, [sp, #8]
	add	w8, w8, #1
	str	w8, [sp, #8]
	b	.LBB4_4
.LBB4_7:
	b	.LBB4_8
.LBB4_8:
	ldr	x8, [sp, #24]
	ldr	x8, [x8, #24]
	cbz	x8, .LBB4_14
	b	.LBB4_9
.LBB4_9:
	str	wzr, [sp, #4]
	b	.LBB4_10
.LBB4_10:                               // =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #4]
	ldr	w9, [sp, #12]
	subs	w8, w8, w9
	b.ge	.LBB4_13
	b	.LBB4_11
.LBB4_11:                               //   in Loop: Header=BB4_10 Depth=1
	ldr	x8, [sp, #24]
	ldr	x8, [x8, #24]
	ldrsw	x9, [sp, #4]
	mov	w10, #1148846080                // =0x447a0000
	fmov	s0, w10
	str	s0, [x8, x9, lsl #2]
	b	.LBB4_12
.LBB4_12:                               //   in Loop: Header=BB4_10 Depth=1
	ldr	w8, [sp, #4]
	add	w8, w8, #1
	str	w8, [sp, #4]
	b	.LBB4_10
.LBB4_13:
	b	.LBB4_14
.LBB4_14:
	ldr	x8, [sp, #24]
	ldr	x8, [x8, #32]
	cbz	x8, .LBB4_20
	b	.LBB4_15
.LBB4_15:
	str	wzr, [sp]
	b	.LBB4_16
.LBB4_16:                               // =>This Inner Loop Header: Depth=1
	ldr	w8, [sp]
	ldr	w9, [sp, #12]
	subs	w8, w8, w9
	b.ge	.LBB4_19
	b	.LBB4_17
.LBB4_17:                               //   in Loop: Header=BB4_16 Depth=1
	ldr	w8, [sp, #16]
	ldr	x9, [sp, #24]
	ldr	x9, [x9, #32]
	ldrsw	x10, [sp]
	str	w8, [x9, x10, lsl #2]
	b	.LBB4_18
.LBB4_18:                               //   in Loop: Header=BB4_16 Depth=1
	ldr	w8, [sp]
	add	w8, w8, #1
	str	w8, [sp]
	b	.LBB4_16
.LBB4_19:
	b	.LBB4_20
.LBB4_20:
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end4:
	.size	l3d_clear, .Lfunc_end4-l3d_clear
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function l3d_draw_line
	.type	l3d_draw_line,@function
l3d_draw_line:                          // @l3d_draw_line
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #128
	.cfi_def_cfa_offset 128
	stp	x29, x30, [sp, #112]            // 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	s0, [x29, #-12]
	stur	s1, [x29, #-8]
	stur	s2, [x29, #-4]
	stur	s3, [x29, #-24]
	stur	s4, [x29, #-20]
	stur	s5, [x29, #-16]
	stur	x0, [x29, #-32]
	stur	w1, [x29, #-36]
	ldur	x8, [x29, #-32]
	cbnz	x8, .LBB5_2
	b	.LBB5_1
.LBB5_1:
	b	.LBB5_15
.LBB5_2:
	ldur	s0, [x29, #-12]
	fmov	s3, #1.00000000
	fadd	s0, s0, s3
	fcvt	d0, s0
	fmov	d1, #0.50000000
	fmul	d0, d0, d1
	ldur	x8, [x29, #-32]
	ldr	s2, [x8]
	fmov	w8, s2
	scvtf	d2, w8
	fmul	d0, d0, d2
	fcvtzs	w8, d0
	stur	w8, [x29, #-40]
	ldur	s0, [x29, #-8]
	fadd	s0, s0, s3
	fcvt	d0, s0
	fmov	d2, #1.00000000
	fmsub	d0, d0, d1, d2
	ldur	x8, [x29, #-32]
	ldr	s4, [x8, #4]
	fmov	w8, s4
	scvtf	d4, w8
	fmul	d0, d0, d4
	fcvtzs	w8, d0
	stur	w8, [x29, #-44]
	ldur	s0, [x29, #-24]
	fadd	s0, s0, s3
	fcvt	d0, s0
	fmul	d0, d0, d1
	ldur	x8, [x29, #-32]
	ldr	s4, [x8]
	fmov	w8, s4
	scvtf	d4, w8
	fmul	d0, d0, d4
	fcvtzs	w8, d0
	stur	w8, [x29, #-48]
	ldur	s0, [x29, #-20]
	fadd	s0, s0, s3
	fcvt	d0, s0
	fmsub	d0, d0, d1, d2
	ldur	x8, [x29, #-32]
	ldr	s1, [x8, #4]
	fmov	w8, s1
	scvtf	d1, w8
	fmul	d0, d0, d1
	fcvtzs	w8, d0
	stur	w8, [x29, #-52]
	ldur	s0, [x29, #-4]
	str	s0, [sp, #56]
	ldur	s0, [x29, #-16]
	str	s0, [sp, #52]
	ldur	w8, [x29, #-48]
	ldur	w9, [x29, #-40]
	subs	w8, w8, w9
	str	w8, [sp, #48]
	ldur	w8, [x29, #-52]
	ldur	w9, [x29, #-44]
	subs	w8, w8, w9
	str	w8, [sp, #44]
	str	wzr, [sp, #40]
	ldr	w8, [sp, #48]
	tbz	w8, #31, .LBB5_4
	b	.LBB5_3
.LBB5_3:
	ldr	w9, [sp, #48]
	mov	w8, wzr
	subs	w8, w8, w9
	str	w8, [sp, #48]
	b	.LBB5_4
.LBB5_4:
	ldr	w8, [sp, #44]
	tbz	w8, #31, .LBB5_6
	b	.LBB5_5
.LBB5_5:
	ldr	w9, [sp, #44]
	mov	w8, wzr
	subs	w8, w8, w9
	str	w8, [sp, #44]
	b	.LBB5_6
.LBB5_6:
	ldr	w8, [sp, #48]
	ldr	w9, [sp, #44]
	subs	w8, w8, w9
	b.le	.LBB5_8
	b	.LBB5_7
.LBB5_7:
	ldr	w8, [sp, #48]
	str	w8, [sp, #40]
	b	.LBB5_9
.LBB5_8:
	ldr	w8, [sp, #44]
	str	w8, [sp, #40]
	b	.LBB5_9
.LBB5_9:
	ldr	w8, [sp, #40]
	cbnz	w8, .LBB5_11
	b	.LBB5_10
.LBB5_10:
	ldur	x0, [x29, #-32]
	ldur	w1, [x29, #-40]
	ldur	w2, [x29, #-44]
	ldr	s0, [sp, #56]
	ldr	s1, [sp, #52]
	fadd	s0, s0, s1
	fmov	s1, #0.50000000
	fmul	s0, s0, s1
	ldur	w3, [x29, #-36]
	bl	l3d_draw_point
	b	.LBB5_15
.LBB5_11:
	ldr	s0, [sp, #48]
	scvtf	s0, s0
	ldr	s1, [sp, #40]
	scvtf	s1, s1
	fdiv	s0, s0, s1
	str	s0, [sp, #36]
	ldr	s0, [sp, #44]
	scvtf	s0, s0
	ldr	s1, [sp, #40]
	scvtf	s1, s1
	fdiv	s0, s0, s1
	str	s0, [sp, #32]
	ldr	s0, [sp, #52]
	ldr	s1, [sp, #56]
	fsub	s0, s0, s1
	ldr	s1, [sp, #40]
	scvtf	s1, s1
	fdiv	s0, s0, s1
	str	s0, [sp, #28]
	ldur	s0, [x29, #-40]
	scvtf	s0, s0
	str	s0, [sp, #24]
	ldur	s0, [x29, #-44]
	scvtf	s0, s0
	str	s0, [sp, #20]
	ldr	s0, [sp, #56]
	str	s0, [sp, #16]
	str	wzr, [sp, #12]
	b	.LBB5_12
.LBB5_12:                               // =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #12]
	ldr	w9, [sp, #40]
	subs	w8, w8, w9
	b.gt	.LBB5_15
	b	.LBB5_13
.LBB5_13:                               //   in Loop: Header=BB5_12 Depth=1
	ldur	x0, [x29, #-32]
	ldr	s0, [sp, #24]
	fcvtzs	w1, s0
	ldr	s0, [sp, #20]
	fcvtzs	w2, s0
	ldr	s0, [sp, #16]
	ldur	w3, [x29, #-36]
	bl	l3d_draw_point
	ldr	s1, [sp, #36]
	ldr	s0, [sp, #24]
	fadd	s0, s0, s1
	str	s0, [sp, #24]
	ldr	s1, [sp, #32]
	ldr	s0, [sp, #20]
	fadd	s0, s0, s1
	str	s0, [sp, #20]
	ldr	s1, [sp, #28]
	ldr	s0, [sp, #16]
	fadd	s0, s0, s1
	str	s0, [sp, #16]
	b	.LBB5_14
.LBB5_14:                               //   in Loop: Header=BB5_12 Depth=1
	ldr	w8, [sp, #12]
	add	w8, w8, #1
	str	w8, [sp, #12]
	b	.LBB5_12
.LBB5_15:
	.cfi_def_cfa wsp, 128
	ldp	x29, x30, [sp, #112]            // 16-byte Folded Reload
	add	sp, sp, #128
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end5:
	.size	l3d_draw_line, .Lfunc_end5-l3d_draw_line
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function l3d_vec3_create
	.type	l3d_vec3_create,@function
l3d_vec3_create:                        // @l3d_vec3_create
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	s0, [sp, #16]
	str	s1, [sp, #12]
	str	s2, [sp, #8]
	ldr	s0, [sp, #16]
	str	s0, [sp, #20]
	ldr	s0, [sp, #12]
	str	s0, [sp, #24]
	ldr	s0, [sp, #8]
	str	s0, [sp, #28]
	ldr	s0, [sp, #20]
	ldr	s1, [sp, #24]
	ldr	s2, [sp, #28]
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end6:
	.size	l3d_vec3_create, .Lfunc_end6-l3d_vec3_create
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function l3d_draw_grid
	.type	l3d_draw_grid,@function
l3d_draw_grid:                          // @l3d_draw_grid
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #112
	.cfi_def_cfa_offset 112
	stp	x29, x30, [sp, #96]             // 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	s0, [x29, #-12]
	stur	w1, [x29, #-16]
	stur	w2, [x29, #-20]
	ldur	x8, [x29, #-8]
	cbnz	x8, .LBB7_2
	b	.LBB7_1
.LBB7_1:
	b	.LBB7_6
.LBB7_2:
	ldur	s0, [x29, #-12]
	ldur	s1, [x29, #-16]
	scvtf	s1, s1
	fdiv	s0, s0, s1
	stur	s0, [x29, #-24]
	ldur	s0, [x29, #-12]
	fmov	s1, #0.50000000
	fmul	s0, s0, s1
	stur	s0, [x29, #-28]
	stur	wzr, [x29, #-32]
	b	.LBB7_3
.LBB7_3:                                // =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-32]
	ldur	w9, [x29, #-16]
	subs	w8, w8, w9
	b.gt	.LBB7_6
	b	.LBB7_4
.LBB7_4:                                //   in Loop: Header=BB7_3 Depth=1
	ldur	s2, [x29, #-28]
	ldur	s0, [x29, #-32]
	scvtf	s0, s0
	ldur	s1, [x29, #-24]
	fnmsub	s0, s0, s1, s2
	stur	s0, [x29, #-36]
	ldur	s0, [x29, #-28]
	fneg	s0, s0
	str	s0, [sp, #48]
	movi	d0, #0000000000000000
	str	s0, [sp, #4]                    // 4-byte Folded Spill
	str	s0, [sp, #52]
	ldur	s1, [x29, #-36]
	str	s1, [sp, #56]
	ldur	s1, [x29, #-28]
	str	s1, [sp, #32]
	str	s0, [sp, #36]
	ldur	s0, [x29, #-36]
	str	s0, [sp, #40]
	ldur	x0, [x29, #-8]
	ldur	w1, [x29, #-20]
	ldr	s0, [sp, #48]
	ldr	s1, [sp, #52]
	ldr	s2, [sp, #56]
	ldr	s3, [sp, #32]
	ldr	s4, [sp, #36]
	ldr	s5, [sp, #40]
	bl	l3d_draw_line
	ldr	s1, [sp, #4]                    // 4-byte Folded Reload
	ldur	s0, [x29, #-36]
	ldur	s2, [x29, #-28]
	fneg	s2, s2
	bl	l3d_vec3_create
	fmov	s3, s0
	fmov	s0, s1
	ldr	s1, [sp, #4]                    // 4-byte Folded Reload
	str	s3, [sp, #20]
	str	s0, [sp, #24]
	str	s2, [sp, #28]
	ldur	x8, [sp, #20]
	str	x8, [sp, #48]
	ldr	w8, [sp, #28]
	str	w8, [sp, #56]
	ldur	s0, [x29, #-36]
	ldur	s2, [x29, #-28]
	bl	l3d_vec3_create
	str	s0, [sp, #8]
	str	s1, [sp, #12]
	str	s2, [sp, #16]
	ldr	x8, [sp, #8]
	str	x8, [sp, #32]
	ldr	w8, [sp, #16]
	str	w8, [sp, #40]
	ldur	x0, [x29, #-8]
	ldur	w1, [x29, #-20]
	ldr	s0, [sp, #48]
	ldr	s1, [sp, #52]
	ldr	s2, [sp, #56]
	ldr	s3, [sp, #32]
	ldr	s4, [sp, #36]
	ldr	s5, [sp, #40]
	bl	l3d_draw_line
	b	.LBB7_5
.LBB7_5:                                //   in Loop: Header=BB7_3 Depth=1
	ldur	w8, [x29, #-32]
	add	w8, w8, #1
	stur	w8, [x29, #-32]
	b	.LBB7_3
.LBB7_6:
	.cfi_def_cfa wsp, 112
	ldp	x29, x30, [sp, #96]             // 16-byte Folded Reload
	add	sp, sp, #112
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end7:
	.size	l3d_draw_grid, .Lfunc_end7-l3d_draw_grid
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function l3d_draw_cube
	.type	l3d_draw_cube,@function
l3d_draw_cube:                          // @l3d_draw_cube
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #432
	.cfi_def_cfa_offset 432
	stp	x29, x30, [sp, #400]            // 16-byte Folded Spill
	str	x28, [sp, #416]                 // 8-byte Folded Spill
	add	x29, sp, #400
	.cfi_def_cfa w29, 32
	.cfi_offset w28, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	str	x1, [sp, #56]                   // 8-byte Folded Spill
	stur	s0, [x29, #-12]
	stur	s1, [x29, #-8]
	stur	s2, [x29, #-4]
	stur	x0, [x29, #-24]
	stur	s3, [x29, #-28]
	stur	x1, [x29, #-40]
	stur	w2, [x29, #-44]
	ldur	x8, [x29, #-24]
	cbnz	x8, .LBB8_2
	b	.LBB8_1
.LBB8_1:
	b	.LBB8_10
.LBB8_2:
	ldur	s0, [x29, #-28]
	fmov	s1, #0.50000000
	fmul	s0, s0, s1
	stur	s0, [x29, #-48]
	ldur	s0, [x29, #-48]
	fneg	s0, s0
	stur	s0, [x29, #-144]
	ldur	s0, [x29, #-48]
	fneg	s0, s0
	stur	s0, [x29, #-140]
	ldur	s0, [x29, #-48]
	fneg	s0, s0
	stur	s0, [x29, #-136]
	ldur	s0, [x29, #-48]
	stur	s0, [x29, #-132]
	ldur	s0, [x29, #-48]
	fneg	s0, s0
	stur	s0, [x29, #-128]
	ldur	s0, [x29, #-48]
	fneg	s0, s0
	stur	s0, [x29, #-124]
	ldur	s0, [x29, #-48]
	stur	s0, [x29, #-120]
	ldur	s0, [x29, #-48]
	stur	s0, [x29, #-116]
	ldur	s0, [x29, #-48]
	fneg	s0, s0
	stur	s0, [x29, #-112]
	ldur	s0, [x29, #-48]
	fneg	s0, s0
	stur	s0, [x29, #-108]
	ldur	s0, [x29, #-48]
	stur	s0, [x29, #-104]
	ldur	s0, [x29, #-48]
	fneg	s0, s0
	stur	s0, [x29, #-100]
	ldur	s0, [x29, #-48]
	fneg	s0, s0
	stur	s0, [x29, #-96]
	ldur	s0, [x29, #-48]
	fneg	s0, s0
	stur	s0, [x29, #-92]
	ldur	s0, [x29, #-48]
	stur	s0, [x29, #-88]
	ldur	s0, [x29, #-48]
	stur	s0, [x29, #-84]
	ldur	s0, [x29, #-48]
	fneg	s0, s0
	stur	s0, [x29, #-80]
	ldur	s0, [x29, #-48]
	stur	s0, [x29, #-76]
	ldur	s0, [x29, #-48]
	stur	s0, [x29, #-72]
	ldur	s0, [x29, #-48]
	stur	s0, [x29, #-68]
	ldur	s0, [x29, #-48]
	stur	s0, [x29, #-64]
	ldur	s0, [x29, #-48]
	fneg	s0, s0
	stur	s0, [x29, #-60]
	ldur	s0, [x29, #-48]
	stur	s0, [x29, #-56]
	ldur	s0, [x29, #-48]
	stur	s0, [x29, #-52]
	stur	wzr, [x29, #-148]
	b	.LBB8_3
.LBB8_3:                                // =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-148]
	subs	w8, w8, #8
	b.ge	.LBB8_6
	b	.LBB8_4
.LBB8_4:                                //   in Loop: Header=BB8_3 Depth=1
	ldursw	x8, [x29, #-148]
	mov	x10, #12                        // =0xc
	str	x10, [sp, #8]                   // 8-byte Folded Spill
	mul	x11, x8, x10
	sub	x8, x29, #144
	str	x8, [sp, #16]                   // 8-byte Folded Spill
	mov	x9, x8
	add	x9, x9, x11
	str	x9, [sp]                        // 8-byte Folded Spill
	ldursw	x9, [x29, #-148]
	mul	x9, x9, x10
	add	x8, x8, x9
	ldr	s0, [x8]
	ldr	s1, [x8, #4]
	ldr	s2, [x8, #8]
	ldur	s3, [x29, #-12]
	ldur	s4, [x29, #-8]
	ldur	s5, [x29, #-4]
	bl	l3d_vec3_add
	ldr	x11, [sp]                       // 8-byte Folded Reload
	ldr	x10, [sp, #8]                   // 8-byte Folded Reload
	ldr	x8, [sp, #16]                   // 8-byte Folded Reload
	ldr	x1, [sp, #56]                   // 8-byte Folded Reload
	stur	s0, [x29, #-160]
	stur	s1, [x29, #-156]
	stur	s2, [x29, #-152]
	ldur	x9, [x29, #-160]
	str	x9, [x11]
	ldur	w9, [x29, #-152]
	str	w9, [x11, #8]
	ldursw	x9, [x29, #-148]
	mul	x11, x9, x10
	mov	x9, x8
	add	x9, x9, x11
	str	x9, [sp, #48]                   // 8-byte Folded Spill
	ldursw	x9, [x29, #-148]
	mul	x9, x9, x10
	add	x8, x8, x9
	ldr	s0, [x8]
	str	s0, [sp, #36]                   // 4-byte Folded Spill
	ldr	s0, [x8, #4]
	str	s0, [sp, #40]                   // 4-byte Folded Spill
	ldr	s0, [x8, #8]
	str	s0, [sp, #44]                   // 4-byte Folded Spill
	add	x0, sp, #164
	str	x0, [sp, #24]                   // 8-byte Folded Spill
	mov	x2, #64                         // =0x40
	bl	memcpy
	ldr	x0, [sp, #24]                   // 8-byte Folded Reload
	ldr	s0, [sp, #36]                   // 4-byte Folded Reload
	ldr	s1, [sp, #40]                   // 4-byte Folded Reload
	ldr	s2, [sp, #44]                   // 4-byte Folded Reload
	bl	l3d_vec3_transform
	ldr	x9, [sp, #48]                   // 8-byte Folded Reload
	stur	s0, [x29, #-172]
	stur	s1, [x29, #-168]
	stur	s2, [x29, #-164]
	ldur	x8, [x29, #-172]
	str	x8, [x9]
	ldur	w8, [x29, #-164]
	str	w8, [x9, #8]
	b	.LBB8_5
.LBB8_5:                                //   in Loop: Header=BB8_3 Depth=1
	ldur	w8, [x29, #-148]
	add	w8, w8, #1
	stur	w8, [x29, #-148]
	b	.LBB8_3
.LBB8_6:
	add	x0, sp, #68
	mov	x2, #96                         // =0x60
	adrp	x1, .L__const.l3d_draw_cube.edges
	add	x1, x1, :lo12:.L__const.l3d_draw_cube.edges
	bl	memcpy
	str	wzr, [sp, #64]
	b	.LBB8_7
.LBB8_7:                                // =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #64]
	subs	w8, w8, #12
	b.ge	.LBB8_10
	b	.LBB8_8
.LBB8_8:                                //   in Loop: Header=BB8_7 Depth=1
	ldur	x0, [x29, #-24]
	ldrsw	x8, [sp, #64]
	lsl	x8, x8, #3
	add	x10, sp, #68
	ldrsw	x8, [x10, x8]
	mov	x11, #12                        // =0xc
	mul	x12, x8, x11
	sub	x8, x29, #144
	mov	x9, x8
	add	x9, x9, x12
	ldrsw	x12, [sp, #64]
	add	x10, x10, x12, lsl #3
	ldrsw	x10, [x10, #4]
	mul	x10, x10, x11
	add	x8, x8, x10
	ldur	w1, [x29, #-44]
	ldr	s0, [x9]
	ldr	s1, [x9, #4]
	ldr	s2, [x9, #8]
	ldr	s3, [x8]
	ldr	s4, [x8, #4]
	ldr	s5, [x8, #8]
	bl	l3d_draw_line
	b	.LBB8_9
.LBB8_9:                                //   in Loop: Header=BB8_7 Depth=1
	ldr	w8, [sp, #64]
	add	w8, w8, #1
	str	w8, [sp, #64]
	b	.LBB8_7
.LBB8_10:
	.cfi_def_cfa wsp, 432
	ldr	x28, [sp, #416]                 // 8-byte Folded Reload
	ldp	x29, x30, [sp, #400]            // 16-byte Folded Reload
	add	sp, sp, #432
	.cfi_def_cfa_offset 0
	.cfi_restore w28
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end8:
	.size	l3d_draw_cube, .Lfunc_end8-l3d_draw_cube
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function l3d_matrix_rotate_y
	.type	l3d_matrix_rotate_y,@function
l3d_matrix_rotate_y:                    // @l3d_matrix_rotate_y
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x8, [sp, #8]                    // 8-byte Folded Spill
	stur	s0, [x29, #-4]
	bl	l3d_matrix_identity
	ldur	s0, [x29, #-4]
	bl	l3d_fcos
	stur	s0, [x29, #-8]
	ldur	s0, [x29, #-4]
	bl	l3d_fsin
	ldr	x8, [sp, #8]                    // 8-byte Folded Reload
	stur	s0, [x29, #-12]
	ldur	s0, [x29, #-8]
	str	s0, [x8]
	ldur	s0, [x29, #-12]
	str	s0, [x8, #8]
	ldur	s0, [x29, #-12]
	fneg	s0, s0
	str	s0, [x8, #32]
	ldur	s0, [x29, #-8]
	str	s0, [x8, #40]
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end9:
	.size	l3d_matrix_rotate_y, .Lfunc_end9-l3d_matrix_rotate_y
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function l3d_matrix_rotate_x
	.type	l3d_matrix_rotate_x,@function
l3d_matrix_rotate_x:                    // @l3d_matrix_rotate_x
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x8, [sp, #8]                    // 8-byte Folded Spill
	stur	s0, [x29, #-4]
	bl	l3d_matrix_identity
	ldur	s0, [x29, #-4]
	bl	l3d_fcos
	stur	s0, [x29, #-8]
	ldur	s0, [x29, #-4]
	bl	l3d_fsin
	ldr	x8, [sp, #8]                    // 8-byte Folded Reload
	stur	s0, [x29, #-12]
	ldur	s0, [x29, #-8]
	str	s0, [x8, #20]
	ldur	s0, [x29, #-12]
	fneg	s0, s0
	str	s0, [x8, #24]
	ldur	s0, [x29, #-12]
	str	s0, [x8, #36]
	ldur	s0, [x29, #-8]
	str	s0, [x8, #40]
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end10:
	.size	l3d_matrix_rotate_x, .Lfunc_end10-l3d_matrix_rotate_x
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function l3d_matrix_rotate_z
	.type	l3d_matrix_rotate_z,@function
l3d_matrix_rotate_z:                    // @l3d_matrix_rotate_z
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x8, [sp, #8]                    // 8-byte Folded Spill
	stur	s0, [x29, #-4]
	bl	l3d_matrix_identity
	ldur	s0, [x29, #-4]
	bl	l3d_fcos
	stur	s0, [x29, #-8]
	ldur	s0, [x29, #-4]
	bl	l3d_fsin
	ldr	x8, [sp, #8]                    // 8-byte Folded Reload
	stur	s0, [x29, #-12]
	ldur	s0, [x29, #-8]
	str	s0, [x8]
	ldur	s0, [x29, #-12]
	fneg	s0, s0
	str	s0, [x8, #4]
	ldur	s0, [x29, #-12]
	str	s0, [x8, #16]
	ldur	s0, [x29, #-8]
	str	s0, [x8, #20]
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end11:
	.size	l3d_matrix_rotate_z, .Lfunc_end11-l3d_matrix_rotate_z
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function l3d_draw_sphere
	.type	l3d_draw_sphere,@function
l3d_draw_sphere:                        // @l3d_draw_sphere
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #304
	.cfi_def_cfa_offset 304
	stp	x29, x30, [sp, #272]            // 16-byte Folded Spill
	str	x28, [sp, #288]                 // 8-byte Folded Spill
	add	x29, sp, #272
	.cfi_def_cfa w29, 32
	.cfi_offset w28, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	stur	s0, [x29, #-12]
	stur	s1, [x29, #-8]
	stur	s2, [x29, #-4]
	stur	x0, [x29, #-24]
	stur	s3, [x29, #-28]
	stur	w1, [x29, #-32]
	stur	w2, [x29, #-36]
	ldur	x8, [x29, #-24]
	cbnz	x8, .LBB12_2
	b	.LBB12_1
.LBB12_1:
	b	.LBB12_18
.LBB12_2:
	stur	wzr, [x29, #-40]
	b	.LBB12_3
.LBB12_3:                               // =>This Loop Header: Depth=1
                                        //     Child Loop BB12_5 Depth 2
	ldur	w8, [x29, #-40]
	ldur	w9, [x29, #-32]
	subs	w8, w8, w9
	b.ge	.LBB12_10
	b	.LBB12_4
.LBB12_4:                               //   in Loop: Header=BB12_3 Depth=1
	ldur	s0, [x29, #-40]
	scvtf	s1, s0
	mov	w8, #4059                       // =0xfdb
	movk	w8, #16585, lsl #16
	fmov	s0, w8
	fmul	s1, s0, s1
	ldur	s2, [x29, #-32]
	scvtf	s2, s2
	fdiv	s1, s1, s2
	stur	s1, [x29, #-44]
	ldur	w8, [x29, #-40]
	add	w8, w8, #1
	scvtf	s1, w8
	fmul	s0, s0, s1
	ldur	s1, [x29, #-32]
	scvtf	s1, s1
	fdiv	s0, s0, s1
	stur	s0, [x29, #-48]
	stur	wzr, [x29, #-52]
	b	.LBB12_5
.LBB12_5:                               //   Parent Loop BB12_3 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	ldur	w8, [x29, #-52]
	ldur	w9, [x29, #-32]
	mov	w10, #2                         // =0x2
	sdiv	w9, w9, w10
	subs	w8, w8, w9
	b.gt	.LBB12_8
	b	.LBB12_6
.LBB12_6:                               //   in Loop: Header=BB12_5 Depth=2
	ldur	s0, [x29, #-52]
	scvtf	s1, s0
	mov	w8, #4059                       // =0xfdb
	movk	w8, #16457, lsl #16
	fmov	s0, w8
	fmul	s1, s0, s1
	ldur	w8, [x29, #-32]
	mov	w9, #2                          // =0x2
	sdiv	w8, w8, w9
	scvtf	s2, w8
	fdiv	s1, s1, s2
	stur	s1, [x29, #-56]
	ldur	w8, [x29, #-52]
	add	w8, w8, #1
	scvtf	s1, w8
	fmul	s0, s0, s1
	ldur	w8, [x29, #-32]
	sdiv	w8, w8, w9
	scvtf	s1, w8
	fdiv	s0, s0, s1
	stur	s0, [x29, #-60]
	ldur	s0, [x29, #-28]
	str	s0, [sp, #48]                   // 4-byte Folded Spill
	ldur	s0, [x29, #-56]
	bl	l3d_fsin
	fmov	s1, s0
	ldr	s0, [sp, #48]                   // 4-byte Folded Reload
	fmul	s0, s0, s1
	str	s0, [sp, #52]                   // 4-byte Folded Spill
	ldur	s0, [x29, #-44]
	bl	l3d_fcos
	fmov	s1, s0
	ldr	s0, [sp, #52]                   // 4-byte Folded Reload
	fmul	s0, s0, s1
	stur	s0, [x29, #-72]
	ldur	s0, [x29, #-28]
	str	s0, [sp, #56]                   // 4-byte Folded Spill
	ldur	s0, [x29, #-56]
	bl	l3d_fcos
	fmov	s1, s0
	ldr	s0, [sp, #56]                   // 4-byte Folded Reload
	fmul	s0, s0, s1
	stur	s0, [x29, #-68]
	ldur	s0, [x29, #-28]
	str	s0, [sp, #60]                   // 4-byte Folded Spill
	ldur	s0, [x29, #-56]
	bl	l3d_fsin
	fmov	s1, s0
	ldr	s0, [sp, #60]                   // 4-byte Folded Reload
	fmul	s0, s0, s1
	str	s0, [sp, #64]                   // 4-byte Folded Spill
	ldur	s0, [x29, #-44]
	bl	l3d_fsin
	fmov	s1, s0
	ldr	s0, [sp, #64]                   // 4-byte Folded Reload
	fmul	s0, s0, s1
	stur	s0, [x29, #-64]
	ldur	s0, [x29, #-28]
	str	s0, [sp, #68]                   // 4-byte Folded Spill
	ldur	s0, [x29, #-60]
	bl	l3d_fsin
	fmov	s1, s0
	ldr	s0, [sp, #68]                   // 4-byte Folded Reload
	fmul	s0, s0, s1
	str	s0, [sp, #72]                   // 4-byte Folded Spill
	ldur	s0, [x29, #-44]
	bl	l3d_fcos
	fmov	s1, s0
	ldr	s0, [sp, #72]                   // 4-byte Folded Reload
	fmul	s0, s0, s1
	stur	s0, [x29, #-88]
	ldur	s0, [x29, #-28]
	str	s0, [sp, #76]                   // 4-byte Folded Spill
	ldur	s0, [x29, #-60]
	bl	l3d_fcos
	fmov	s1, s0
	ldr	s0, [sp, #76]                   // 4-byte Folded Reload
	fmul	s0, s0, s1
	stur	s0, [x29, #-84]
	ldur	s0, [x29, #-28]
	str	s0, [sp, #80]                   // 4-byte Folded Spill
	ldur	s0, [x29, #-60]
	bl	l3d_fsin
	fmov	s1, s0
	ldr	s0, [sp, #80]                   // 4-byte Folded Reload
	fmul	s0, s0, s1
	str	s0, [sp, #84]                   // 4-byte Folded Spill
	ldur	s0, [x29, #-44]
	bl	l3d_fsin
	fmov	s1, s0
	ldr	s0, [sp, #84]                   // 4-byte Folded Reload
	fmul	s0, s0, s1
	stur	s0, [x29, #-80]
	ldur	s0, [x29, #-72]
	ldur	s1, [x29, #-68]
	ldur	s2, [x29, #-64]
	ldur	s3, [x29, #-12]
	ldur	s4, [x29, #-8]
	ldur	s5, [x29, #-4]
	bl	l3d_vec3_add
	stur	s0, [x29, #-100]
	stur	s1, [x29, #-96]
	stur	s2, [x29, #-92]
	ldur	x8, [x29, #-100]
	stur	x8, [x29, #-72]
	ldur	w8, [x29, #-92]
	stur	w8, [x29, #-64]
	ldur	s0, [x29, #-88]
	ldur	s1, [x29, #-84]
	ldur	s2, [x29, #-80]
	ldur	s3, [x29, #-12]
	ldur	s4, [x29, #-8]
	ldur	s5, [x29, #-4]
	bl	l3d_vec3_add
	stur	s0, [x29, #-112]
	stur	s1, [x29, #-108]
	stur	s2, [x29, #-104]
	ldur	x8, [x29, #-112]
	stur	x8, [x29, #-88]
	ldur	w8, [x29, #-104]
	stur	w8, [x29, #-80]
	ldur	x0, [x29, #-24]
	ldur	w1, [x29, #-36]
	ldur	s0, [x29, #-72]
	ldur	s1, [x29, #-68]
	ldur	s2, [x29, #-64]
	ldur	s3, [x29, #-88]
	ldur	s4, [x29, #-84]
	ldur	s5, [x29, #-80]
	bl	l3d_draw_line
	b	.LBB12_7
.LBB12_7:                               //   in Loop: Header=BB12_5 Depth=2
	ldur	w8, [x29, #-52]
	add	w8, w8, #1
	stur	w8, [x29, #-52]
	b	.LBB12_5
.LBB12_8:                               //   in Loop: Header=BB12_3 Depth=1
	b	.LBB12_9
.LBB12_9:                               //   in Loop: Header=BB12_3 Depth=1
	ldur	w8, [x29, #-40]
	add	w8, w8, #1
	stur	w8, [x29, #-40]
	b	.LBB12_3
.LBB12_10:
	stur	wzr, [x29, #-116]
	b	.LBB12_11
.LBB12_11:                              // =>This Loop Header: Depth=1
                                        //     Child Loop BB12_13 Depth 2
	ldur	w8, [x29, #-116]
	ldur	w9, [x29, #-32]
	mov	w10, #2                         // =0x2
	sdiv	w9, w9, w10
	subs	w8, w8, w9
	b.gt	.LBB12_18
	b	.LBB12_12
.LBB12_12:                              //   in Loop: Header=BB12_11 Depth=1
	ldur	s0, [x29, #-116]
	scvtf	s1, s0
	mov	w8, #4059                       // =0xfdb
	movk	w8, #16457, lsl #16
	fmov	s0, w8
	fmul	s0, s0, s1
	ldur	w8, [x29, #-32]
	mov	w9, #2                          // =0x2
	sdiv	w8, w8, w9
	scvtf	s1, w8
	fdiv	s0, s0, s1
	stur	s0, [x29, #-120]
	stur	wzr, [x29, #-124]
	b	.LBB12_13
.LBB12_13:                              //   Parent Loop BB12_11 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	ldur	w8, [x29, #-124]
	ldur	w9, [x29, #-32]
	subs	w8, w8, w9
	b.ge	.LBB12_16
	b	.LBB12_14
.LBB12_14:                              //   in Loop: Header=BB12_13 Depth=2
	ldur	s0, [x29, #-124]
	scvtf	s1, s0
	mov	w8, #4059                       // =0xfdb
	movk	w8, #16585, lsl #16
	fmov	s0, w8
	fmul	s1, s0, s1
	ldur	s2, [x29, #-32]
	scvtf	s2, s2
	fdiv	s1, s1, s2
	stur	s1, [x29, #-128]
	ldur	w8, [x29, #-124]
	add	w8, w8, #1
	scvtf	s1, w8
	fmul	s0, s0, s1
	ldur	s1, [x29, #-32]
	scvtf	s1, s1
	fdiv	s0, s0, s1
	stur	s0, [x29, #-132]
	ldur	s0, [x29, #-28]
	str	s0, [sp, #8]                    // 4-byte Folded Spill
	ldur	s0, [x29, #-120]
	bl	l3d_fsin
	fmov	s1, s0
	ldr	s0, [sp, #8]                    // 4-byte Folded Reload
	fmul	s0, s0, s1
	str	s0, [sp, #12]                   // 4-byte Folded Spill
	ldur	s0, [x29, #-128]
	bl	l3d_fcos
	fmov	s1, s0
	ldr	s0, [sp, #12]                   // 4-byte Folded Reload
	fmul	s0, s0, s1
	str	s0, [sp, #128]
	ldur	s0, [x29, #-28]
	str	s0, [sp, #16]                   // 4-byte Folded Spill
	ldur	s0, [x29, #-120]
	bl	l3d_fcos
	fmov	s1, s0
	ldr	s0, [sp, #16]                   // 4-byte Folded Reload
	fmul	s0, s0, s1
	str	s0, [sp, #132]
	ldur	s0, [x29, #-28]
	str	s0, [sp, #20]                   // 4-byte Folded Spill
	ldur	s0, [x29, #-120]
	bl	l3d_fsin
	fmov	s1, s0
	ldr	s0, [sp, #20]                   // 4-byte Folded Reload
	fmul	s0, s0, s1
	str	s0, [sp, #24]                   // 4-byte Folded Spill
	ldur	s0, [x29, #-128]
	bl	l3d_fsin
	fmov	s1, s0
	ldr	s0, [sp, #24]                   // 4-byte Folded Reload
	fmul	s0, s0, s1
	str	s0, [sp, #136]
	ldur	s0, [x29, #-28]
	str	s0, [sp, #28]                   // 4-byte Folded Spill
	ldur	s0, [x29, #-120]
	bl	l3d_fsin
	fmov	s1, s0
	ldr	s0, [sp, #28]                   // 4-byte Folded Reload
	fmul	s0, s0, s1
	str	s0, [sp, #32]                   // 4-byte Folded Spill
	ldur	s0, [x29, #-132]
	bl	l3d_fcos
	fmov	s1, s0
	ldr	s0, [sp, #32]                   // 4-byte Folded Reload
	fmul	s0, s0, s1
	str	s0, [sp, #112]
	ldur	s0, [x29, #-28]
	str	s0, [sp, #36]                   // 4-byte Folded Spill
	ldur	s0, [x29, #-120]
	bl	l3d_fcos
	fmov	s1, s0
	ldr	s0, [sp, #36]                   // 4-byte Folded Reload
	fmul	s0, s0, s1
	str	s0, [sp, #116]
	ldur	s0, [x29, #-28]
	str	s0, [sp, #40]                   // 4-byte Folded Spill
	ldur	s0, [x29, #-120]
	bl	l3d_fsin
	fmov	s1, s0
	ldr	s0, [sp, #40]                   // 4-byte Folded Reload
	fmul	s0, s0, s1
	str	s0, [sp, #44]                   // 4-byte Folded Spill
	ldur	s0, [x29, #-132]
	bl	l3d_fsin
	fmov	s1, s0
	ldr	s0, [sp, #44]                   // 4-byte Folded Reload
	fmul	s0, s0, s1
	str	s0, [sp, #120]
	ldr	s0, [sp, #128]
	ldr	s1, [sp, #132]
	ldr	s2, [sp, #136]
	ldur	s3, [x29, #-12]
	ldur	s4, [x29, #-8]
	ldur	s5, [x29, #-4]
	bl	l3d_vec3_add
	str	s0, [sp, #100]
	str	s1, [sp, #104]
	str	s2, [sp, #108]
	ldur	x8, [sp, #100]
	str	x8, [sp, #128]
	ldr	w8, [sp, #108]
	str	w8, [sp, #136]
	ldr	s0, [sp, #112]
	ldr	s1, [sp, #116]
	ldr	s2, [sp, #120]
	ldur	s3, [x29, #-12]
	ldur	s4, [x29, #-8]
	ldur	s5, [x29, #-4]
	bl	l3d_vec3_add
	str	s0, [sp, #88]
	str	s1, [sp, #92]
	str	s2, [sp, #96]
	ldr	x8, [sp, #88]
	str	x8, [sp, #112]
	ldr	w8, [sp, #96]
	str	w8, [sp, #120]
	ldur	x0, [x29, #-24]
	ldur	w1, [x29, #-36]
	ldr	s0, [sp, #128]
	ldr	s1, [sp, #132]
	ldr	s2, [sp, #136]
	ldr	s3, [sp, #112]
	ldr	s4, [sp, #116]
	ldr	s5, [sp, #120]
	bl	l3d_draw_line
	b	.LBB12_15
.LBB12_15:                              //   in Loop: Header=BB12_13 Depth=2
	ldur	w8, [x29, #-124]
	add	w8, w8, #1
	stur	w8, [x29, #-124]
	b	.LBB12_13
.LBB12_16:                              //   in Loop: Header=BB12_11 Depth=1
	b	.LBB12_17
.LBB12_17:                              //   in Loop: Header=BB12_11 Depth=1
	ldur	w8, [x29, #-116]
	add	w8, w8, #1
	stur	w8, [x29, #-116]
	b	.LBB12_11
.LBB12_18:
	.cfi_def_cfa wsp, 304
	ldr	x28, [sp, #288]                 // 8-byte Folded Reload
	ldp	x29, x30, [sp, #272]            // 16-byte Folded Reload
	add	sp, sp, #304
	.cfi_def_cfa_offset 0
	.cfi_restore w28
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end12:
	.size	l3d_draw_sphere, .Lfunc_end12-l3d_draw_sphere
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function l3d_render
	.type	l3d_render,@function
l3d_render:                             // @l3d_render
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, .LBB13_2
	b	.LBB13_1
.LBB13_1:
	b	.LBB13_5
.LBB13_2:
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #8]
	subs	w8, w8, #1
	b.ne	.LBB13_4
	b	.LBB13_3
.LBB13_3:
	ldr	x0, [sp, #8]
	bl	l3d_display_text
	b	.LBB13_5
.LBB13_4:
	ldr	x0, [sp, #8]
	bl	l3d_display_graphical
	b	.LBB13_5
.LBB13_5:
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end13:
	.size	l3d_render, .Lfunc_end13-l3d_render
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function l3d_matrix_mul
	.type	l3d_matrix_mul,@function
l3d_matrix_mul:                         // @l3d_matrix_mul
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #80
	.cfi_def_cfa_offset 80
	stp	x29, x30, [sp, #64]             // 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x8, [sp, #8]                    // 8-byte Folded Spill
	mov	x8, x0
	ldr	x0, [sp, #8]                    // 8-byte Folded Reload
	str	x8, [sp, #16]                   // 8-byte Folded Spill
	str	x1, [sp, #24]                   // 8-byte Folded Spill
	stur	x8, [x29, #-8]
	stur	x1, [x29, #-16]
	mov	x2, #64                         // =0x40
	mov	w1, wzr
	bl	memset
	stur	wzr, [x29, #-20]
	b	.LBB14_1
.LBB14_1:                               // =>This Loop Header: Depth=1
                                        //     Child Loop BB14_3 Depth 2
                                        //       Child Loop BB14_5 Depth 3
	ldur	w8, [x29, #-20]
	subs	w8, w8, #4
	b.ge	.LBB14_12
	b	.LBB14_2
.LBB14_2:                               //   in Loop: Header=BB14_1 Depth=1
	stur	wzr, [x29, #-24]
	b	.LBB14_3
.LBB14_3:                               //   Parent Loop BB14_1 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB14_5 Depth 3
	ldur	w8, [x29, #-24]
	subs	w8, w8, #4
	b.ge	.LBB14_10
	b	.LBB14_4
.LBB14_4:                               //   in Loop: Header=BB14_3 Depth=2
	ldr	x8, [sp, #8]                    // 8-byte Folded Reload
	ldursw	x9, [x29, #-20]
	add	x8, x8, x9, lsl #4
	ldursw	x9, [x29, #-24]
	movi	d0, #0000000000000000
	str	s0, [x8, x9, lsl #2]
	stur	wzr, [x29, #-28]
	b	.LBB14_5
.LBB14_5:                               //   Parent Loop BB14_1 Depth=1
                                        //     Parent Loop BB14_3 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	ldur	w8, [x29, #-28]
	subs	w8, w8, #4
	b.ge	.LBB14_8
	b	.LBB14_6
.LBB14_6:                               //   in Loop: Header=BB14_5 Depth=3
	ldr	x8, [sp, #8]                    // 8-byte Folded Reload
	ldr	x9, [sp, #24]                   // 8-byte Folded Reload
	ldr	x10, [sp, #16]                  // 8-byte Folded Reload
	ldursw	x11, [x29, #-20]
	add	x10, x10, x11, lsl #4
	ldursw	x11, [x29, #-28]
	ldr	s0, [x10, x11, lsl #2]
	ldursw	x10, [x29, #-28]
	add	x9, x9, x10, lsl #4
	ldursw	x10, [x29, #-24]
	ldr	s1, [x9, x10, lsl #2]
	ldursw	x9, [x29, #-20]
	add	x8, x8, x9, lsl #4
	ldursw	x9, [x29, #-24]
	ldr	s2, [x8, x9, lsl #2]
	fmadd	s0, s0, s1, s2
	str	s0, [x8, x9, lsl #2]
	b	.LBB14_7
.LBB14_7:                               //   in Loop: Header=BB14_5 Depth=3
	ldur	w8, [x29, #-28]
	add	w8, w8, #1
	stur	w8, [x29, #-28]
	b	.LBB14_5
.LBB14_8:                               //   in Loop: Header=BB14_3 Depth=2
	b	.LBB14_9
.LBB14_9:                               //   in Loop: Header=BB14_3 Depth=2
	ldur	w8, [x29, #-24]
	add	w8, w8, #1
	stur	w8, [x29, #-24]
	b	.LBB14_3
.LBB14_10:                              //   in Loop: Header=BB14_1 Depth=1
	b	.LBB14_11
.LBB14_11:                              //   in Loop: Header=BB14_1 Depth=1
	ldur	w8, [x29, #-20]
	add	w8, w8, #1
	stur	w8, [x29, #-20]
	b	.LBB14_1
.LBB14_12:
	.cfi_def_cfa wsp, 80
	ldp	x29, x30, [sp, #64]             // 16-byte Folded Reload
	add	sp, sp, #80
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end14:
	.size	l3d_matrix_mul, .Lfunc_end14-l3d_matrix_mul
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function l3d_fcos
	.type	l3d_fcos,@function
l3d_fcos:                               // @l3d_fcos
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	s0, [x29, #-4]
	ldur	s0, [x29, #-4]
	mov	w8, #4059                       // =0xfdb
	movk	w8, #16329, lsl #16
	fmov	s1, w8
	fadd	s0, s0, s1
	bl	l3d_fsin
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end15:
	.size	l3d_fcos, .Lfunc_end15-l3d_fcos
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function l3d_fsin
	.type	l3d_fsin,@function
l3d_fsin:                               // @l3d_fsin
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	s0, [sp, #12]
	ldr	s2, [sp, #12]
	ldr	s0, [sp, #12]
	mov	w8, #4059                       // =0xfdb
	movk	w8, #16585, lsl #16
	fmov	s1, w8
	fdiv	s0, s0, s1
	fcvtzs	s0, s0
	scvtf	s1, s0
	mov	w8, #4059                       // =0xfdb
	movk	w8, #49353, lsl #16
	fmov	s0, w8
	fmadd	s0, s0, s1, s2
	str	s0, [sp, #12]
	fmov	s0, #1.00000000
	str	s0, [sp, #8]
	ldr	s0, [sp, #12]
	fcmp	s0, #0.0
	b.pl	.LBB16_2
	b	.LBB16_1
.LBB16_1:
	fmov	s0, #-1.00000000
	str	s0, [sp, #8]
	ldr	s0, [sp, #12]
	fneg	s0, s0
	str	s0, [sp, #12]
	b	.LBB16_2
.LBB16_2:
	ldr	s0, [sp, #12]
	mov	w8, #4059                       // =0xfdb
	movk	w8, #16457, lsl #16
	fmov	s1, w8
	fcmp	s0, s1
	b.le	.LBB16_4
	b	.LBB16_3
.LBB16_3:
	ldr	s0, [sp, #8]
	fneg	s0, s0
	str	s0, [sp, #8]
	ldr	s0, [sp, #12]
	mov	w8, #4059                       // =0xfdb
	movk	w8, #16457, lsl #16
	fmov	s1, w8
	fsub	s0, s0, s1
	str	s0, [sp, #12]
	b	.LBB16_4
.LBB16_4:
	ldr	s0, [sp, #12]
	mov	w8, #4059                       // =0xfdb
	movk	w8, #16329, lsl #16
	fmov	s1, w8
	fcmp	s0, s1
	b.le	.LBB16_6
	b	.LBB16_5
.LBB16_5:
	ldr	s1, [sp, #12]
	mov	w8, #4059                       // =0xfdb
	movk	w8, #16457, lsl #16
	fmov	s0, w8
	fsub	s0, s0, s1
	str	s0, [sp, #12]
	b	.LBB16_6
.LBB16_6:
	ldr	s0, [sp, #12]
	ldr	s1, [sp, #12]
	fmul	s0, s0, s1
	str	s0, [sp, #4]
	ldr	s0, [sp, #8]
	ldr	s1, [sp, #12]
	fmul	s0, s0, s1
	ldr	s1, [sp, #4]
	ldr	s2, [sp, #4]
	ldr	s3, [sp, #4]
	mov	w8, #34953                      // =0x8889
	movk	w8, #15368, lsl #16
	fmov	s5, w8
	mov	w8, #3329                       // =0xd01
	movk	w8, #14672, lsl #16
	fmov	s4, w8
	fmsub	s3, s3, s4, s5
	mov	w8, #43691                      // =0xaaab
	movk	w8, #15914, lsl #16
	fmov	s4, w8
	fmsub	s2, s2, s3, s4
	fmov	s3, #1.00000000
	fmsub	s1, s1, s2, s3
	fmul	s0, s0, s1
	add	sp, sp, #16
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end16:
	.size	l3d_fsin, .Lfunc_end16-l3d_fsin
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function l3d_destroy_context
	.type	l3d_destroy_context,@function
l3d_destroy_context:                    // @l3d_destroy_context
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, .LBB17_2
	b	.LBB17_1
.LBB17_1:
	b	.LBB17_9
.LBB17_2:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #16]
	cbz	x8, .LBB17_4
	b	.LBB17_3
.LBB17_3:
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #16]
	bl	l_free
	b	.LBB17_4
.LBB17_4:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #24]
	cbz	x8, .LBB17_6
	b	.LBB17_5
.LBB17_5:
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #24]
	bl	l_free
	b	.LBB17_6
.LBB17_6:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #32]
	cbz	x8, .LBB17_8
	b	.LBB17_7
.LBB17_7:
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #32]
	bl	l_free
	b	.LBB17_8
.LBB17_8:
	ldr	x0, [sp, #8]
	bl	l_free
	b	.LBB17_9
.LBB17_9:
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end17:
	.size	l3d_destroy_context, .Lfunc_end17-l3d_destroy_context
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function l_write
	.type	l_write,@function
l_write:                                // @l_write
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	w0, [x29, #-4]
	str	x1, [sp, #16]
	str	w2, [sp, #12]
	ldursw	x1, [x29, #-4]
	ldr	x2, [sp, #16]
	ldrsw	x3, [sp, #12]
	mov	x0, #64                         // =0x40
	mov	x6, xzr
	mov	x4, x6
	mov	x5, x6
	bl	l_syscall
                                        // kill: def $w0 killed $w0 killed $x0
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end18:
	.size	l_write, .Lfunc_end18-l_write
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function l_putchar
	.type	l_putchar,@function
l_putchar:                              // @l_putchar
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	sub	x1, x29, #1
	sturb	w0, [x29, #-1]
	mov	w2, #1                          // =0x1
	mov	w0, w2
	bl	l_write
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end19:
	.size	l_putchar, .Lfunc_end19-l_putchar
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function l_syscall
	.type	l_syscall,@function
l_syscall:                              // @l_syscall
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #128
	.cfi_def_cfa_offset 128
	str	x0, [sp, #112]
	str	x1, [sp, #104]
	str	x2, [sp, #96]
	str	x3, [sp, #88]
	str	x4, [sp, #80]
	str	x5, [sp, #72]
	str	x6, [sp, #64]
	ldr	x8, [sp, #112]
	str	x8, [sp, #48]
	ldr	x8, [sp, #104]
	str	x8, [sp, #40]
	ldr	x8, [sp, #96]
	str	x8, [sp, #32]
	ldr	x8, [sp, #88]
	str	x8, [sp, #24]
	ldr	x8, [sp, #80]
	str	x8, [sp, #16]
	ldr	x8, [sp, #72]
	str	x8, [sp, #8]
	ldr	x8, [sp, #64]
	str	x8, [sp]
	ldr	x0, [sp, #40]
	ldr	x1, [sp, #32]
	ldr	x2, [sp, #24]
	ldr	x3, [sp, #16]
	ldr	x4, [sp, #8]
	ldr	x5, [sp]
	ldr	x8, [sp, #48]
	//APP
	svc	#0
	//NO_APP
	str	x0, [sp, #40]
	ldr	x8, [sp, #40]
	str	x8, [sp, #56]
	ldr	x8, [sp, #56]
	tbz	x8, #63, .LBB20_2
	b	.LBB20_1
.LBB20_1:
	ldr	x9, [sp, #56]
	mov	x8, xzr
	subs	x8, x8, x9
	str	x8, [sp, #120]
	b	.LBB20_3
.LBB20_2:
	ldr	x8, [sp, #56]
	str	x8, [sp, #120]
	b	.LBB20_3
.LBB20_3:
	ldr	x0, [sp, #120]
	add	sp, sp, #128
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end20:
	.size	l_syscall, .Lfunc_end20-l_syscall
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function l_malloc
	.type	l_malloc,@function
l_malloc:                               // @l_malloc
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	w0, [sp, #20]
	ldr	w8, [sp, #20]
	subs	w8, w8, #0
	b.gt	.LBB21_2
	b	.LBB21_1
.LBB21_1:
                                        // kill: def $x8 killed $xzr
	str	xzr, [sp, #24]
	b	.LBB21_5
.LBB21_2:
	ldrsw	x8, [sp, #20]
	add	x8, x8, #8
	add	x8, x8, #7
	and	x8, x8, #0xfffffffffffffff8
                                        // kill: def $w8 killed $w8 killed $x8
	str	w8, [sp, #16]
	adrp	x8, l_mem_used
	ldr	w8, [x8, :lo12:l_mem_used]
	ldr	w9, [sp, #16]
	add	w8, w8, w9
	subs	w8, w8, #1024, lsl #12          // =4194304
	b.le	.LBB21_4
	b	.LBB21_3
.LBB21_3:
                                        // kill: def $x8 killed $xzr
	str	xzr, [sp, #24]
	b	.LBB21_5
.LBB21_4:
	adrp	x9, l_mem_used
	ldrsw	x10, [x9, :lo12:l_mem_used]
	adrp	x8, l_mem_pool
	add	x8, x8, :lo12:l_mem_pool
	add	x8, x8, x10
	str	x8, [sp, #8]
	ldr	w8, [sp, #20]
	ldr	x10, [sp, #8]
	str	w8, [x10]
	ldr	x10, [sp, #8]
	mov	w8, #1                          // =0x1
	str	w8, [x10, #4]
	ldr	x8, [sp, #8]
	add	x8, x8, #8
	str	x8, [sp]
	ldr	w10, [sp, #16]
	ldr	w8, [x9, :lo12:l_mem_used]
	add	w8, w8, w10
	str	w8, [x9, :lo12:l_mem_used]
	ldr	x8, [sp]
	str	x8, [sp, #24]
	b	.LBB21_5
.LBB21_5:
	ldr	x0, [sp, #24]
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end21:
	.size	l_malloc, .Lfunc_end21-l_malloc
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function l3d_draw_point
	.type	l3d_draw_point,@function
l3d_draw_point:                         // @l3d_draw_point
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #24]
	str	w1, [sp, #20]
	str	w2, [sp, #16]
	str	s0, [sp, #12]
	str	w3, [sp, #8]
	ldr	x8, [sp, #24]
	cbz	x8, .LBB22_3
	b	.LBB22_1
.LBB22_1:
	ldr	x8, [sp, #24]
	ldr	x8, [x8, #24]
	cbz	x8, .LBB22_3
	b	.LBB22_2
.LBB22_2:
	ldr	x8, [sp, #24]
	ldr	x8, [x8, #32]
	cbnz	x8, .LBB22_4
	b	.LBB22_3
.LBB22_3:
	b	.LBB22_18
.LBB22_4:
	ldr	w8, [sp, #20]
	tbnz	w8, #31, .LBB22_8
	b	.LBB22_5
.LBB22_5:
	ldr	w8, [sp, #20]
	ldr	x9, [sp, #24]
	ldr	w9, [x9]
	subs	w8, w8, w9
	b.ge	.LBB22_8
	b	.LBB22_6
.LBB22_6:
	ldr	w8, [sp, #16]
	tbnz	w8, #31, .LBB22_8
	b	.LBB22_7
.LBB22_7:
	ldr	w8, [sp, #16]
	ldr	x9, [sp, #24]
	ldr	w9, [x9, #4]
	subs	w8, w8, w9
	b.lt	.LBB22_9
	b	.LBB22_8
.LBB22_8:
	b	.LBB22_18
.LBB22_9:
	ldr	w8, [sp, #16]
	ldr	x9, [sp, #24]
	ldr	w9, [x9]
	mul	w8, w8, w9
	ldr	w9, [sp, #20]
	add	w8, w8, w9
	str	w8, [sp, #4]
	ldr	s0, [sp, #12]
	fcmp	s0, #0.0
	b.lt	.LBB22_18
	b	.LBB22_10
.LBB22_10:
	ldr	s0, [sp, #12]
	ldr	x8, [sp, #24]
	ldr	x8, [x8, #24]
	ldrsw	x9, [sp, #4]
	ldr	s1, [x8, x9, lsl #2]
	fcmp	s0, s1
	b.pl	.LBB22_18
	b	.LBB22_11
.LBB22_11:
	ldr	s0, [sp, #12]
	ldr	x8, [sp, #24]
	ldr	x8, [x8, #24]
	ldrsw	x9, [sp, #4]
	str	s0, [x8, x9, lsl #2]
	ldr	w8, [sp, #8]
	ldr	x9, [sp, #24]
	ldr	x9, [x9, #32]
	ldrsw	x10, [sp, #4]
	str	w8, [x9, x10, lsl #2]
	ldr	s0, [sp, #12]
	fmov	s1, #8.00000000
	fmul	s0, s0, s1
	fcvtzs	w8, s0
	str	w8, [sp]
	ldr	w8, [sp]
	tbz	w8, #31, .LBB22_13
	b	.LBB22_12
.LBB22_12:
	str	wzr, [sp]
	b	.LBB22_13
.LBB22_13:
	ldr	w8, [sp]
	subs	w8, w8, #7
	b.le	.LBB22_15
	b	.LBB22_14
.LBB22_14:
	mov	w8, #7                          // =0x7
	str	w8, [sp]
	b	.LBB22_15
.LBB22_15:
	ldr	x8, [sp, #24]
	ldr	x8, [x8, #16]
	cbz	x8, .LBB22_17
	b	.LBB22_16
.LBB22_16:
	adrp	x8, L3D_TEXT_CHARS
	ldr	x8, [x8, :lo12:L3D_TEXT_CHARS]
	ldrsw	x9, [sp]
	add	x8, x8, x9
	ldrb	w8, [x8]
	ldr	x9, [sp, #24]
	ldr	x9, [x9, #16]
	ldrsw	x10, [sp, #4]
	add	x9, x9, x10
	strb	w8, [x9]
	b	.LBB22_17
.LBB22_17:
	b	.LBB22_18
.LBB22_18:
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end22:
	.size	l3d_draw_point, .Lfunc_end22-l3d_draw_point
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function l3d_vec3_add
	.type	l3d_vec3_add,@function
l3d_vec3_add:                           // @l3d_vec3_add
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	str	s0, [sp, #24]
	str	s1, [sp, #28]
	str	s2, [sp, #32]
	str	s3, [sp, #12]
	str	s4, [sp, #16]
	str	s5, [sp, #20]
	ldr	s0, [sp, #24]
	ldr	s1, [sp, #12]
	fadd	s0, s0, s1
	str	s0, [sp, #36]
	ldr	s0, [sp, #28]
	ldr	s1, [sp, #16]
	fadd	s0, s0, s1
	str	s0, [sp, #40]
	ldr	s0, [sp, #32]
	ldr	s1, [sp, #20]
	fadd	s0, s0, s1
	str	s0, [sp, #44]
	ldr	s0, [sp, #36]
	ldr	s1, [sp, #40]
	ldr	s2, [sp, #44]
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end23:
	.size	l3d_vec3_add, .Lfunc_end23-l3d_vec3_add
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function l3d_vec3_transform
	.type	l3d_vec3_transform,@function
l3d_vec3_transform:                     // @l3d_vec3_transform
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	str	s0, [sp, #24]
	str	s1, [sp, #28]
	str	s2, [sp, #32]
	mov	x8, x0
	str	x8, [sp, #16]
	ldr	s0, [sp, #24]
	ldr	s1, [x0, #12]
	ldr	s2, [sp, #28]
	ldr	s3, [x0, #28]
	fmul	s2, s2, s3
	fmadd	s2, s0, s1, s2
	ldr	s0, [sp, #32]
	ldr	s1, [x0, #44]
	fmadd	s0, s0, s1, s2
	ldr	s1, [x0, #60]
	fadd	s0, s0, s1
	str	s0, [sp, #12]
	ldr	s0, [sp, #24]
	ldr	s1, [x0]
	ldr	s2, [sp, #28]
	ldr	s3, [x0, #16]
	fmul	s2, s2, s3
	fmadd	s2, s0, s1, s2
	ldr	s0, [sp, #32]
	ldr	s1, [x0, #32]
	fmadd	s0, s0, s1, s2
	ldr	s1, [x0, #48]
	fadd	s0, s0, s1
	ldr	s1, [sp, #12]
	fdiv	s0, s0, s1
	str	s0, [sp, #36]
	ldr	s0, [sp, #24]
	ldr	s1, [x0, #4]
	ldr	s2, [sp, #28]
	ldr	s3, [x0, #20]
	fmul	s2, s2, s3
	fmadd	s2, s0, s1, s2
	ldr	s0, [sp, #32]
	ldr	s1, [x0, #36]
	fmadd	s0, s0, s1, s2
	ldr	s1, [x0, #52]
	fadd	s0, s0, s1
	ldr	s1, [sp, #12]
	fdiv	s0, s0, s1
	str	s0, [sp, #40]
	ldr	s0, [sp, #24]
	ldr	s1, [x0, #8]
	ldr	s2, [sp, #28]
	ldr	s3, [x0, #24]
	fmul	s2, s2, s3
	fmadd	s2, s0, s1, s2
	ldr	s0, [sp, #32]
	ldr	s1, [x0, #40]
	fmadd	s0, s0, s1, s2
	ldr	s1, [x0, #56]
	fadd	s0, s0, s1
	ldr	s1, [sp, #12]
	fdiv	s0, s0, s1
	str	s0, [sp, #44]
	ldr	s0, [sp, #36]
	ldr	s1, [sp, #40]
	ldr	s2, [sp, #44]
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end24:
	.size	l3d_vec3_transform, .Lfunc_end24-l3d_vec3_transform
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function l3d_matrix_identity
	.type	l3d_matrix_identity,@function
l3d_matrix_identity:                    // @l3d_matrix_identity
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x0, x8
	str	x0, [sp]                        // 8-byte Folded Spill
	mov	x2, #64                         // =0x40
	mov	w1, wzr
	bl	memset
	stur	wzr, [x29, #-4]
	b	.LBB25_1
.LBB25_1:                               // =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-4]
	subs	w8, w8, #4
	b.ge	.LBB25_4
	b	.LBB25_2
.LBB25_2:                               //   in Loop: Header=BB25_1 Depth=1
	ldr	x8, [sp]                        // 8-byte Folded Reload
	ldursw	x9, [x29, #-4]
	add	x8, x8, x9, lsl #4
	ldursw	x9, [x29, #-4]
	fmov	s0, #1.00000000
	str	s0, [x8, x9, lsl #2]
	b	.LBB25_3
.LBB25_3:                               //   in Loop: Header=BB25_1 Depth=1
	ldur	w8, [x29, #-4]
	add	w8, w8, #1
	stur	w8, [x29, #-4]
	b	.LBB25_1
.LBB25_4:
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end25:
	.size	l3d_matrix_identity, .Lfunc_end25-l3d_matrix_identity
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function l3d_display_text
	.type	l3d_display_text,@function
l3d_display_text:                       // @l3d_display_text
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	ldur	x8, [x29, #-8]
	cbz	x8, .LBB26_2
	b	.LBB26_1
.LBB26_1:
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #16]
	cbnz	x8, .LBB26_3
	b	.LBB26_2
.LBB26_2:
	b	.LBB26_11
.LBB26_3:
	adrp	x0, .L.str.9
	add	x0, x0, :lo12:.L.str.9
	bl	l_puts
	stur	wzr, [x29, #-12]
	b	.LBB26_4
.LBB26_4:                               // =>This Loop Header: Depth=1
                                        //     Child Loop BB26_6 Depth 2
	ldur	w8, [x29, #-12]
	ldur	x9, [x29, #-8]
	ldr	w9, [x9, #4]
	subs	w8, w8, w9
	b.ge	.LBB26_11
	b	.LBB26_5
.LBB26_5:                               //   in Loop: Header=BB26_4 Depth=1
	str	wzr, [sp, #16]
	b	.LBB26_6
.LBB26_6:                               //   Parent Loop BB26_4 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #16]
	ldur	x9, [x29, #-8]
	ldr	w9, [x9]
	subs	w8, w8, w9
	b.ge	.LBB26_9
	b	.LBB26_7
.LBB26_7:                               //   in Loop: Header=BB26_6 Depth=2
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #16]
	ldur	w9, [x29, #-12]
	ldur	x10, [x29, #-8]
	ldr	w10, [x10]
	mul	w9, w9, w10
	ldr	w10, [sp, #16]
	add	w9, w9, w10
	add	x8, x8, w9, sxtw
	ldrb	w8, [x8]
	strb	w8, [sp, #15]
	ldrb	w0, [sp, #15]
	bl	l_putchar
	b	.LBB26_8
.LBB26_8:                               //   in Loop: Header=BB26_6 Depth=2
	ldr	w8, [sp, #16]
	add	w8, w8, #1
	str	w8, [sp, #16]
	b	.LBB26_6
.LBB26_9:                               //   in Loop: Header=BB26_4 Depth=1
	mov	w0, #10                         // =0xa
	bl	l_putchar
	b	.LBB26_10
.LBB26_10:                              //   in Loop: Header=BB26_4 Depth=1
	ldur	w8, [x29, #-12]
	add	w8, w8, #1
	stur	w8, [x29, #-12]
	b	.LBB26_4
.LBB26_11:
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end26:
	.size	l3d_display_text, .Lfunc_end26-l3d_display_text
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function l3d_display_graphical
	.type	l3d_display_graphical,@function
l3d_display_graphical:                  // @l3d_display_graphical
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, .LBB27_2
	b	.LBB27_1
.LBB27_1:
	b	.LBB27_14
.LBB27_2:
	adrp	x0, .L.str.9
	add	x0, x0, :lo12:.L.str.9
	bl	l_puts
	str	wzr, [sp, #4]
	b	.LBB27_3
.LBB27_3:                               // =>This Loop Header: Depth=1
                                        //     Child Loop BB27_5 Depth 2
	ldr	w8, [sp, #4]
	ldr	x9, [sp, #8]
	ldr	w9, [x9, #4]
	subs	w8, w8, w9
	b.ge	.LBB27_14
	b	.LBB27_4
.LBB27_4:                               //   in Loop: Header=BB27_3 Depth=1
	str	wzr, [sp]
	b	.LBB27_5
.LBB27_5:                               //   Parent Loop BB27_3 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp]
	ldr	x9, [sp, #8]
	ldr	w9, [x9]
	subs	w8, w8, w9
	b.ge	.LBB27_12
	b	.LBB27_6
.LBB27_6:                               //   in Loop: Header=BB27_5 Depth=2
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #24]
	cbz	x8, .LBB27_9
	b	.LBB27_7
.LBB27_7:                               //   in Loop: Header=BB27_5 Depth=2
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #24]
	ldr	w9, [sp, #4]
	ldr	x10, [sp, #8]
	ldr	w10, [x10]
	mul	w9, w9, w10
	ldr	w10, [sp]
	add	w9, w9, w10
	ldr	s0, [x8, w9, sxtw #2]
	mov	w8, #49152                      // =0xc000
	movk	w8, #17529, lsl #16
	fmov	s1, w8
	fcmp	s0, s1
	b.pl	.LBB27_9
	b	.LBB27_8
.LBB27_8:                               //   in Loop: Header=BB27_5 Depth=2
	mov	w0, #42                         // =0x2a
	bl	l_putchar
	b	.LBB27_10
.LBB27_9:                               //   in Loop: Header=BB27_5 Depth=2
	mov	w0, #32                         // =0x20
	bl	l_putchar
	b	.LBB27_10
.LBB27_10:                              //   in Loop: Header=BB27_5 Depth=2
	b	.LBB27_11
.LBB27_11:                              //   in Loop: Header=BB27_5 Depth=2
	ldr	w8, [sp]
	add	w8, w8, #1
	str	w8, [sp]
	b	.LBB27_5
.LBB27_12:                              //   in Loop: Header=BB27_3 Depth=1
	mov	w0, #10                         // =0xa
	bl	l_putchar
	b	.LBB27_13
.LBB27_13:                              //   in Loop: Header=BB27_3 Depth=1
	ldr	w8, [sp, #4]
	add	w8, w8, #2
	str	w8, [sp, #4]
	b	.LBB27_3
.LBB27_14:
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end27:
	.size	l3d_display_graphical, .Lfunc_end27-l3d_display_graphical
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function l_free
	.type	l_free,@function
l_free:                                 // @l_free
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, .LBB28_2
	b	.LBB28_1
.LBB28_1:
	b	.LBB28_3
.LBB28_2:
	ldr	x8, [sp, #8]
	subs	x8, x8, #8
	str	x8, [sp]
	ldr	x8, [sp]
	str	wzr, [x8, #4]
	b	.LBB28_3
.LBB28_3:
	add	sp, sp, #16
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end28:
	.size	l_free, .Lfunc_end28-l_free
	.cfi_endproc
                                        // -- End function
	.type	.L.str,@object                  // @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"=== LAOLIPEF 3D \346\270\262\346\237\223\350\207\252\345\212\250\346\274\224\347\244\272 ===\n"
	.size	.L.str, 40

	.type	.L.str.1,@object                // @.str.1
.L.str.1:
	.asciz	"\351\224\231\350\257\257\357\274\232\346\227\240\346\263\225\345\210\233\345\273\2723D\344\270\212\344\270\213\346\226\207\n"
	.size	.L.str.1, 34

	.type	.L.str.2,@object                // @.str.2
.L.str.2:
	.asciz	"\346\274\224\347\244\272\345\260\206\345\234\2502\347\247\222\345\220\216\345\274\200\345\247\213...\n"
	.size	.L.str.2, 30

	.type	.L.str.3,@object                // @.str.3
.L.str.3:
	.asciz	"\345\234\272\346\231\2571\357\274\232\351\235\231\346\200\2013D\345\234\272\346\231\257\n"
	.size	.L.str.3, 26

	.type	.L.str.4,@object                // @.str.4
.L.str.4:
	.asciz	"\n\346\230\276\347\244\272\351\235\231\346\200\201\345\234\272\346\231\2573\347\247\222..."
	.size	.L.str.4, 27

	.type	.L.str.5,@object                // @.str.5
.L.str.5:
	.asciz	"\n\345\234\272\346\231\2572\357\274\2323D\346\227\213\350\275\254\345\212\250\347\224\273\n"
	.size	.L.str.5, 27

	.type	.L.str.6,@object                // @.str.6
.L.str.6:
	.asciz	"\n=== \346\274\224\347\244\272\345\256\214\346\210\220 ==="
	.size	.L.str.6, 22

	.type	.L.str.7,@object                // @.str.7
.L.str.7:
	.asciz	"\350\260\242\350\260\242\350\247\202\347\234\213\357\274\201\n"
	.size	.L.str.7, 17

	.type	l_mem_used,@object              // @l_mem_used
	.local	l_mem_used
	.comm	l_mem_used,4,4
	.type	l_mem_pool,@object              // @l_mem_pool
	.local	l_mem_pool
	.comm	l_mem_pool,4194304,1
	.type	L3D_TEXT_CHARS,@object          // @L3D_TEXT_CHARS
	.data
	.p2align	3, 0x0
L3D_TEXT_CHARS:
	.xword	.L.str.8
	.size	L3D_TEXT_CHARS, 8

	.type	.L.str.8,@object                // @.str.8
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.8:
	.asciz	" .,:;oO8@"
	.size	.L.str.8, 10

	.type	.L__const.l3d_draw_cube.edges,@object // @__const.l3d_draw_cube.edges
	.section	.rodata,"a",@progbits
	.p2align	2, 0x0
.L__const.l3d_draw_cube.edges:
	.word	0                               // 0x0
	.word	1                               // 0x1
	.word	1                               // 0x1
	.word	2                               // 0x2
	.word	2                               // 0x2
	.word	3                               // 0x3
	.word	3                               // 0x3
	.word	0                               // 0x0
	.word	4                               // 0x4
	.word	5                               // 0x5
	.word	5                               // 0x5
	.word	6                               // 0x6
	.word	6                               // 0x6
	.word	7                               // 0x7
	.word	7                               // 0x7
	.word	4                               // 0x4
	.word	0                               // 0x0
	.word	4                               // 0x4
	.word	1                               // 0x1
	.word	5                               // 0x5
	.word	2                               // 0x2
	.word	6                               // 0x6
	.word	3                               // 0x3
	.word	7                               // 0x7
	.size	.L__const.l3d_draw_cube.edges, 96

	.type	.L.str.9,@object                // @.str.9
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.9:
	.asciz	"\033[2J\033[H"
	.size	.L.str.9, 8

	.ident	"clang version 21.1.8"
	.section	".note.GNU-stack","",@progbits
