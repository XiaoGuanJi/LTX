#!/bin/bash
#
# Copyright [2023] [LAOLIPEF]
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

#!/bin/bash

# 2D地形探索游戏 - 修复指令冲突版
# 解决S键移动和保存的冲突问题

# 游戏参数设置
MAP_WIDTH=45
MAP_HEIGHT=15
PLAYER_CHAR="@"
TERRAIN_CHARS=(" " "." "," "~" "^" "*" "#" "▲")

# 颜色定义
RED='\033[1;31m'
GREEN='\033[1;32m'
YELLOW='\033[1;33m'
BLUE='\033[1;34m'
CYAN='\033[1;36m'
WHITE='\033[1;37m'
NC='\033[0m'

# 游戏状态
PLAYER_X=22
PLAYER_Y=7
PLAYER_LEVEL=1
PLAYER_EXP=0
DISCOVERED_AREAS=0
STEPS_TAKEN=0
CURRENT_SEED=""
SAVE_SLOT=""

# 路径设置
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd 2>/dev/null || pwd)"
SAVE_BASE_DIR="$SCRIPT_DIR/etc"
SAVE_DIR="$SAVE_BASE_DIR/data/2ds"

# 日志初始化
echo "=== 游戏启动 $(date) ===" > "$SCRIPT_DIR/game.log"

# 修复指令冲突的终端检测
get_terminal_size() {
    if command -v stty >/dev/null 2>&1; then
        stty size 2>/dev/null && return
    fi
    echo "15 50"
}

check_terminal_size() {
    read lines cols <<< $(get_terminal_size)
    echo "终端大小: ${cols}x${lines}" >> "$SCRIPT_DIR/game.log"
}

# 创建目录
create_directories() {
    mkdir -p "$SAVE_DIR" || {
        echo "使用备用存档目录" >> "$SCRIPT_DIR/game.log"
        SAVE_DIR="$SCRIPT_DIR/game_saves"
        mkdir -p "$SAVE_DIR"
    }
    echo "存档目录: $SAVE_DIR" >> "$SCRIPT_DIR/game.log"
}

# 生成种子
generate_seed() {
    date +%s%N | md5sum | head -c 16 2>/dev/null || echo "defaultseed12345678"
}

# 地形数据
declare -A terrain_map
declare -A discovered_map

# 生成新游戏
generate_new_game() {
    CURRENT_SEED=$(generate_seed)
    SAVE_SLOT=$(echo "$CURRENT_SEED" | cut -c1-8)
    
    for ((y=0; y<MAP_HEIGHT; y++)); do
        for ((x=0; x<MAP_WIDTH; x++)); do
            height=$(( (x * 137 + y * 157 + RANDOM) % 7 ))
            terrain_map[$y,$x]=$height
            discovered_map[$y,$x]=0
        done
    done
    
    PLAYER_X=$((MAP_WIDTH/2))
    PLAYER_Y=$((MAP_HEIGHT/2))
    PLAYER_LEVEL=1
    PLAYER_EXP=0
    DISCOVERED_AREAS=1
    STEPS_TAKEN=0
    discovered_map[$PLAYER_Y,$PLAYER_X]=1
}

# 修复指令冲突的保存函数
save_game() {
    echo "保存游戏..." >> "$SCRIPT_DIR/game.log"
    
    create_directories
    
    if [ -z "$SAVE_SLOT" ]; then
        SAVE_SLOT=$(generate_seed | cut -c1-8)
    fi
    
    local save_dir="$SAVE_DIR/$SAVE_SLOT"
    local save_file="$save_dir/game.dat"
    
    mkdir -p "$save_dir"
    
    # 保存游戏数据
    cat > "$save_file" << EOF
SAVE_TIME=$(date '+%Y-%m-%d %H:%M:%S')
SEED=$CURRENT_SEED
PLAYER_X=$PLAYER_X
PLAYER_Y=$PLAYER_Y
PLAYER_LEVEL=$PLAYER_LEVEL
PLAYER_EXP=$PLAYER_EXP
DISCOVERED_AREAS=$DISCOVERED_AREAS
STEPS_TAKEN=$STEPS_TAKEN
SAVE_SLOT=$SAVE_SLOT
EOF

    # 保存存档信息
    cat > "$save_dir/info.txt" << INFO
存档ID: $SAVE_SLOT
保存时间: $(date)
玩家等级: $PLAYER_LEVEL
探索进度: $DISCOVERED_AREAS
INFO

    if [ -f "$save_file" ]; then
        echo -e "${GREEN}✓ 游戏已保存!${NC}"
        echo -e "${CYAN}存档ID: $SAVE_SLOT${NC}"
        return 0
    else
        echo -e "${RED}✗ 保存失败${NC}"
        return 1
    fi
}

# 加载游戏
load_game() {
    local save_id=$1
    local save_dir="$SAVE_DIR/$save_id"
    local save_file="$save_dir/game.dat"
    
    if [ ! -f "$save_file" ]; then
        echo -e "${RED}存档不存在${NC}"
        return 1
    fi
    
    while IFS='=' read -r key value; do
        case $key in
            PLAYER_X) PLAYER_X="$value" ;;
            PLAYER_Y) PLAYER_Y="$value" ;;
            PLAYER_LEVEL) PLAYER_LEVEL="$value" ;;
            PLAYER_EXP) PLAYER_EXP="$value" ;;
            DISCOVERED_AREAS) DISCOVERED_AREAS="$value" ;;
            STEPS_TAKEN) STEPS_TAKEN="$value" ;;
            SAVE_SLOT) SAVE_SLOT="$value" ;;
            SEED) CURRENT_SEED="$value" ;;
        esac
    done < "$save_file"
    
    echo -e "${GREEN}✓ 游戏加载成功!${NC}"
    return 0
}

# 列出存档
list_saves() {
    if [ -d "$SAVE_DIR" ]; then
        local count=0
        for save_dir in "$SAVE_DIR"/*; do
            if [ -d "$save_dir" ] && [ -f "$save_dir/game.dat" ]; then
                local save_id=$(basename "$save_dir")
                local info_file="$save_dir/info.txt"
                echo -e "${CYAN}存档: $save_id${NC}"
                if [ -f "$info_file" ]; then
                    cat "$info_file"
                fi
                echo
                ((count++))
            fi
        done
        if [ $count -eq 0 ]; then
            echo -e "${YELLOW}暂无存档${NC}"
        fi
    else
        echo -e "${YELLOW}存档目录不存在${NC}"
    fi
}

# 移动玩家（修复S键冲突）
move_player() {
    local direction=$1
    local new_x=$PLAYER_X
    local new_y=$PLAYER_Y
    
    # 修复：使用小写字母进行移动，避免与保存冲突
    case $direction in
        w) ((new_y--)) ;;
        s) ((new_y++)) ;;  # 小写s移动
        a) ((new_x--)) ;;
        d) ((new_x++)) ;;
        *) return 1 ;;
    esac
    
    if (( new_x >= 0 && new_x < MAP_WIDTH && new_y >= 0 && new_y < MAP_HEIGHT )); then
        PLAYER_X=$new_x
        PLAYER_Y=$new_y
        ((STEPS_TAKEN++))
        
        if (( discovered_map[$PLAYER_Y,$PLAYER_X] == 0 )); then
            discovered_map[$PLAYER_Y,$PLAYER_X]=1
            ((DISCOVERED_AREAS++))
            ((PLAYER_EXP+=terrain_map[$PLAYER_Y,$PLAYER_X]+1))
            
            if (( PLAYER_EXP >= PLAYER_LEVEL * 8 )); then
                ((PLAYER_LEVEL++))
                echo -e "${GREEN}↑ 升级! 等级:$PLAYER_LEVEL${NC}"
            fi
        fi
        return 0
    fi
    return 1
}

# 显示游戏界面
display_game() {
    clear
    
    echo -e "${CYAN}════════ 2D地形探索 ════════${NC}"
    echo -e "存档:${SAVE_SLOT:0:6} 等级:$PLAYER_LEVEL 经验:$PLAYER_EXP"
    echo
    
    # 显示地图
    for ((y=0; y<MAP_HEIGHT; y++)); do
        line=""
        for ((x=0; x<MAP_WIDTH; x++)); do
            if (( discovered_map[$y,$x] == 1 )); then
                if (( x == PLAYER_X && y == PLAYER_Y )); then
                    line+="${RED}${PLAYER_CHAR}${NC}"
                else
                    height=${terrain_map[$y,$x]}
                    case $height in
                        0|1) line+="${BLUE}.${NC}" ;;
                        2|3) line+="${GREEN},${NC}" ;;
                        4|5) line+="${YELLOW}*${NC}" ;;
                        6) line+="${CYAN}#${NC}" ;;
                    esac
                fi
            else
                line+=" "
            fi
        done
        echo -e "$line"
    done
    
    # 显示状态
    local exploration_rate=$(( DISCOVERED_AREAS * 100 / (MAP_WIDTH * MAP_HEIGHT) ))
    echo
    echo -e "探索:${exploration_rate}% 位置:X${PLAYER_X} Y${PLAYER_Y} 步数:${STEPS_TAKEN}"
    echo -e "${GREEN}━━━━━━━━━━ 控制 ━━━━━━━━━━${NC}"
    
    # 修复：清晰区分移动和功能键
    echo -e "移动: ${CYAN}w${NC}(上) ${CYAN}s${NC}(下) ${CYAN}a${NC}(左) ${CYAN}d${NC}(右)"
    echo -e "功能: ${YELLOW}S${NC}(保存) ${YELLOW}L${NC}(加载) ${YELLOW}N${NC}(新游戏) ${YELLOW}Q${NC}(退出)"
    echo -e "菜单: ${YELLOW}M${NC}(存档管理)"
}

# 存档管理菜单
show_save_menu() {
    while true; do
        clear
        echo -e "${CYAN}══════ 存档管理 ══════${NC}"
        echo
        echo -e "${GREEN}1. 保存游戏"
        echo -e "2. 加载存档"
        echo -e "3. 删除存档"
        echo -e "4. 返回游戏"
        echo
        read -p "选择 [1-4]: " choice
        
        case $choice in
            1)
                if save_game; then
                    echo -e "${GREEN}保存成功!${NC}"
                else
                    echo -e "${RED}保存失败!${NC}"
                fi
                read -n1 -p "按任意键继续..."
                ;;
            2)
                echo
                list_saves
                if [ -d "$SAVE_DIR" ] && [ "$(ls -A "$SAVE_DIR" 2>/dev/null)" ]; then
                    read -p "输入存档ID: " save_id
                    if [ -n "$save_id" ]; then
                        if load_game "$save_id"; then
                            echo -e "${GREEN}加载成功!${NC}"
                            return 2  # 特殊返回码，表示需要重新开始游戏循环
                        fi
                    fi
                fi
                read -n1 -p "按任意键继续..."
                ;;
            3)
                echo
                list_saves
                if [ -d "$SAVE_DIR" ] && [ "$(ls -A "$SAVE_DIR" 2>/dev/null)" ]; then
                    read -p "输入要删除的存档ID: " save_id
                    if [ -n "$save_id" ]; then
                        local save_path="$SAVE_DIR/$save_id"
                        if [ -d "$save_path" ]; then
                            rm -rf "$save_path"
                            echo -e "${GREEN}存档已删除${NC}"
                        fi
                    fi
                fi
                read -n1 -p "按任意键继续..."
                ;;
            4)
                break
                ;;
            *)
                echo -e "${RED}无效选择${NC}"
                sleep 1
                ;;
        esac
    done
    return 0
}

# 游戏主循环（修复指令冲突）
game_loop() {
    while true; do
        display_game
        
        echo
        read -n1 -p "输入指令: " input
        echo
        
        case $input in
            # 修复：小写字母用于移动
            w|a|s|d)
                move_player "$input"
                ;;
            
            # 修复：大写字母用于功能
            S)
                if save_game; then
                    sleep 1
                fi
                ;;
            
            L)
                echo -e "${CYAN}可用存档:${NC}"
                list_saves
                read -p "输入存档ID加载: " save_id
                if [ -n "$save_id" ]; then
                    if load_game "$save_id"; then
                        echo -e "${GREEN}加载成功!${NC}"
                        return 2
                    fi
                fi
                sleep 1
                ;;
            
            M)
                show_save_menu
                local result=$?
                if [ $result -eq 2 ]; then
                    return 2
                fi
                ;;
            
            N)
                echo -e "${YELLOW}开始新游戏? (y/n)${NC}"
                read -n1 confirm
                if [[ $confirm == "y" || $confirm == "Y" ]]; then
                    generate_new_game
                    echo -e "${GREEN}新游戏开始!${NC}"
                    sleep 1
                fi
                ;;
            
            Q)
                echo -e "${YELLOW}退出游戏? (y/n)${NC}"
                read -n1 confirm
                if [[ $confirm == "y" || $confirm == "Y" ]]; then
                    echo -e "${GREEN}再见!${NC}"
                    exit 0
                fi
                ;;
            
            *)
                echo -e "${RED}无效指令!${NC}"
                echo -e "移动: wasd  功能: SLNQ  菜单: M"
                sleep 1
                ;;
        esac
    done
}

# 开始界面
show_title() {
    clear
    echo -e "${CYAN}════════════════════════════════${NC}"
    echo -e "${CYAN}          2D地形探索游戏${NC}"
    echo -e "${CYAN}      修复指令冲突版${NC}"
    echo -e "${CYAN}════════════════════════════════${NC}"
    echo
    echo -e "${GREEN}修复内容:${NC}"
    echo -e "• 移动: 小写 wasd (下方向键用小写s)"
    echo -e "• 保存: 大写 S 键"
    echo -e "• 加载: 大写 L 键"
    echo -e "• 菜单: 大写 M 键"
    echo
    echo -e "${YELLOW}存档位置:${NC}"
    echo -e "$SAVE_DIR"
    echo
    echo -e "${GREEN}按任意键开始游戏...${NC}"
    read -n1
}

# 主函数
main() {
    check_terminal_size
    create_directories
    show_title
    generate_new_game
    
    # 游戏循环（支持重新加载）
    while true; do
        game_loop
        local result=$?
        if [ $result -ne 2 ]; then
            break
        fi
    done
}

# 启动游戏
main "$@"
