/**
 * Copyright [2023] [LAOLIPEF]
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <stdio.h>
#include <openssl/evp.h>

#define BUFSIZE 8192

void print_md5(const char *filename) {
    EVP_MD_CTX *ctx = EVP_MD_CTX_new();
    const EVP_MD *md = EVP_md5();
    unsigned char md_value[EVP_MAX_MD_SIZE];
    unsigned int md_len;
    FILE *file = fopen(filename, "rb");
    unsigned char buffer[BUFSIZE];
    size_t bytes;

    if(!file) { perror("fopen"); return; }
    if(!EVP_DigestInit_ex(ctx, md, NULL)) { puts("Init failed"); return; }

    while((bytes = fread(buffer, 1, BUFSIZE, file)) > 0) {
        if(!EVP_DigestUpdate(ctx, buffer, bytes)) { puts("Update failed"); break; }
    }

    if(EVP_DigestFinal_ex(ctx, md_value, &md_len)) {
        for(unsigned i = 0; i < md_len; i++)
            printf("%02x", md_value[i]);
        printf("  %s\n", filename);
    }

    EVP_MD_CTX_free(ctx);
    fclose(file);
}

int main(int argc, char **argv) {
    if(argc < 2) {
        fprintf(stderr, "Usage: %s <file>\n", argv[0]);
        return 1;
    }
    print_md5(argv[1]);
    return 0;
}
